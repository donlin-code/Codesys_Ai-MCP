# donlinxg_MCP

CODESYS AI 工程助手 v0.1.0。通过 stdio MCP 让 AI 读取、分析和编辑独立测试工程中的 ST 代码，并获取完整编译诊断。

当前提供的是 **CODESYS V3.5 SP20 Patch 6 实验适配器**，基于已安装的官方 Scripting API；它不是 CODESYS 官方 SP22 MCP 插件，也不是安装到 IDE 的 `.package` 扩展。SP22 官方配置辅助脚本已提供，插件、PDE 许可和连接需另行核验。

## 安装与连接

要求 Windows、Node.js 22+、CODESYS SP20 Patch 6 及可用的 Scripting API。下载并解压 `donlinxg_MCP-0.1.0-runtime.zip`，其中已包含编译输出和生产依赖，无需 npm install。Node.js 和 CODESYS 不随包分发。

在工具包根目录运行 PowerShell：

```powershell
$toolkitNode = (Get-Command node).Source
# 指定你自己的已保存测试工程，启动器会另外复制工程。
.\scripts\Start-SP20Bridge.ps1 -Project 'D:\Projects\Test.project' `
  -Ide 'D:\Program Files\CODESYS 3.5.20.60\CODESYS\Common\CODESYS.exe' `
  -Profile 'CODESYS V3.5 SP20 Patch 6'
.\scripts\Configure-SP20Mcp.ps1 -NodePath $toolkitNode -RegisterCodex
```

刷新客户端 MCP 工具或新开对话。也可按 [通用 MCP 配置](config/mcp.example.json) 手动配置其他支持 stdio 的客户端，把示例路径改为解压目录绝对路径。连接依赖运行中的独立 IDE；关闭后需重新启动桥。不要上传 `artifacts/` 中生成的会话文件。

对 AI 说：“读取工程身份和 Application，读全自有 ST 及子对象，报告未覆盖内容；先分析，展示具体差异，等我确认本批后再修改和完整编译。”

## 工具能力

| MCP 工具 | 用途 |
|---|---|
| `codesys_project_info` | 核对当前绑定工程 |
| `codesys_list_objects` | 遍历对象树 |
| `codesys_read_object` | 读取完整声明、实现和指纹 |
| `codesys_replace_st` | 检查基线指纹后替换源码 |
| `codesys_create_st` | 检查父节点后创建 ST 对象 |
| `codesys_compile` | 完整 Application 编译及诊断 |
| `codesys_reconcile_write` | 核对结果未知的写入 |

覆盖 POU、GVL、DUT、方法及 ST Action 等文本对象；图形实现、受保护库和未知语言明确报告未覆盖。辅助 CLI 支持 `bridge status`、`snapshot capture/validate`、`diff`、`batch prepare/record/verify`、`report` 和 SP22 前置检查 `doctor`。

```powershell
node dist/src/cli.js --help
node dist/src/cli.js bridge status --config artifacts/sp20-bridge/current-session.json
node dist/src/cli.js snapshot capture --config artifacts/sp20-bridge/current-session.json --out artifacts/snapshot.json
node dist/src/cli.js report --snapshot artifacts/snapshot.json --out artifacts/coverage.md
```

## 编辑与验证

按 [编辑工作流](workflows/EDIT.md) 操作：展示实际差异 → 用户确认计划哈希 → 重新读取核对基线 → 逐项写入、回读 → 完整编译 → 用户保存关闭重开 → 再次核对。写入超时先核实实际状态，不盲目重试；编译修复需要新批次。

确认由 AI 对话工作流执行，服务端本身不强制用户审批；CLI 也不能约束其他客户端。采用单编辑者约定，不承诺 IDE 锁、多对象事务或自动完整回滚。编译通过不等于运行行为通过。

工具不自动保存，不提供 PLC 登录、下载、启动、强制 I/O。Modbus、OPC UA、OEM 适配和独立 UI 尚未交付。实际状态见 [验证范围](docs/acceptance.md)。

## 源码开发与打包

```powershell
npm ci
npm test
# Python 3（仅开发时运行桥合同测试）
python tests/sp20-bridge-contract.py
npm run package:release
```

源码测试不需要连接 IDE。发布源码只含通用工具、76 项 Node 测试、Python 桥合同测试及三对象 smoke 源码示例。原始现场工程、业务框架和历史取证资料不在发行范围。`npm run package:release` 先构建，再生成独立源码目录及包含锁定生产依赖的运行目录和 SHA256 清单。

仓库未授予开源许可证；第三方依赖按各自许可证使用，运行包保留依赖许可证文件与清单。
