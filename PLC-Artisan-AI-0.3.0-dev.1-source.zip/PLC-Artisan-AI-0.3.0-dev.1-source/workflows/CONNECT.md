# 连接工作流 v0.2

1. 阅读 docs/acceptance.md，区分当前版本证据和历史记录。SP20 是实验 Scripting API 适配器，SP22/OEM 未验收。
2. 使用已经保存的工程启动 scripts/Start-SP20Bridge.ps1。脚本建立独立副本和 GUI 工作者，不修改原框架或原工程。不要自动保存/关闭用户 IDE。
3. 启动 scripts/Start-Workbench.ps1。MCP 入口 dist/src/mcp-server.js 自动连接同一个本地服务；不得另建不受批次控制的写入通道。
4. 网页显式选择桥接配置。核对 codesys_status、codesys_project_info、codesys_capabilities 返回的工程、会话和 guardedWrites。文件存在、环境检查或历史验收不代表当前已连接。
5. 从 codesys_list_objects 的实际树选择 Application，读取一个完整 ST 对象。保留原始返回、声明、实现和 GUID，不通过摘要重建源码。
6. 升级桥接脚本后需新的 IDE 工作者。旧会话不能继承新会话批准；工具不自动切换另一工程或清除未知写入。
7. 在线、断线、身份变化、待核实写入分别记录。nonce、签名密钥和本地服务 ticket 仅在必要传输层保留，不进入模型上下文或分享包。

SP22 官方路线仍需对应插件、有效 PDE 许可、安装权限和 IDE 生成的真实 Bridge 参数。未实测时显示未验证，不用 SP20 成功替代官方验收。CLI doctor 保留官方 SP22 文件诊断；网页环境检查同时列出 SP20、SP22 和 OEM 状态。
