import { createHash, randomUUID } from "node:crypto";
import { mkdir, readFile, rename, writeFile, realpath } from "node:fs/promises";
import { dirname, relative, isAbsolute, resolve } from "node:path";

export class AppError extends Error {
  constructor(
    public code: string,
    message: string,
    public details?: unknown,
  ) {
    super(message);
  }
}
export const sha256 = (text: string) =>
  createHash("sha256").update(text, "utf8").digest("hex");
export const sourceHash = (declaration: string, implementation: string) =>
  sha256(declaration + "\0" + implementation);
export const lf = (text: string) => text.replace(/\r\n?/g, "\n");
export function decodeLocalText(data: Buffer): string {
  const opaqueMarker = Buffer.from("%TSD-Header-###%", "ascii");
  if (data.subarray(0, opaqueMarker.length).equals(opaqueMarker))
    throw new AppError(
      "OPAQUE_FILE",
      "The local file reader sees transparent-encryption ciphertext; provide an authorized readable copy. No plaintext content or absence of matches is inferred.",
    );
  const encoding =
    data[0] === 0xff && data[1] === 0xfe
      ? "utf-16le"
      : data[0] === 0xfe && data[1] === 0xff
        ? "utf-16be"
        : "utf-8";
  try {
    return new TextDecoder(encoding, { fatal: true }).decode(data);
  } catch {
    throw new AppError(
      "TEXT_ENCODING_UNSUPPORTED",
      "File is not valid UTF-8 or BOM-marked UTF-16; cannot index or scan it reliably",
    );
  }
}
export async function loadJson<T>(path: string, fallback?: T): Promise<T> {
  try {
    return JSON.parse((await readFile(path, "utf8")).replace(/^\uFEFF/, ""));
  } catch (e) {
    if (
      (e as NodeJS.ErrnoException).code === "ENOENT" &&
      fallback !== undefined
    )
      return fallback;
    throw e;
  }
}
export async function saveJson(path: string, value: unknown): Promise<void> {
  await mkdir(dirname(path), { recursive: true });
  const temp = path + "." + randomUUID() + ".tmp";
  await writeFile(temp, JSON.stringify(value, null, 2) + "\n", {
    mode: 0o600,
    flag: "wx",
  });
  await rename(temp, path);
}
export function redact(value: unknown): any {
  if (Array.isArray(value)) return value.map(redact);
  if (value && typeof value === "object")
    return Object.fromEntries(
      Object.entries(value)
        .filter(
          ([key]) =>
            !/^(nonce|authorizationKey|authorization|apiKey|password|secret|token|accessToken|refreshToken)$/i.test(
              key,
            ),
        )
        .map(([key, item]) => [key, redact(item)]),
    );
  return value;
}
export async function inside(root: string, path: string): Promise<string> {
  const base = await realpath(root),
    target = await realpath(resolve(root, path));
  const rel = relative(base, target);
  if (
    rel === ".." ||
    rel.startsWith("..\\") ||
    rel.startsWith("../") ||
    isAbsolute(rel)
  )
    throw new AppError("PATH_DENIED", "Path leaves the authorized directory");
  return target;
}
export class SerialQueue {
  private tail: Promise<unknown> = Promise.resolve();
  run<T>(action: () => Promise<T>): Promise<T> {
    const next = this.tail.then(action, action);
    this.tail = next.catch(() => undefined);
    return next;
  }
}
