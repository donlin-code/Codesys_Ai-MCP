#!/usr/bin/env node
import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
} from "@modelcontextprotocol/sdk/types.js";
import { toolsForProfile } from "./toolkit.js";
import { ensureService, rpc } from "./service-client.js";
export const bridgeTools = toolsForProfile("core");
async function main() {
  const args = process.argv.slice(2),
    option = (key: string) => {
      const i = args.indexOf("--" + key);
      return i >= 0 ? args[i + 1] : undefined;
    };
  const selectedTools = toolsForProfile(option("profile") ?? "core");
  // Discovery must work even when the IDE is offline. Connect only on a call.
  let endpointPromise: ReturnType<typeof ensureService> | undefined;
  const endpoint = () =>
    (endpointPromise ??= ensureService(option("data"), option("config")).catch(
      (e) => {
        endpointPromise = undefined;
        throw e;
      },
    ));
  const server = new Server(
    { name: "plc-artisan-ai", version: "0.3.0-dev.1" },
    {
      capabilities: { tools: {} },
      instructions:
        "Project-bound engineering service. Query capabilities for backend and validation status. Human approves exact batches in the local workbench; no approval tool exists. Stop on conflicts or unknown writes. Readback, compilation, save/reopen and behavior are distinct. No PLC download/start/force.",
    },
  );
  server.setRequestHandler(ListToolsRequestSchema, async () => ({
    tools: selectedTools as any,
  }));
  server.setRequestHandler(CallToolRequestSchema, async (request) => {
    try {
      if (!selectedTools.some((t) => t.name === request.params.name))
        throw Object.assign(new Error("Tool is not enabled in this profile"), {
          code: "TOOL_DISABLED",
        });
      const value = await rpc(await endpoint(), {
        method: "tools/call",
        name: request.params.name,
        arguments: request.params.arguments ?? {},
      });
      return {
        content: [{ type: "text" as const, text: JSON.stringify(value) }],
      };
    } catch (e) {
      return {
        isError: true,
        content: [
          {
            type: "text" as const,
            text: JSON.stringify({
              ok: false,
              error: {
                code: (e as any).code ?? "CLIENT_ERROR",
                message: (e as Error).message,
              },
            }),
          },
        ],
      };
    }
  });
  await server.connect(new StdioServerTransport());
}
main().catch((e) => {
  console.error((e as Error).message);
  process.exitCode = 1;
});
