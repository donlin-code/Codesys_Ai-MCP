import { randomUUID, createHmac } from "node:crypto";
import { join } from "node:path";
import { readdir } from "node:fs/promises";
import { readFileSync } from "node:fs";
import { BridgeClient, BridgeClientError } from "./bridge-client.js";
import {
  AppError,
  SerialQueue,
  loadJson,
  saveJson,
  lf,
  sourceHash,
  sha256,
  redact,
} from "./core.js";
import { canonicalJson } from "./snapshot.js";
import { unifiedTextDiff } from "./diff.js";
import {
  AnalysisIndex,
  type SourceObject,
  referencesTo,
  formatST,
} from "./st-analysis.js";
import { defaultProfile, standards, generationContract } from "./standards.js";
import { AnalysisWorker } from "./analysis-worker.js";
import { SourceSearch } from "./source-search.js";

export interface Adapter {
  name?: string;
  officialMcp?: boolean;
  close?(): Promise<void>;
  session: {
    sessionId: string;
    projectIdentity: { path: string; handle: number; instanceId: string };
  };
  actions: string[];
  guardedWrites: boolean;
  verifiedCreateKinds: string[];
  invoke(
    action: string,
    args?: Record<string, any>,
    permit?: { batchId: string; operationId: string; expiresAt: string },
  ): Promise<any>;
}
export class ScriptAdapter implements Adapter {
  session;
  actions;
  guardedWrites;
  verifiedCreateKinds;
  constructor(private client: BridgeClient) {
    this.session = {
      sessionId: client.ready.sessionId,
      projectIdentity: client.ready.projectIdentity,
    };
    this.actions = client.ready.actions;
    this.guardedWrites =
      (client.ready as any).writeAuthorization === "hmac-sha256-v1" &&
      typeof (client.config as any).authorizationKey === "string" &&
      (client.ready as any).bridgeSourceSha256 ===
        sha256(
          readFileSync(
            new URL("../../scripts/sp20_bridge.py", import.meta.url),
            "utf8",
          ),
        );
    this.verifiedCreateKinds = (client.ready as any).verifiedCreateKinds ?? [];
  }
  async invoke(
    action: string,
    args: Record<string, any> = {},
    permit?: { batchId: string; operationId: string; expiresAt: string },
  ) {
    if (action === "reconcile")
      return this.client.reconcile(args.requestId, args.observedSha256);
    let authorization;
    if (permit) {
      if (!this.guardedWrites)
        throw new AppError(
          "BRIDGE_UPGRADE_REQUIRED",
          "Start a fresh bridge with v0.2 authorization support",
        );
      const payload = JSON.stringify({
        ...permit,
        ...this.session,
        action,
        args,
        grantId: randomUUID(),
      });
      authorization = {
        payload,
        signature: createHmac(
          "sha256",
          (this.client.config as any).authorizationKey,
        )
          .update(payload)
          .digest("hex"),
      };
    }
    return this.client.call(action, args, authorization);
  }
}
export interface LiveOperation {
  id: string;
  action: "replace_st" | "create_st";
  path: string;
  args: Record<string, any>;
  before: SourceObject | null;
  afterHash: string;
  diff: string;
  state: "planned" | "executing" | "verified" | "failed" | "unknown";
  result?: any;
}
export interface LiveBatch {
  schemaVersion: 2;
  id: string;
  session: Adapter["session"];
  applicationPath: string;
  createdAt: string;
  operations: LiveOperation[];
  planHash: string;
  approval?: { at: string; expiresAt: string; planHash: string };
  parentBaselines?: Record<string, [string, string][]>;
  halted?: string;
  compile?: any;
  persistence: "not-verified";
}
export interface SnapshotV2 {
  schemaVersion: 2;
  origin: "ide";
  session: Adapter["session"];
  applicationPath: string;
  capturedAt: string;
  startedAt: string;
  scope: { roots: string[]; kinds: string[]; paths: string[] };
  inventory: any[];
  objects: SourceObject[];
  issues: { path: string; reason: string }[];
  evidenceIds: string[];
  treeComplete: boolean;
  freshness: "verified-across-passes" | "changed";
  atomic: false;
  refresh?: {
    at: string;
    paths: string[];
    completeness: "selected-objects-only";
  };
  metrics: { elapsedMs: number; requests: number; sourceBytes: number };
}
function immutablePlan(b: LiveBatch) {
  return {
    schemaVersion: b.schemaVersion,
    id: b.id,
    session: b.session,
    applicationPath: b.applicationPath,
    createdAt: b.createdAt,
    parentBaselines: b.parentBaselines ?? {},
    operations: b.operations.map(
      ({ id, action, path, args, before, afterHash, diff }) => ({
        id,
        action,
        path,
        args,
        before,
        afterHash,
        diff,
      }),
    ),
  };
}
export class EngineeringService {
  readonly queue = new SerialQueue();
  readonly index = new AnalysisIndex();
  adapter?: Adapter;
  snapshot?: SnapshotV2;
  contextSnapshot?: any;
  lastError?: { code: string; message: string };
  private configurationFingerprint?: string;
  progress: any = null;
  private cachedStatus: any;
  private worker = new AnalysisWorker();
  private searchIndex = new SourceSearch();
  private searchSnapshot?: SnapshotV2;
  private referenceSnapshot?: SnapshotV2;
  private referencePromise?: Promise<any[]>;
  private analysisSnapshot?: SnapshotV2;
  private analysisContext?: any;
  private analysisPromise?: Promise<any>;
  constructor(
    public readonly directory: string,
    adapter?: Adapter,
  ) {
    this.adapter = adapter;
  }
  async close() {
    await this.worker.close();
    await this.adapter?.close?.();
  }
  private batchPath(id: string) {
    if (!/^[a-f0-9-]{36}$/.test(id))
      throw new AppError("INVALID_ID", "Invalid batch ID");
    return join(this.directory, "batches", id + ".json");
  }
  async connect(configPath: string) {
    return this.queue.run(async () => {
      const config = await loadJson<any>(configPath);
      let next: Adapter;
      if (config.backend === "sp22-official") {
        const { OfficialConnection, OfficialDiscoveryAdapter } =
          await import("./official-mcp.js");
        const connection = new OfficialConnection(
          join(this.directory, "official-evidence", randomUUID()),
        );
        await connection.connect(config);
        next = new OfficialDiscoveryAdapter(connection);
      } else
        next = new ScriptAdapter(await BridgeClient.load(configPath, 90000));
      const ping = await next.invoke("ping");
      if (!ping.ok) throw new AppError("OFFLINE", "Bridge handshake failed");
      await this.adapter?.close?.();
      this.adapter = next;
      this.configurationFingerprint = sha256(canonicalJson(config));
      this.snapshot = undefined;
      this.contextSnapshot = undefined;
      this.lastError = undefined;
      await saveJson(join(this.directory, "connection.json"), {
        configPath,
        session: next.session,
      });
      return this.getStatus();
    });
  }
  private bound() {
    if (!this.adapter)
      throw new AppError(
        "OFFLINE",
        "No IDE connected. Select a fresh isolated test-project bridge.",
      );
    return this.adapter;
  }
  async status() {
    if (this.progress)
      return {
        ...(this.cachedStatus ?? {
          state: "unknown",
          session: this.adapter?.session,
        }),
        progress: this.progress,
        dirty: null,
        liveCheck: false,
      };
    return this.queue.run(() => this.getStatus());
  }
  private async getStatus() {
    let online = false,
      info: any;
    if (this.adapter)
      try {
        info = await this.raw("project_info");
        online = true;
        this.lastError = undefined;
      } catch (e) {
        this.lastError = {
          code: (e as any).code ?? "OFFLINE",
          message: (e as Error).message,
        };
      }
    const status = {
      state: !online
        ? "disconnected"
        : (await this.batches()).some((b) =>
              b.operations.some((o) =>
                ["unknown", "executing"].includes(o.state),
              ),
            )
          ? "unresolved-write"
          : "online",
      session: this.adapter?.session,
      configurationFingerprint: this.configurationFingerprint,
      guardedWrites: this.adapter?.guardedWrites ?? false,
      dirty: info?.dirty ?? null,
      lastError: this.lastError,
      progress: this.progress,
      adapter: this.adapter?.name ?? "experimental-sp20-scriptengine",
      officialMcp: this.adapter?.officialMcp ?? false,
      otherAdapters: ["SP22-official", "InoProShop", "Motion Expert"].map(
        (name) => ({ name, status: "unverified" }),
      ),
      lastLiveCheckAt: new Date().toISOString(),
      liveCheck: true,
    };
    this.cachedStatus = status;
    return status;
  }
  async raw(
    action: string,
    args: Record<string, any> = {},
    permit?: { batchId: string; operationId: string; expiresAt: string },
  ) {
    const adapter = this.bound(),
      evidenceId = randomUUID(),
      at = new Date().toISOString();
    const response = await adapter.invoke(action, args, permit);
    // Exact local transport evidence is intentionally separate from public/model output.
    await saveJson(
      join(this.directory, "private-evidence", evidenceId + ".json"),
      { id: evidenceId, action, args, result: response, capturedAt: at },
    );
    if (response.ok === false)
      throw new AppError(response.error.code, response.error.message, {
        ...redact(response.error),
        requestId: response.id,
      });
    return { ...redact(response.result ?? response), evidenceId };
  }
  async read(action: string, args: Record<string, any> = {}) {
    if (
      ![
        "ping",
        "project_info",
        "list",
        "read",
        "read_many",
        "read_page",
        "context",
        "capabilities",
      ].includes(action)
    )
      throw new AppError("ACTION_DENIED", "Not a read action");
    return this.queue.run(async () => {
      const result = await this.raw(action, args);
      if (action === "context") this.contextSnapshot = result;
      return result;
    });
  }
  async batches(): Promise<LiveBatch[]> {
    const names = await readdir(join(this.directory, "batches")).catch(
      () => [],
    );
    return Promise.all(
      names
        .filter((n) => n.endsWith(".json"))
        .map((n) => loadJson<LiveBatch>(join(this.directory, "batches", n))),
    );
  }
  async getBatch(id: string) {
    return loadJson<LiveBatch>(this.batchPath(id));
  }
  async prepare(
    applicationPath: string,
    requests: {
      action: "replace_st" | "create_st";
      args: Record<string, any>;
    }[],
  ) {
    if (!requests.length || requests.length > 100)
      throw new AppError("INVALID_BATCH", "Batch requires 1..100 operations");
    return this.queue.run(async () => {
      const a = this.bound(),
        tree = await this.raw("list");
      if (
        !tree.objects.some(
          (o: any) => o.path === applicationPath && o.isApplication,
        )
      )
        throw new AppError(
          "INVALID_APPLICATION",
          "Select an Application from the live tree",
        );
      const operations: LiveOperation[] = [],
        seen = new Set<string>();
      for (const request of requests) {
        if (!["replace_st", "create_st"].includes(request.action))
          throw new AppError("ACTION_DENIED", "Unsupported operation");
        const input = request.args;
        if (
          typeof input.declaration !== "string" ||
          typeof input.implementation !== "string" ||
          /\0/.test(input.declaration + input.implementation)
        )
          throw new AppError(
            "INVALID_SOURCE",
            "Source must be complete declaration/implementation strings without NUL",
          );
        const path =
          request.action === "replace_st"
            ? input.path
            : (input.parentPath === "/" ? "" : input.parentPath) +
              "/" +
              String(input.name).replace(/~/g, "~0").replace(/\//g, "~1");
        if (
          typeof path !== "string" ||
          !path.startsWith(applicationPath + "/") ||
          seen.has(path)
        )
          throw new AppError(
            "INVALID_SCOPE",
            "Targets must be unique descendants of the selected Application",
          );
        seen.add(path);
        const declaration = lf(input.declaration),
          implementation = lf(input.implementation);
        const checks = this.index.analyze([
          {
            path,
            declaration,
            implementation,
            sha256: sourceHash(declaration, implementation),
          },
        ]);
        if (checks.findings.some((f) => f.severity === "error"))
          throw new AppError(
            "STANDARD_CHECK_FAILED",
            "Draft contains unverified language features",
            checks.findings,
          );
        let before: SourceObject | null = null,
          args: Record<string, any>;
        if (request.action === "replace_st") {
          before = await this.raw("read", { path });
          if (before!.sourceComplete !== true)
            throw new AppError(
              "INCOMPLETE_SOURCE",
              "Target is not proven complete editable ST",
            );
          args = {
            path,
            declaration,
            implementation,
            expectedSha256: before!.sha256,
          };
          if (before!.id) args.expectedObjectId = before!.id;
        } else {
          if (
            tree.objects.some(
              (o: any) =>
                o.path === path ||
                (o.parentPath === input.parentPath &&
                  o.name?.toLowerCase() === input.name.toLowerCase()),
            )
          )
            throw new AppError(
              "ALREADY_EXISTS",
              "Creation target already exists; prepare a replacement batch instead",
            );
          if (!a.verifiedCreateKinds.includes(input.kind))
            throw new AppError(
              "KIND_UNVERIFIED",
              "Creation kind has no live validation for this adapter: " +
                input.kind,
            );
          if (
            input.kind === "DUT" &&
            input.dutKind &&
            input.dutKind !== "Structure" &&
            !a.verifiedCreateKinds.includes(
              "DUT_" + input.dutKind.toUpperCase(),
            )
          )
            throw new AppError(
              "KIND_UNVERIFIED",
              "DUT subtype awaits native validation",
            );
          const parent = tree.objects.find(
            (o: any) => o.path === input.parentPath,
          );
          if (!parent)
            throw new AppError(
              "INVALID_PARENT",
              "Parent not in live inventory",
            );
          args = {
            parentPath: input.parentPath,
            name: input.name,
            kind: input.kind,
            declaration,
            implementation,
            expectedChildrenSha256: parent.childrenSha256,
          };
          if (parent.id) args.expectedParentId = parent.id;
          if (input.dutKind) args.dutKind = input.dutKind;
          if (input.returnType) args.returnType = input.returnType;
          if (input.baseType) args.baseType = input.baseType;
        }
        operations.push({
          id: randomUUID(),
          action: request.action,
          path,
          args,
          before,
          afterHash: sourceHash(declaration, implementation),
          diff: unifiedTextDiff(
            before
              ? before.declaration + "\n" + before.implementation
              : undefined,
            declaration + "\n" + implementation,
            path,
          ),
          state: "planned",
        });
      }
      const batch: LiveBatch = {
        schemaVersion: 2,
        id: randomUUID(),
        session: structuredClone(a.session),
        applicationPath,
        createdAt: new Date().toISOString(),
        operations,
        planHash: "",
        persistence: "not-verified",
      };
      batch.parentBaselines = Object.fromEntries(
        operations
          .filter((o) => o.action === "create_st")
          .map((o) => [
            o.args.parentPath,
            tree.objects
              .filter((x: any) => x.parentPath === o.args.parentPath)
              .map((x: any) => [x.path, x.id])
              .sort(),
          ]),
      );
      batch.planHash = sha256(canonicalJson(immutablePlan(batch)));
      await saveJson(this.batchPath(batch.id), batch);
      return batch;
    });
  }
  /** Only the browser human-control route invokes this; never exposed as a model/MCP tool. */
  async approve(id: string, planHash: string) {
    return this.queue.run(async () => {
      const b = await this.getBatch(id);
      this.validatePlan(b);
      if (
        planHash !== b.planHash ||
        b.halted ||
        b.operations.some((o) => o.state !== "planned")
      )
        throw new AppError(
          "APPROVAL_REJECTED",
          "Plan changed or batch already started",
        );
      b.approval = {
        at: new Date().toISOString(),
        expiresAt: new Date(Date.now() + 30 * 60000).toISOString(),
        planHash,
      };
      await saveJson(this.batchPath(id), b);
      return b;
    });
  }
  private validatePlan(b: LiveBatch) {
    if (
      b.schemaVersion !== 2 ||
      sha256(canonicalJson(immutablePlan(b))) !== b.planHash
    )
      throw new AppError("PLAN_CHANGED", "Immutable plan hash mismatch");
    if (canonicalJson(b.session) !== canonicalJson(this.bound().session))
      throw new AppError(
        "SESSION_CHANGED",
        "Batch belongs to a different IDE session",
      );
  }
  async execute(
    id: string,
    operationId: string,
    submitted?: { action: string; args: Record<string, any> },
  ) {
    return this.queue.run(async () => {
      const b = await this.getBatch(id);
      this.validatePlan(b);
      if (
        !b.approval ||
        b.approval.planHash !== b.planHash ||
        Date.parse(b.approval.expiresAt) <= Date.now()
      )
        throw new AppError(
          "APPROVAL_REQUIRED",
          "Human approval for this exact plan is required or has expired",
        );
      if (!this.bound().guardedWrites)
        throw new AppError(
          "BRIDGE_UPGRADE_REQUIRED",
          "Current bridge is read-only; start the v0.2 bridge",
        );
      const all = await this.batches();
      if (
        all.some((x) =>
          x.operations.some((o) => ["unknown", "executing"].includes(o.state)),
        )
      )
        throw new AppError(
          "UNRESOLVED_WRITE",
          "Resolve unknown/executing writes before any new write",
        );
      const op = b.operations.find((o) => o.id === operationId),
        first = b.operations.find((o) => o.state !== "verified");
      if (!op || op !== first || op.state !== "planned" || b.halted)
        throw new AppError(
          "BATCH_HALTED",
          "Wrong operation order or batch halted",
        );
      if (
        submitted &&
        (submitted.action !== op.action ||
          canonicalJson(submitted.args) !== canonicalJson(op.args))
      )
        throw new AppError(
          "PLAN_CHANGED",
          "Write parameters differ from approved operation",
        );
      const args = { ...op.args };
      // All planned baselines and previous readbacks are checked again; local checks are not an IDE lock.
      try {
        for (const target of b.operations.filter(
          (o) => o.before || o.state === "verified",
        )) {
          const now = await this.raw("read", { path: target.path });
          if (
            now.sha256 !==
            (target.state === "verified"
              ? target.afterHash
              : target.before!.sha256)
          )
            throw new AppError("CONFLICT", "Source changed: " + target.path);
          const expectedId = target.before?.id ?? target.result?.readback?.id;
          if (expectedId && now.id !== expectedId)
            throw new AppError(
              "CONFLICT",
              "Object identity changed: " + target.path,
            );
        }
        if (op.action === "create_st") {
          const tree = await this.raw("list"),
            parent = tree.objects.find(
              (o: any) => o.path === op.args.parentPath,
            );
          if (
            !parent ||
            (args.expectedParentId && parent.id !== args.expectedParentId)
          )
            throw new AppError("CONFLICT", "Parent object identity changed");
          // Account only for earlier approved creations in this parent.
          const prior = b.operations.filter(
            (o) =>
              o.state === "verified" &&
              o.action === "create_st" &&
              o.args.parentPath === op.args.parentPath,
          );
          if (
            !prior.length &&
            parent?.childrenSha256 !== op.args.expectedChildrenSha256
          )
            throw new AppError("CONFLICT", "Parent inventory changed");
          if (prior.length) {
            const original = tree.objects.filter(
              (o: any) => o.parentPath === op.args.parentPath,
            );
            const expectedAdded = new Set(prior.map((o) => o.path));
            // A complete original sibling set is recorded below at prepare time.
            const base = (b as any).parentBaselines?.[op.args.parentPath];
            if (
              !base ||
              canonicalJson(
                original
                  .filter((o: any) => !expectedAdded.has(o.path))
                  .map((o: any) => [o.path, o.id])
                  .sort(),
              ) !== canonicalJson(base)
            )
              throw new AppError(
                "CONFLICT",
                "Parent inventory changed outside this batch",
              );
          }
          // Derive only from the tree just validated above. A later unchecked
          // list must never silently authorize an unrelated IDE tree change.
          args.expectedChildrenSha256 = parent.childrenSha256;
        }
      } catch (e) {
        b.halted = (e as Error).message;
        await saveJson(this.batchPath(id), b);
        throw e;
      }
      op.state = "executing";
      await saveJson(this.batchPath(id), b);
      try {
        if (op.action === "replace_st") {
          const fresh = await this.raw("read", { path: op.path });
          if (
            fresh.sha256 !== args.expectedSha256 ||
            (args.expectedObjectId && fresh.id !== args.expectedObjectId)
          )
            throw new AppError(
              "CONFLICT",
              "Target changed immediately before write",
            );
        }
        const result = await this.raw(op.action, args, {
          batchId: id,
          operationId,
          expiresAt: b.approval.expiresAt,
        });
        op.result = result;
        const readback = await this.raw("read", { path: op.path });
        if (
          readback.sha256 !== op.afterHash ||
          readback.declaration !== args.declaration ||
          readback.implementation !== args.implementation ||
          (args.expectedObjectId && readback.id !== args.expectedObjectId)
        )
          throw new AppError(
            "READBACK_MISMATCH",
            "Independent readback differs",
          );
        op.state = "verified";
      } catch (e) {
        const code = (e as any).code ?? "UNKNOWN";
        op.state =
          op.result?.verified === true ||
          ([
            "CONFLICT",
            "INVALID_REQUEST",
            "APPROVAL_REQUIRED",
            "ALREADY_EXISTS",
            "UNAUTHORIZED_WRITE",
            "INVALID_PARENT",
            "KIND_UNVERIFIED",
          ].includes(code) &&
            !(e as any).details?.partial)
            ? "failed"
            : "unknown";
        op.result = {
          ...op.result,
          error: {
            code,
            message: (e as Error).message,
            details: redact((e as any).details),
          },
        };
        b.halted = code;
        await saveJson(this.batchPath(id), b);
        throw e;
      }
      await saveJson(this.batchPath(id), b);
      this.snapshot = undefined;
      return b;
    });
  }
  async compile(applicationPath: string, batchId?: string) {
    return this.queue.run(async () => {
      if (batchId) {
        const b = await this.getBatch(batchId);
        this.validatePlan(b);
        if (
          b.applicationPath !== applicationPath ||
          b.operations.some((o) => o.state !== "verified")
        )
          throw new AppError(
            "BATCH_INCOMPLETE",
            "Cannot associate build with incomplete batch",
          );
      }
      const fingerprintScope = async () => {
        const tree = await this.raw("list"),
          targets = tree.objects.filter(
            (o: any) =>
              o.path.startsWith(applicationPath + "/") &&
              (o.hasDeclaration || o.hasImplementation),
          );
        const values: any[] = [];
        for (let i = 0; i < targets.length; i += 25) {
          const paths = targets.slice(i, i + 25).map((o: any) => o.path);
          if (this.bound().actions.includes("fingerprint_many"))
            values.push(
              ...(await this.raw("fingerprint_many", { paths })).objects.map(
                (v: any) =>
                  v.ok
                    ? {
                        path: v.source.path,
                        id: v.source.id,
                        sha256: v.source.sha256,
                      }
                    : { path: v.path, unread: true },
              ),
            );
          else
            for (const path of paths) {
              const v = await this.raw("read", { path });
              values.push({ path, id: v.id, sha256: v.sha256 });
            }
        }
        return { inventorySha256: tree.inventorySha256, sources: values };
      };
      const before = await fingerprintScope();
      if (batchId) {
        const b = await this.getBatch(batchId);
        for (const op of b.operations)
          if (
            !before.sources.some(
              (o) => o.path === op.path && o.sha256 === op.afterHash,
            )
          )
            throw new AppError(
              "CONFLICT",
              "Batch source changed before compilation: " + op.path,
            );
      }
      const build = await this.raw("compile", {
        applicationPath,
        fullBuild: true,
      });
      const after = await fingerprintScope();
      const result = {
        ...build,
        sourceScopeBefore: before,
        sourceScopeAfter: after,
        associationVerified:
          canonicalJson(before) === canonicalJson(after) &&
          !before.sources.some((o) => o.unread),
        saved: false,
      };
      if (batchId) {
        const b = await this.getBatch(batchId);
        this.validatePlan(b);
        if (
          b.applicationPath !== applicationPath ||
          b.operations.some((o) => o.state !== "verified")
        )
          throw new AppError(
            "BATCH_INCOMPLETE",
            "Cannot associate build with incomplete batch",
          );
        b.compile = result;
        await saveJson(this.batchPath(batchId), b);
      }
      return result;
    });
  }
  async reconcileBatch(
    batchId: string,
    operationId: string,
    requestId: string,
    observedSha256: string,
  ) {
    return this.queue.run(async () => {
      const b = await this.getBatch(batchId);
      this.validatePlan(b);
      const op = b.operations.find((o) => o.id === operationId);
      if (!op || !["unknown", "executing"].includes(op.state))
        throw new AppError("NOT_PENDING", "Operation is not unresolved");
      const pendingId =
        op.result?.error?.details?.id ?? op.result?.error?.details?.requestId;
      if (pendingId && pendingId !== requestId)
        throw new AppError(
          "REQUEST_MISMATCH",
          "Request ID does not match the failed operation",
        );
      await this.raw("reconcile", { requestId, observedSha256 });
      const current = await this.raw("read", { path: op.path });
      if (current.sha256 !== observedSha256)
        throw new AppError("CONFLICT", "Source changed during reconciliation");
      op.state = current.sha256 === op.afterHash ? "verified" : "failed";
      op.result = {
        ...op.result,
        reconciliation: {
          observedSha256,
          requestId,
          at: new Date().toISOString(),
          originalSuccessProven: false,
        },
      };
      b.halted = "Reconciled; prepare a fresh batch for any remaining edits";
      await saveJson(this.batchPath(batchId), b);
      return b;
    });
  }
  async capture(
    applicationPath: string,
    filters: Partial<SnapshotV2["scope"]> = {},
    mode: "batch" | "sequential" = "batch",
  ) {
    return this.queue.run(async () => {
      const started = Date.now(),
        evidenceIds: string[] = [];
      let requests = 0;
      const call = async (action: string, args = {}) => {
        requests++;
        const r = await this.raw(action, args);
        evidenceIds.push(r.evidenceId);
        return r;
      };
      const tree = await call("list");
      if (
        !tree.objects.some(
          (o: any) => o.path === applicationPath && o.isApplication,
        )
      )
        throw new AppError("INVALID_APPLICATION", "Application missing");
      const scope = {
        roots: filters.roots ?? [applicationPath],
        kinds: filters.kinds ?? [],
        paths: filters.paths ?? [],
      };
      const inventory = tree.objects.filter(
        (o: any) =>
          o.path.startsWith(applicationPath + "/") &&
          scope.roots.some(
            (root) => o.path === root || o.path.startsWith(root + "/"),
          ) &&
          (!scope.paths.length || scope.paths.includes(o.path)),
      );
      const candidates = inventory.filter(
          (o: any) => o.hasDeclaration || o.hasImplementation,
        ),
        objects: SourceObject[] = [],
        issues: SnapshotV2["issues"] = [];
      for (const o of inventory.filter(
        (o: any) => !o.hasDeclaration && !o.hasImplementation,
      ))
        issues.push({
          path: o.path,
          reason:
            "Non-text object: inventory only; complete source is not exposed by ST adapter",
        });
      let done = 0;
      const read = async (paths: string[]) => {
        if (mode === "batch" && this.bound().actions.includes("read_many")) {
          const r = await call("read_many", { paths });
          return r.objects as any[];
        }
        const values = [];
        for (const path of paths)
          try {
            values.push({ ok: true, source: await call("read", { path }) });
          } catch (e) {
            values.push({ ok: false, path, error: (e as Error).message });
          }
        return values;
      };
      this.progress = { done: 0, total: candidates.length, phase: "read" };
      try {
        for (let i = 0; i < candidates.length; i += 25) {
          const values = await read(
            candidates.slice(i, i + 25).map((o: any) => o.path),
          );
          for (const v of values) {
            let o = v.source;
            if (v.paged) o = await this.readPaged(v.path, call);
            if (!v.ok || !o || o.sourceComplete !== true || o.complete !== true)
              issues.push({
                path: v.path ?? o?.path ?? "",
                reason: v.error?.message ?? v.error ?? "Complete ST not proven",
              });
            else if (!scope.kinds.length || scope.kinds.includes(o.sourceKind))
              objects.push(o);
          }
          done += values.length;
          this.progress = { done, total: candidates.length, phase: "read" };
        }
        let changed = false;
        for (let i = 0; i < objects.length; i += 25) {
          const paths = objects.slice(i, i + 25).map((o) => o.path);
          const check =
            mode === "batch" &&
            this.bound().actions.includes("fingerprint_many")
              ? (await call("fingerprint_many", { paths })).objects
              : await read(paths);
          for (const v of check) {
            const current = v.paged
              ? await this.readPaged(v.path, call)
              : v.source;
            const prior = objects.find(
              (o) => o.path === (current?.path ?? v.path),
            );
            if (
              !v.ok ||
              !prior ||
              current?.sha256 !== prior.sha256 ||
              current?.id !== prior.id
            ) {
              changed = true;
              issues.push({
                path: prior?.path ?? v.path,
                reason:
                  "Source changed or could not be verified across passes; recapture required",
              });
            }
          }
        }
        const endTree = await call("list"),
          treeComplete = tree.inventorySha256 === endTree.inventorySha256;
        const snapshot: SnapshotV2 = {
          schemaVersion: 2,
          origin: "ide",
          session: structuredClone(this.bound().session),
          applicationPath,
          capturedAt: new Date().toISOString(),
          startedAt: new Date(started).toISOString(),
          scope,
          inventory,
          objects,
          issues,
          evidenceIds,
          treeComplete,
          freshness:
            changed || !treeComplete ? "changed" : "verified-across-passes",
          atomic: false,
          metrics: {
            elapsedMs: Date.now() - started,
            requests,
            sourceBytes: objects.reduce(
              (n, o) => n + Buffer.byteLength(o.declaration + o.implementation),
              0,
            ),
          },
        };
        const seen = new Set<string>();
        for (const object of objects) {
          if (
            seen.has(object.path) ||
            !inventory.some(
              (i: any) => i.path === object.path && i.id === object.id,
            ) ||
            sourceHash(object.declaration, object.implementation) !==
              object.sha256
          )
            throw new AppError(
              "SNAPSHOT_INVALID",
              "Duplicate, wrong identity or altered source in capture",
            );
          seen.add(object.path);
        }
        await saveJson(
          join(this.directory, "snapshots", randomUUID() + ".json"),
          snapshot,
        );
        this.snapshot = snapshot;
        return snapshot;
      } finally {
        this.progress = null;
      }
    });
  }
  async refreshSources(paths: string[]) {
    if (
      !paths.length ||
      paths.length > 25 ||
      new Set(paths).size !== paths.length
    )
      throw new AppError(
        "INVALID_SCOPE",
        "Select 1..25 distinct captured objects",
      );
    return this.queue.run(async () => {
      const snapshot = this.snapshot;
      if (
        !snapshot ||
        canonicalJson(snapshot.session) !== canonicalJson(this.bound().session)
      )
        throw new AppError("SNAPSHOT_REQUIRED", "Capture this session first");
      if (paths.some((p) => !snapshot.objects.some((o) => o.path === p)))
        throw new AppError(
          "INVALID_SCOPE",
          "Refresh cannot silently expand a captured scope",
        );
      const objects = [...snapshot.objects],
        evidenceIds: string[] = [];
      const call = async (action: string, args: any) => {
        const r = await this.raw(action, args);
        evidenceIds.push(r.evidenceId);
        return r;
      };
      try {
        for (const path of paths) {
          const before = snapshot.objects.find((o) => o.path === path)!;
          const first = await call("read", { path });
          const current = first.paged
            ? await this.readPaged(path, call)
            : first;
          const second = await call("read", { path });
          const check = second.paged
            ? await this.readPaged(path, call)
            : second;
          if (
            current.path !== path ||
            current.id !== before.id ||
            check.id !== current.id ||
            current.complete !== true ||
            check.complete !== true ||
            current.sourceComplete !== true ||
            check.sha256 !== current.sha256 ||
            sourceHash(current.declaration, current.implementation) !==
              current.sha256
          )
            throw new AppError(
              "SOURCE_CHANGED",
              "Selected object changed identity/content or is incomplete; recapture scope",
            );
          objects[objects.findIndex((o) => o.path === path)] = current;
        }
        const refresh = {
          at: new Date().toISOString(),
          paths,
          completeness: "selected-objects-only" as const,
        };
        const changedPaths = paths.filter(
          (p) =>
            snapshot.objects.find((o) => o.path === p)!.sha256 !==
            objects.find((o) => o.path === p)!.sha256,
        );
        if (!changedPaths.length)
          return {
            refresh,
            changedPaths,
            freshness: "selected-objects-only",
            atomic: false,
          };
        const next: SnapshotV2 = {
          ...snapshot,
          objects,
          evidenceIds: [...snapshot.evidenceIds, ...evidenceIds],
          freshness: "changed",
          refresh,
        };
        await saveJson(
          join(this.directory, "snapshots", randomUUID() + ".json"),
          next,
        );
        this.snapshot = next;
        return {
          refresh,
          changedPaths,
          freshness: "selected-objects-only",
          atomic: false,
        };
      } catch (e) {
        this.snapshot = undefined;
        throw e;
      }
    });
  }
  private async readPaged(
    path: string,
    call: (action: string, args: any) => Promise<any>,
  ) {
    const parts: Record<string, string> = {
      declaration: "",
      implementation: "",
    };
    let reference: any;
    for (const part of ["declaration", "implementation"]) {
      let cursor = 0;
      do {
        const page = await call("read_page", {
          path,
          part,
          cursor,
          maxChars: 65536,
        });
        if (
          page.path !== path ||
          page.part !== part ||
          page.cursor !== cursor ||
          typeof page.chunk !== "string" ||
          page.chunk.length > 65536 ||
          (page.nextCursor !== null &&
            (!Number.isInteger(page.nextCursor) ||
              page.nextCursor !== cursor + page.chunk.length ||
              page.nextCursor <= cursor))
        )
          throw new AppError(
            "PAGINATION_GAP",
            "Invalid page identity, range or non-advancing cursor",
          );
        if (
          reference &&
          (page.sha256 !== reference.sha256 || page.id !== reference.id)
        )
          throw new AppError(
            "SOURCE_CHANGED",
            "Paged object changed while reading",
          );
        reference = page;
        parts[part] += page.chunk;
        if (Buffer.byteLength(parts[part]) > 32 * 1024 * 1024)
          throw new AppError(
            "SOURCE_TOO_LARGE",
            "Source part exceeds the explicit 32 MiB collection limit; no complete capture is claimed",
          );
        cursor = page.nextCursor;
      } while (cursor !== null);
    }
    if (
      sourceHash(parts.declaration, parts.implementation) !== reference.sha256
    )
      throw new AppError("PAGINATION_GAP", "Paged source hash mismatch");
    return {
      ...reference,
      ...parts,
      text:
        parts.declaration +
        (parts.implementation ? "\n" + parts.implementation : ""),
      complete: true,
    };
  }
  async analyze() {
    const snapshot = this.snapshot;
    if (!snapshot)
      throw new AppError("SNAPSHOT_REQUIRED", "Capture current source first");
    if (
      this.analysisSnapshot !== snapshot ||
      this.analysisContext !== this.contextSnapshot ||
      !this.analysisPromise
    ) {
      this.analysisSnapshot = snapshot;
      this.analysisContext = this.contextSnapshot;
      const context = this.contextSnapshot;
      this.analysisPromise = this.worker
        .run(snapshot.objects)
        .then((result) => {
          if (this.snapshot !== snapshot || this.contextSnapshot !== context)
            throw new AppError(
              "SOURCE_CHANGED",
              "Analysis belongs to an older capture; rerun for current source",
            );
          return this.enrichAnalysis(result);
        });
    }
    try {
      return await this.analysisPromise;
    } catch (e) {
      if (this.analysisSnapshot === snapshot) this.analysisPromise = undefined;
      throw e;
    }
  }
  private enrichAnalysis(result: ReturnType<AnalysisIndex["analyze"]>) {
    if (!this.snapshot)
      throw new AppError("SNAPSHOT_REQUIRED", "Capture current source first");
    const ownership: Record<string, string[]> = {},
      taskGaps: any[] = [];
    const objects = this.snapshot.objects;
    const resolveCall = (name: string) =>
      objects.filter(
        (o) => o.path.split("/").at(-1)?.toLowerCase() === name.toLowerCase(),
      );
    const visit = (objectPath: string, taskPath: string, seen: Set<string>) => {
      if (seen.has(objectPath)) return;
      seen.add(objectPath);
      ownership[objectPath] = [
        ...new Set([...(ownership[objectPath] ?? []), taskPath]),
      ];
      for (const call of result.references.filter(
        (r) => r.path === objectPath && r.access === "call",
      )) {
        const matches = resolveCall(call.expression);
        if (matches.length === 1) visit(matches[0].path, taskPath, seen);
      }
    };
    for (const task of this.contextSnapshot?.tasks ?? [])
      for (const name of task.data?.pous ?? []) {
        const matches = resolveCall(String(name));
        if (matches.length === 1) visit(matches[0].path, task.path, new Set());
        else
          taskGaps.push({
            task: task.path,
            call: name,
            reason:
              "Task POU call unresolved/ambiguous; instance and dynamic dispatch may require manual inspection",
          });
      }
    const writes = result.references.filter(
      (r) =>
        ["write", "possible-write"].includes(r.access) &&
        r.expression.includes("."),
    );
    for (const finding of result.findings.filter(
      (f) => f.rule === "MULTIPLE_WRITERS",
    )) {
      const targets = writes.filter(
        (w) => w.path === finding.path && w.line === finding.line,
      );
      for (const target of targets) {
        const tasks = new Set(
          writes
            .filter(
              (w) =>
                w.expression.toLowerCase() === target.expression.toLowerCase(),
            )
            .flatMap((w) => ownership[w.path] ?? []),
        );
        if (tasks.size > 1)
          finding.message +=
            " Reachable from multiple resolved tasks: " + [...tasks].join(", ");
      }
    }
    return {
      ...result,
      taskOwnership: ownership,
      taskGaps,
      taskContext: this.contextSnapshot
        ? {
            capturedAt: this.contextSnapshot.capturedAt,
            coverage: this.contextSnapshot.coverage,
          }
        : {
            status: "not-read",
            reason:
              "Read task/I/O context before interpreting startup and cross-task behavior",
          },
      sourceFreshness: this.snapshot.freshness,
      sourceVersion: sha256(
        canonicalJson([
          this.snapshot.session,
          this.snapshot.objects.map((o) => [o.path, o.id, o.sha256]),
        ]),
      ),
      capturedAt: this.snapshot.capturedAt,
      refresh: this.snapshot.refresh ?? null,
      atomic: false,
    };
  }
  search(query: string) {
    if (!query || query.length > 256)
      throw new AppError("INVALID_QUERY", "Query length 1..256");
    if (!this.snapshot)
      throw new AppError("SNAPSHOT_REQUIRED", "Capture current source first");
    if (this.searchSnapshot !== this.snapshot) {
      this.searchIndex.update(this.snapshot.objects);
      this.searchSnapshot = this.snapshot;
    }
    return this.searchIndex.search(query);
  }
  async references(query: string) {
    if (!query || query.length > 256)
      throw new AppError("INVALID_QUERY", "Query length 1..256");
    const snapshot = this.snapshot;
    if (!snapshot)
      throw new AppError("SNAPSHOT_REQUIRED", "Capture current source first");
    if (this.referenceSnapshot !== snapshot || !this.referencePromise) {
      this.referenceSnapshot = snapshot;
      this.referencePromise = this.worker.run(snapshot.objects, "references");
    }
    try {
      const refs = await this.referencePromise;
      if (this.snapshot !== snapshot)
        throw new AppError(
          "SOURCE_CHANGED",
          "References belong to an older capture",
        );
      return referencesTo(refs, query);
    } catch (e) {
      if (this.referenceSnapshot === snapshot)
        this.referencePromise = undefined;
      throw e;
    }
  }
}
