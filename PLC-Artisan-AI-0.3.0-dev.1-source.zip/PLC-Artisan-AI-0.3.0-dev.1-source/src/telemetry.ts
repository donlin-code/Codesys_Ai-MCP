import ModbusRTU from "modbus-serial";
import { createRequire } from "node:module";
import {
  OPCUAClient,
  AttributeIds,
  MessageSecurityMode,
  SecurityPolicy,
  ClientSubscription,
  ClientMonitoredItem,
  TimestampsToReturn,
  OPCUACertificateManager,
  UserTokenType,
  type ClientSession,
} from "node-opcua";
import { createHash } from "node:crypto";
import { join } from "node:path";
import { AppError, loadJson, saveJson, SerialQueue } from "./core.js";
const ModbusClient: { new (): import("modbus-serial/ModbusRTU.js").ModbusRTU } =
  createRequire(import.meta.url)("modbus-serial");

export interface Sample {
  point: string;
  value: unknown;
  dataType: string;
  unit?: string;
  variable?: string;
  sourceTimestamp: string | null;
  receivedAt: string;
  quality: string;
  stale: boolean;
}
export interface Point {
  id: string;
  variable?: string;
  unit?: string;
  fc?: 1 | 2 | 3 | 4;
  address?: number;
  addressBase?: "zero" | "reference";
  dataType: "BOOL" | "INT" | "UINT" | "DINT" | "UDINT" | "REAL" | "LREAL";
  byteOrder?: "BE" | "LE";
  wordOrder?: "high-low" | "low-high";
  nodeId?: string;
}
export interface TelemetryConfig {
  id: string;
  protocol: "modbus-tcp" | "opcua";
  host?: string;
  port?: number;
  unitId?: number;
  endpoint?: string;
  intervalMs: number;
  points: Point[];
  securityMode?: "None" | "Sign" | "SignAndEncrypt";
  securityPolicy?: "None" | "Basic256Sha256";
  usernameEnv?: string;
  passwordEnv?: string;
  trustedFingerprint?: string;
}
export const registerCount = (type: Point["dataType"]) =>
  ["DINT", "UDINT", "REAL"].includes(type) ? 2 : type === "LREAL" ? 4 : 1;
export function protocolAddress(p: Point) {
  if (!Number.isInteger(p.address) || !p.fc || ![1, 2, 3, 4].includes(p.fc))
    throw new AppError(
      "POINT_INVALID",
      "Explicit function code and integer address required",
    );
  if (!["zero", "reference"].includes(p.addressBase ?? ""))
    throw new AppError(
      "ADDRESS_BASE_REQUIRED",
      "Specify zero-based or conventional reference address",
    );
  const offset =
    p.addressBase === "reference"
      ? { 1: 1, 2: 10001, 3: 40001, 4: 30001 }[p.fc]
      : 0;
  const address = p.address! - offset;
  if (address < 0 || address + registerCount(p.dataType) > 65536)
    throw new AppError("POINT_INVALID", "Address outside 0..65535");
  return address;
}
export function decodeRegisters(
  words: number[],
  point: Point,
): number | boolean {
  if (!point.byteOrder || !point.wordOrder)
    throw new AppError(
      "ORDER_REQUIRED",
      "Explicit byte and word order required for register data",
    );
  const values = point.wordOrder === "low-high" ? [...words].reverse() : words,
    b = Buffer.alloc(values.length * 2);
  values.forEach((word, i) => b.writeUInt16BE(word, i * 2));
  if (point.byteOrder === "LE") b.swap16();
  const value =
    point.dataType === "BOOL"
      ? b.readUInt16BE() !== 0
      : point.dataType === "INT"
        ? b.readInt16BE()
        : point.dataType === "UINT"
          ? b.readUInt16BE()
          : point.dataType === "DINT"
            ? b.readInt32BE()
            : point.dataType === "UDINT"
              ? b.readUInt32BE()
              : point.dataType === "REAL"
                ? b.readFloatBE()
                : b.readDoubleBE();
  if (typeof value === "number" && !Number.isFinite(value))
    throw new AppError(
      "NON_FINITE",
      "Register data decoded to non-finite floating point",
    );
  return value;
}
export function groupPoints(points: Point[]) {
  const sorted = points
    .map((point) => ({
      point,
      start: protocolAddress(point),
      count: point.fc! <= 2 ? 1 : registerCount(point.dataType),
    }))
    .sort((a, b) => a.point.fc! - b.point.fc! || a.start - b.start);
  const groups: {
    fc: number;
    start: number;
    count: number;
    entries: typeof sorted;
  }[] = [];
  for (const entry of sorted) {
    const last = groups.at(-1),
      end = entry.start + entry.count,
      max = entry.point.fc! <= 2 ? 2000 : 125;
    if (
      last &&
      last.fc === entry.point.fc &&
      entry.start <= last.start + last.count &&
      end - last.start <= max
    ) {
      last.count = Math.max(last.count, end - last.start);
      last.entries.push(entry);
    } else
      groups.push({
        fc: entry.point.fc!,
        start: entry.start,
        count: entry.count,
        entries: [entry],
      });
  }
  return groups;
}
export function validateTelemetry(config: TelemetryConfig) {
  if (
    !/^[A-Za-z0-9_-]{1,64}$/.test(config.id) ||
    !["modbus-tcp", "opcua"].includes(config.protocol) ||
    !Number.isInteger(config.intervalMs) ||
    config.intervalMs < 100 ||
    config.intervalMs > 60000 ||
    !Array.isArray(config.points) ||
    config.points.length > 1000
  )
    throw new AppError(
      "CONFIG_INVALID",
      "Invalid telemetry id, interval or point count",
    );
  if (new Set(config.points.map((p) => p.id)).size !== config.points.length)
    throw new AppError("POINT_INVALID", "Duplicate point identifiers");
  for (const p of config.points) {
    if (
      !/^[A-Za-z0-9_.-]{1,128}$/.test(p.id) ||
      !["BOOL", "INT", "UINT", "DINT", "UDINT", "REAL", "LREAL"].includes(
        p.dataType,
      )
    )
      throw new AppError("POINT_INVALID", "Invalid point type/id");
    if (config.protocol === "modbus-tcp") {
      protocolAddress(p);
      if (p.fc! <= 2 && p.dataType !== "BOOL")
        throw new AppError(
          "POINT_INVALID",
          "Coil/discrete point type must be BOOL",
        );
      if (
        p.fc! >= 3 &&
        (!["BE", "LE"].includes(p.byteOrder ?? "") ||
          !["high-low", "low-high"].includes(p.wordOrder ?? ""))
      )
        throw new AppError(
          "ORDER_REQUIRED",
          "Explicit byte/word order required",
        );
    } else if (!p.nodeId)
      throw new AppError("POINT_INVALID", "Explicit OPC UA NodeId required");
  }
  if (
    config.protocol === "modbus-tcp" &&
    (!config.host ||
      !Number.isInteger(config.port) ||
      config.port! < 1 ||
      config.port! > 65535 ||
      !Number.isInteger(config.unitId) ||
      config.unitId! < 0 ||
      config.unitId! > 255)
  )
    throw new AppError(
      "CONFIG_INVALID",
      "Explicit host, port and unitId required",
    );
  if (config.protocol === "opcua") {
    if (
      !config.endpoint?.startsWith("opc.tcp://") ||
      !["None", "Sign", "SignAndEncrypt"].includes(config.securityMode ?? "") ||
      !["None", "Basic256Sha256"].includes(config.securityPolicy ?? "")
    )
      throw new AppError(
        "CONFIG_INVALID",
        "Explicit endpoint and supported security settings required",
      );
    if ((config.securityMode === "None") !== (config.securityPolicy === "None"))
      throw new AppError("CONFIG_INVALID", "Security mode/policy mismatch");
    if (
      config.securityMode !== "None" &&
      !/^[a-f0-9]{64}$/.test(config.trustedFingerprint ?? "")
    )
      throw new AppError(
        "CERTIFICATE_TRUST_REQUIRED",
        "Discover and explicitly trust the server certificate first",
      );
    if (config.usernameEnv && config.securityMode !== "SignAndEncrypt")
      throw new AppError(
        "CONFIG_INVALID",
        "Username credentials require an encrypted OPC UA channel",
      );
  }
  for (const field of [config.usernameEnv, config.passwordEnv])
    if (field && !/^[A-Za-z_][A-Za-z0-9_]*$/.test(field))
      throw new AppError(
        "CONFIG_INVALID",
        "Credentials must reference environment variables",
      );
  return config;
}
export class TelemetryManager {
  private jobs = new Map<
    string,
    {
      stop: () => Promise<void>;
      samples: Map<string, Sample>;
      history: Sample[];
      state: string;
      error?: string;
      revisedInterval?: number;
      intervalMs: number;
    }
  >();
  constructor(private directory: string) {}
  private file() {
    return join(this.directory, "telemetry.json");
  }
  async configs() {
    return loadJson<TelemetryConfig[]>(this.file(), []);
  }
  async save(config: TelemetryConfig) {
    validateTelemetry(config);
    const all = await this.configs();
    await saveJson(this.file(), [
      ...all.filter((c) => c.id !== config.id),
      config,
    ]);
    return config;
  }
  async discover(endpoint: string) {
    if (!endpoint.startsWith("opc.tcp://"))
      throw new AppError("ENDPOINT_INVALID", "Expected opc.tcp endpoint");
    const client = OPCUAClient.create({
      connectionStrategy: { maxRetry: 0 },
      endpointMustExist: false,
    });
    try {
      await client.connect(endpoint);
      return (await client.getEndpoints()).map((e) => ({
        endpointUrl: e.endpointUrl,
        securityMode: MessageSecurityMode[e.securityMode],
        securityPolicyUri: e.securityPolicyUri,
        fingerprint: e.serverCertificate
          ? createHash("sha256").update(e.serverCertificate).digest("hex")
          : null,
        certificate: e.serverCertificate?.toString("base64"),
      }));
    } finally {
      await client.disconnect();
    }
  }
  async trust(endpoint: string, fingerprint: string) {
    const endpoints = await this.discover(endpoint),
      item = endpoints.find((e) => e.fingerprint === fingerprint);
    if (!item?.certificate)
      throw new AppError(
        "CERTIFICATE_CHANGED",
        "Fingerprint differs from current discovery",
      );
    const manager = new OPCUACertificateManager({
      rootFolder: join(this.directory, "certificates"),
      automaticallyAcceptUnknownCertificate: false,
    });
    try {
      await manager.initialize();
      await manager.trustCertificate(Buffer.from(item.certificate, "base64"));
    } finally {
      await manager.dispose();
    }
    return { trustedFingerprint: fingerprint };
  }
  private async pinnedCertificate(config: TelemetryConfig) {
    if (config.securityMode === "None") return undefined;
    const endpoints = await this.discover(config.endpoint!);
    const selected = endpoints.find(
      (e) =>
        e.securityMode === config.securityMode &&
        e.securityPolicyUri === SecurityPolicy[config.securityPolicy!] &&
        e.fingerprint === config.trustedFingerprint,
    );
    if (!selected?.certificate)
      throw new AppError(
        "CERTIFICATE_CHANGED",
        "Selected security endpoint does not match the explicitly trusted fingerprint",
      );
    return Buffer.from(selected.certificate, "base64");
  }
  private identity(config: TelemetryConfig) {
    const username = config.usernameEnv
      ? process.env[config.usernameEnv]
      : undefined;
    const password = config.passwordEnv
      ? process.env[config.passwordEnv]
      : undefined;
    if (config.usernameEnv && !username)
      throw new AppError(
        "CREDENTIAL_MISSING",
        "OPC UA username environment variable unset",
      );
    if (config.passwordEnv && password === undefined)
      throw new AppError(
        "CREDENTIAL_MISSING",
        "OPC UA password environment variable unset",
      );
    return username
      ? {
          type: UserTokenType.UserName as const,
          userName: username,
          password: password ?? "",
        }
      : { type: UserTokenType.Anonymous as const };
  }
  private async certificateManager(serverCertificate?: Buffer) {
    const manager = new OPCUACertificateManager({
      rootFolder: join(this.directory, "certificates"),
      automaticallyAcceptUnknownCertificate: false,
    });
    try {
      await manager.initialize();
      if (serverCertificate) {
        const status = await manager.checkCertificate(serverCertificate);
        if (!status.isGood())
          throw new AppError(
            "CERTIFICATE_REJECTED",
            "Server certificate validation failed: " + status.toString(),
          );
      }
      return manager;
    } catch (error) {
      await manager.dispose();
      throw error;
    }
  }
  private async withUaSession<T>(
    config: TelemetryConfig,
    operation: (session: ClientSession) => Promise<T>,
  ): Promise<T> {
    if (config.protocol !== "opcua")
      throw new AppError("PROTOCOL_INVALID", "Requires OPC UA");
    validateTelemetry(config);
    const identity = this.identity(config),
      serverCertificate = await this.pinnedCertificate(config);
    const manager = await this.certificateManager(serverCertificate);
    const client = OPCUAClient.create({
      clientCertificateManager: manager,
      serverCertificate,
      securityMode: MessageSecurityMode[config.securityMode!],
      securityPolicy: SecurityPolicy[config.securityPolicy!],
      connectionStrategy: { maxRetry: 0 },
      endpointMustExist: false,
    });
    let session: ClientSession | undefined;
    try {
      await client.connect(config.endpoint!);
      session = await client.createSession(identity);
      return await operation(session);
    } finally {
      try {
        await session?.close();
      } finally {
        try {
          await client.disconnect();
        } finally {
          await manager.dispose();
        }
      }
    }
  }
  async readAttributes(
    config: TelemetryConfig,
    nodes: { nodeId: string; attribute: string }[],
  ) {
    const allowed = [
      "Value",
      "DataType",
      "DisplayName",
      "BrowseName",
      "Description",
      "ValueRank",
      "AccessLevel",
      "UserAccessLevel",
      "MinimumSamplingInterval",
    ];
    if (
      !Array.isArray(nodes) ||
      !nodes.length ||
      nodes.length > 100 ||
      nodes.some((n) => !n.nodeId || !allowed.includes(n.attribute))
    )
      throw new AppError(
        "ATTRIBUTE_INVALID",
        "Select 1..100 nodes and supported read-only attributes",
      );
    return this.withUaSession(config, async (session) => {
      const values = await session.read(
        nodes.map((n) => ({
          nodeId: n.nodeId,
          attributeId: AttributeIds[
            n.attribute as keyof typeof AttributeIds
          ] as number,
        })),
        0,
      );
      return values.map((value, i) => ({
        ...nodes[i],
        value: value.value.value,
        quality: value.statusCode.isGood()
          ? "Good"
          : value.statusCode.toString(),
        sourceTimestamp: value.sourceTimestamp?.toISOString() ?? null,
        receivedAt: new Date().toISOString(),
      }));
    });
  }
  state() {
    return [...this.jobs.entries()].map(([id, job]) => ({
      id,
      state: job.state,
      error: job.error,
      revisedInterval: job.revisedInterval,
      samples: [...job.samples.values()].map((s) => ({
        ...s,
        stale:
          s.stale ||
          Date.now() - Date.parse(s.receivedAt) >
            Math.max(2000, job.intervalMs * 3),
      })),
    }));
  }
  history(id: string) {
    return this.jobs.get(id)?.history ?? [];
  }
  csv(id: string) {
    const quote = (s: unknown) =>
      '"' + String(s ?? "").replace(/"/g, '""') + '"';
    return [
      "point,value,dataType,unit,variable,sourceTimestamp,receivedAt,quality,stale",
      ...this.history(id).map((s) =>
        [
          s.point,
          s.value,
          s.dataType,
          s.unit,
          s.variable,
          s.sourceTimestamp,
          s.receivedAt,
          s.quality,
          s.stale,
        ]
          .map(quote)
          .join(","),
      ),
    ].join("\r\n");
  }
  async stop(id: string) {
    const job = this.jobs.get(id);
    if (job) await job.stop();
  }
  async close() {
    await Promise.all([...this.jobs.values()].map((j) => j.stop()));
  }
  async start(config: TelemetryConfig) {
    validateTelemetry(config);
    await this.stop(config.id);
    let stopped = false,
      timer: ReturnType<typeof setTimeout> | undefined,
      close: () => Promise<void> = async () => {};
    const queue = new SerialQueue();
    const job = {
      stop: async () => {
        stopped = true;
        if (timer) clearTimeout(timer);
        if (config.protocol === "opcua") await close();
        await queue.run(close);
        job.state = "stopped";
        for (const s of job.samples.values()) s.stale = true;
      },
      samples: new Map<string, Sample>(),
      history: [] as Sample[],
      state: "connecting",
      error: undefined as string | undefined,
      revisedInterval: undefined as number | undefined,
      intervalMs: config.intervalMs,
    };
    this.jobs.set(config.id, job);
    const emit = (
      p: Point,
      value: unknown,
      quality: string,
      sourceTimestamp: Date | null = null,
    ) => {
      const sample: Sample = {
        point: p.id,
        value,
        dataType: p.dataType,
        unit: p.unit,
        variable: p.variable,
        sourceTimestamp: sourceTimestamp?.toISOString() ?? null,
        receivedAt: new Date().toISOString(),
        quality,
        stale: quality !== "Good",
      };
      job.samples.set(p.id, sample);
      job.history.push(sample);
      if (job.history.length > 20000)
        job.history.splice(0, job.history.length - 20000);
    };
    let attempt = 0;
    const cycle = async () => {
      if (stopped) return;
      try {
        await queue.run(async () => {
          if (stopped) return;
          if (config.protocol === "modbus-tcp") {
            const client = new ModbusClient();
            client.setTimeout(2000);
            client.setID(config.unitId!);
            close = async () => {
              if (client.isOpen)
                await new Promise<void>((r) => client.close(() => r()));
            };
            try {
              await client.connectTCP(config.host!, { port: config.port! });
              for (const g of groupPoints(config.points)) {
                const result =
                  g.fc === 1
                    ? await client.readCoils(g.start, g.count)
                    : g.fc === 2
                      ? await client.readDiscreteInputs(g.start, g.count)
                      : g.fc === 3
                        ? await client.readHoldingRegisters(g.start, g.count)
                        : await client.readInputRegisters(g.start, g.count);
                for (const e of g.entries)
                  try {
                    const values = result.data.slice(
                      e.start - g.start,
                      e.start - g.start + e.count,
                    );
                    emit(
                      e.point,
                      g.fc <= 2
                        ? values[0]
                        : decodeRegisters(values as number[], e.point),
                      "Good",
                    );
                  } catch (error) {
                    emit(
                      e.point,
                      null,
                      (error as AppError).code ?? "DecodeError",
                    );
                  }
              }
            } finally {
              await close();
            }
          } else {
            const serverCertificate = await this.pinnedCertificate(config);
            const manager = await this.certificateManager(serverCertificate);
            const client = OPCUAClient.create({
              clientCertificateManager: manager,
              serverCertificate,
              securityMode: MessageSecurityMode[config.securityMode!],
              securityPolicy: SecurityPolicy[config.securityPolicy!],
              connectionStrategy: { maxRetry: 0 },
              endpointMustExist: false,
            });
            let session: any,
              subscription: any,
              cleanup: Promise<void> | undefined;
            close = () =>
              (cleanup ??= (async () => {
                await subscription?.terminate().catch(() => {});
                await session?.close().catch(() => {});
                await client.disconnect().catch(() => {});
                await manager.dispose();
              })());
            try {
              await client.connect(config.endpoint!);
              if (stopped) return;
              session = await client.createSession(this.identity(config));
              if (stopped) return;
              subscription = ClientSubscription.create(session, {
                requestedPublishingInterval: config.intervalMs,
                requestedLifetimeCount: 100,
                requestedMaxKeepAliveCount: 10,
                maxNotificationsPerPublish: 1000,
                publishingEnabled: true,
                priority: 1,
              });
              await new Promise<void>((resolve, reject) => {
                subscription.once("started", resolve);
                subscription.once("error", reject);
              });
              job.revisedInterval = subscription.publishingInterval;
              for (const p of config.points) {
                const item = ClientMonitoredItem.create(
                  subscription,
                  { nodeId: p.nodeId!, attributeId: AttributeIds.Value },
                  {
                    samplingInterval: config.intervalMs,
                    discardOldest: true,
                    queueSize: 10,
                  },
                  TimestampsToReturn.Both,
                );
                item.on("changed", (value) =>
                  emit(
                    p,
                    value.value.value,
                    value.statusCode.isGood()
                      ? "Good"
                      : value.statusCode.toString(),
                    value.sourceTimestamp ?? null,
                  ),
                );
                item.on("err", () => emit(p, null, "MonitorError"));
              }
              job.state = "connected";
              job.error = undefined;
              // Let subscription notifications run until connection closes or user stops.
              await new Promise<void>((resolve) => {
                const previousClose = close;
                close = async () => {
                  await previousClose();
                  resolve();
                };
                client.once("connection_lost", resolve);
                subscription.once("terminated", resolve);
              });
              if (!stopped)
                throw new AppError(
                  "CONNECTION_LOST",
                  "OPC UA subscription ended",
                );
            } finally {
              await close();
            }
          }
        });
        attempt = 0;
        job.state = stopped ? "stopped" : "connected";
        job.error = undefined;
      } catch (e) {
        job.state = "disconnected";
        job.error = (e as Error).message;
        attempt++;
        for (const s of job.samples.values()) {
          s.stale = true;
          s.quality = "ConnectionError";
        }
      }
      if (!stopped)
        timer = setTimeout(
          cycle,
          attempt
            ? Math.min(30000, 500 * 2 ** Math.min(attempt, 6))
            : config.intervalMs,
        );
    };
    void cycle();
    return { id: config.id, state: job.state };
  }
  async browse(config: TelemetryConfig, nodeId = "RootFolder") {
    return this.withUaSession(config, async (session) => {
      const pages: any[] = [];
      let result = await session.browse({ nodeId, resultMask: 63 });
      while (true) {
        pages.push(
          ...(result.references ?? []).map((r: any) => ({
            nodeId: r.nodeId.toString(),
            browseName: r.browseName.toString(),
            displayName: r.displayName.text,
            nodeClass: r.nodeClass,
          })),
        );
        if (!result.continuationPoint?.length) break;
        if (pages.length >= 10000) {
          await session.browseNext(result.continuationPoint, true);
          throw new AppError(
            "BROWSE_LIMIT",
            "More than 10000 references; select a narrower node",
          );
        }
        result = await session.browseNext(result.continuationPoint, false);
      }
      return { nodeId, references: pages, complete: true };
    });
  }
}
