import type { SourceObject } from "./st-analysis.js";
import { sourceHash } from "./core.js";

// Each object is indexed independently. Removed and renamed objects cannot leave stale hits.
export class SourceSearch {
  private objects = new Map<
    string,
    {
      hash: string;
      rows: {
        path: string;
        part: "declaration" | "implementation";
        line: number;
        text: string;
        lower: string;
        sha256: string;
      }[];
    }
  >();
  update(objects: SourceObject[]) {
    const live = new Set(objects.map((o) => o.path));
    for (const path of this.objects.keys())
      if (!live.has(path)) this.objects.delete(path);
    for (const o of objects) {
      const hash = sourceHash(o.declaration, o.implementation);
      if (this.objects.get(o.path)?.hash === hash) continue;
      const rows = (["declaration", "implementation"] as const).flatMap(
        (part) =>
          o[part]
            .split("\n")
            .map((text, i) => ({
              path: o.path,
              part,
              line: i + 1,
              text,
              lower: text.toLowerCase(),
              sha256: hash,
            })),
      );
      this.objects.set(o.path, { hash, rows });
    }
  }
  search(query: string, limit = 500) {
    const target = query.toLowerCase(),
      result = [];
    for (const { rows } of this.objects.values())
      for (const row of rows) {
        if (!row.lower.includes(target)) continue;
        const { lower, ...match } = row;
        result.push(match);
        if (result.length === limit) return result;
      }
    return result;
  }
}
