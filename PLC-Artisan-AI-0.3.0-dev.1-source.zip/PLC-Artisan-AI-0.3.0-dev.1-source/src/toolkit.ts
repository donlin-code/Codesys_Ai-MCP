import { z } from "zod";
import type { EngineeringService } from "./engineering.js";
import type { TelemetryManager } from "./telemetry.js";
import { AppError } from "./core.js";
import {
  standards,
  targetProfile,
  domainGuidance,
  generationContract,
} from "./standards.js";

const path = z.string().min(1).max(8192),
  hash = z.string().regex(/^[a-f0-9]{64}$/),
  id = z.string().uuid(),
  source = z
    .string()
    .max(2 * 1024 * 1024)
    .refine((s) => !s.includes("\0"));
const writeSource = { declaration: source, implementation: source };
const createFields = {
  parentPath: path,
  name: z.string().regex(/^[A-Za-z_][A-Za-z0-9_]*$/),
  kind: z.enum([
    "PROGRAM",
    "FUNCTION_BLOCK",
    "FUNCTION",
    "GVL",
    "DUT",
    "METHOD",
    "ACTION",
    "INTERFACE",
    "PROPERTY",
  ]),
  ...writeSource,
  dutKind: z.enum(["Structure", "Enumeration", "Alias", "Union"]).optional(),
  returnType: z.string().max(128).optional(),
  baseType: z.string().max(128).optional(),
};
const definitions = [
  [
    "codesys_refresh",
    "Reread 1..25 captured objects twice; other objects retain their earlier observation time. Not an atomic or full refresh.",
    z.object({ paths: z.array(path).min(1).max(25) }),
    true,
  ],
  [
    "codesys_status",
    "Connection, identity, pending writes and adapter validation status",
    z.object({}),
    true,
  ],
  [
    "codesys_project_info",
    "Read bound isolated IDE project identity and dirty state",
    z.object({}),
    true,
  ],
  [
    "codesys_capabilities",
    "Actual adapter capabilities; unverified kinds are disabled",
    z.object({}),
    true,
  ],
  [
    "codesys_list_objects",
    "Read project tree including unsupported and nontext objects",
    z.object({}),
    true,
  ],
  [
    "codesys_read_object",
    "Read exact declaration and implementation from a single object",
    z.object({ path }),
    true,
  ],
  [
    "codesys_read_objects",
    "Read at most 25 objects with per-object completeness and pagination markers",
    z.object({ paths: z.array(path).min(1).max(25) }),
    true,
  ],
  [
    "codesys_read_page",
    "Read bounded source page; verify identity and final source hash",
    z.object({
      path,
      part: z.enum(["declaration", "implementation"]),
      cursor: z.number().int().nonnegative(),
      maxChars: z.number().int().min(2).max(65536).default(65536),
    }),
    true,
  ],
  [
    "codesys_context",
    "Read available task, library, device and I/O configuration with explicit coverage gaps",
    z.object({}),
    true,
  ],
  [
    "codesys_snapshot",
    "Capture scoped full source with second-pass freshness verification; not an atomic snapshot",
    z.object({
      applicationPath: path,
      roots: z.array(path).optional(),
      paths: z.array(path).optional(),
      kinds: z.array(z.string()).optional(),
    }),
    true,
  ],
  [
    "codesys_analyze",
    "Conservative static findings and source coverage gaps from the captured snapshot",
    z.object({}),
    true,
  ],
  [
    "codesys_search",
    "Search local captured source; returns bounded exact excerpts",
    z.object({ query: z.string().min(1).max(256) }),
    true,
  ],
  [
    "codesys_references",
    "Find direct and potential indirect variable references; not proof of absence of aliases",
    z.object({ query: z.string().min(1).max(256) }),
    true,
  ],
  [
    "codesys_generation_rules",
    "Language, vendor capability and style rules plus applicable standards catalogue; not certification",
    z.object({ languageEdition: z.enum(["2013", "2025"]).optional() }),
    true,
  ],
  [
    "codesys_check_st",
    "Check a source draft without writing IDE code",
    z.object({
      path,
      ...writeSource,
      languageEdition: z.enum(["2013", "2025"]).optional(),
    }),
    true,
  ],
  [
    "codesys_format_st",
    "Return conservative formatting preview; preserves literal/comment/pragma text and refuses unsupported syntax",
    z.object({ text: source }),
    true,
  ],
  [
    "codesys_batch_prepare",
    "Prepare immutable batch and actual diff from live baselines; human approves separately in browser",
    z.object({
      applicationPath: path,
      operations: z
        .array(
          z.discriminatedUnion("action", [
            z.object({
              action: z.literal("replace_st"),
              args: z.object({ path, ...writeSource }).strict(),
            }),
            z.object({
              action: z.literal("create_st"),
              args: z.object(createFields).strict(),
            }),
          ]),
        )
        .min(1)
        .max(100),
    }),
    true,
  ],
  [
    "codesys_batch_status",
    "Read a batch, exact plan hash, diff and per-operation evidence states",
    z.object({ batchId: id }),
    true,
  ],
  [
    "codesys_batch_execute",
    "Execute exactly the next human-approved operation; no automatic retry, save or runtime operation",
    z.object({ batchId: id, operationId: id }),
    false,
  ],
  [
    "codesys_replace_st",
    "Requires matching approved batch and operation plus exact approved parameters; rereads then writes once",
    z.object({
      batchId: id,
      operationId: id,
      path,
      expectedSha256: hash,
      expectedObjectId: z.string().max(256).optional(),
      ...writeSource,
    }),
    false,
  ],
  [
    "codesys_create_st",
    "Requires exact approved batch; creation kinds remain gated by native IDE validation",
    z.object({
      batchId: id,
      operationId: id,
      expectedChildrenSha256: hash,
      expectedParentId: z.string().max(256).optional(),
      ...createFields,
    }),
    false,
  ],
  [
    "codesys_compile",
    "Full Application rebuild; changes IDE build/messages state; no save, PLC login or runtime operation",
    z.object({
      applicationPath: path,
      fullBuild: z.literal(true),
      batchId: id.optional(),
    }),
    false,
  ],
  [
    "codesys_reconcile_write",
    "Resolve an unknown write from terminal transport evidence and fresh readback; never repeats the mutation",
    z.object({
      batchId: id,
      operationId: id,
      requestId: id,
      observedSha256: hash,
    }),
    true,
  ],
  [
    "codesys_telemetry_read",
    "Read configured Modbus TCP/OPC UA sampled values with quality, timestamps and freshness",
    z.object({}),
    true,
  ],
  [
    "codesys_telemetry_history",
    "Read bounded local telemetry history; no device write capability",
    z.object({ connectionId: z.string().max(64) }),
    true,
  ],
] as const;
export const toolkitTools = definitions.map(
  ([name, description, schema, readOnly]) => ({
    name,
    description,
    schema: schema.strict(),
    readOnly,
  }),
);
export const publicTools = toolkitTools.map(
  ({ name, description, schema, readOnly }) => ({
    name,
    description,
    inputSchema: z.toJSONSchema(schema),
    annotations: {
      readOnlyHint: readOnly,
      destructiveHint: !readOnly,
      idempotentHint: readOnly,
      openWorldHint: false,
    },
  }),
);
export function toolsForProfile(profile: string = "core") {
  if (!["core", "full"].includes(profile))
    throw new AppError("INVALID_PROFILE", "Use core or full");
  const optional = new Set([
    "codesys_replace_st",
    "codesys_create_st",
    "codesys_telemetry_read",
    "codesys_telemetry_history",
  ]);
  return profile === "full"
    ? publicTools
    : publicTools.filter((t) => !optional.has(t.name));
}

export async function invokeTool(
  service: EngineeringService,
  telemetry: Pick<TelemetryManager, "state" | "history">,
  name: string,
  input: unknown,
) {
  const tool = toolkitTools.find((t) => t.name === name);
  if (!tool) throw new AppError("UNKNOWN_TOOL", "Unknown tool");
  const args = tool.schema.parse(input ?? {}) as Record<string, any>;
  const simple: Record<string, string> = {
    codesys_project_info: "project_info",
    codesys_list_objects: "list",
    codesys_read_object: "read",
    codesys_read_objects: "read_many",
    codesys_read_page: "read_page",
    codesys_context: "context",
    codesys_capabilities: "capabilities",
  };
  if (simple[name]) return service.read(simple[name], args);
  switch (name) {
    case "codesys_refresh":
      return service.refreshSources(args.paths);
    case "codesys_status":
      return service.status();
    case "codesys_snapshot": {
      const { applicationPath, ...filters } = args;
      return service.capture(applicationPath, filters);
    }
    case "codesys_analyze":
      return service.analyze();
    case "codesys_search":
      return service.search(args.query);
    case "codesys_references":
      return service.references(args.query);
    case "codesys_generation_rules":
      return {
        profile: targetProfile(args.languageEdition),
        standards,
        domainGuidance,
        contract: generationContract(targetProfile(args.languageEdition)),
      };
    case "codesys_check_st":
      return new (await import("./st-analysis.js")).AnalysisIndex().analyze(
        [{ ...args, sha256: "" } as any],
        targetProfile(args.languageEdition),
      );
    case "codesys_format_st":
      return (await import("./st-analysis.js")).formatST(args.text);
    case "codesys_batch_prepare":
      return service.prepare(args.applicationPath, args.operations);
    case "codesys_batch_status":
      return service.getBatch(args.batchId);
    case "codesys_batch_execute":
      return service.execute(args.batchId, args.operationId);
    case "codesys_replace_st":
    case "codesys_create_st": {
      const { batchId, operationId, ...submitted } = args;
      return service.execute(batchId, operationId, {
        action: name === "codesys_replace_st" ? "replace_st" : "create_st",
        args: submitted,
      });
    }
    case "codesys_compile":
      return service.compile(args.applicationPath, args.batchId);
    case "codesys_reconcile_write":
      return service.reconcileBatch(
        args.batchId,
        args.operationId,
        args.requestId,
        args.observedSha256,
      );
    case "codesys_telemetry_read":
      return telemetry.state();
    case "codesys_telemetry_history":
      return telemetry.history(args.connectionId);
    default:
      throw new AppError("UNKNOWN_TOOL", name);
  }
}
