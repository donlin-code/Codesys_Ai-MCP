import { AppError, sourceHash, sha256 } from "./core.js";
import type { SourceObject } from "./st-analysis.js";

export interface RegressionSpec {
  version: 1;
  name: string;
  model: "cylinder" | "initialization" | "axis-handshake";
  cycleMs: number;
  bindings: { path: string; sha256: string }[];
  assumptions: string[];
  steps: {
    inputs: Record<string, boolean>;
    scans: number;
    expect: Record<string, unknown>;
  }[];
}
export interface ModelState {
  state: string;
  elapsedMs: number;
  extend: boolean;
  retract: boolean;
  pump: boolean;
  trigger: boolean;
  home: boolean;
  move: boolean;
  done: boolean;
  fault: boolean;
  entered: boolean;
}
export function initialState(): ModelState {
  return {
    state: "idle",
    elapsedMs: 0,
    extend: false,
    retract: false,
    pump: false,
    trigger: false,
    home: false,
    move: false,
    done: false,
    fault: false,
    entered: true,
  };
}
export function scanModel(
  kind: RegressionSpec["model"],
  previous: ModelState,
  input: Record<string, boolean>,
  cycleMs: number,
): ModelState {
  const s = { ...previous, entered: false };
  s.elapsedMs += cycleMs;
  function enter(state: string) {
    s.state = state;
    s.elapsedMs = 0;
    s.entered = true;
    s.done = false;
  }
  if (input.fault) {
    enter("fault");
    s.fault = true;
  }
  if (s.fault || s.state === "fault") {
    s.extend = s.retract = s.home = s.move = s.pump = s.trigger = false;
    if (input.reset && !input.fault) {
      s.fault = false;
      enter("idle");
    }
    return s;
  }
  if (input.stop || input.enabled === false) {
    enter("idle");
    s.extend = s.retract = s.home = s.move = s.pump = s.trigger = false;
    return s;
  }
  if (kind === "cylinder") {
    if (s.state === "idle" && input.extend && !input.retract)
      enter("extending");
    else if (s.state === "idle" && input.retract && !input.extend)
      enter("retracting");
    s.extend = s.state === "extending";
    s.retract = s.state === "retracting";
    if ((s.extend && input.extended) || (s.retract && input.retracted)) {
      enter("done");
      s.done = true;
      s.extend = s.retract = false;
    } else if ((s.extend || s.retract) && s.elapsedMs >= 5000) {
      enter("fault");
      s.fault = true;
      s.extend = s.retract = false;
    }
    if (
      previous.state === "done" &&
      s.state === "done" &&
      !input.extend &&
      !input.retract
    )
      enter("idle");
  } else if (kind === "initialization") {
    s.pump = s.trigger = false;
    if (s.state === "idle" && input.start) enter("clear");
    else if (s.state === "clear") enter("homing");
    else if (s.state === "homing" && input.homeDone) enter("positioning");
    else if (s.state === "positioning" && input.positionDone) {
      enter("done");
      s.done = true;
    }
    s.home = s.state === "homing";
    s.move = s.state === "positioning";
    if (["homing", "positioning"].includes(s.state) && s.elapsedMs >= 30000) {
      enter("fault");
      s.fault = true;
      s.home = s.move = false;
    }
  } else {
    if (s.state === "idle" && input.home) enter("homing");
    else if (s.state === "idle" && input.move && input.homed)
      enter("positioning");
    else if (s.state === "homing" && input.homeDone) {
      enter("done");
      s.done = true;
    } else if (s.state === "positioning" && input.positionDone) {
      enter("done");
      s.done = true;
    }
    if (
      previous.state === "done" &&
      s.state === "done" &&
      !input.home &&
      !input.move
    )
      enter("idle");
    s.home = s.state === "homing";
    s.move = s.state === "positioning";
    if (["homing", "positioning"].includes(s.state) && s.elapsedMs >= 30000) {
      enter("fault");
      s.fault = true;
      s.home = s.move = false;
    }
  }
  return s;
}
export function runRegression(spec: RegressionSpec, sources: SourceObject[]) {
  if (
    spec.version !== 1 ||
    !["cylinder", "initialization", "axis-handshake"].includes(spec.model) ||
    !Number.isInteger(spec.cycleMs) ||
    spec.cycleMs < 1 ||
    spec.cycleMs > 1000 ||
    !spec.bindings.length ||
    !spec.assumptions.length ||
    spec.steps.length > 1000
  )
    throw new AppError(
      "REGRESSION_INVALID",
      "Specify model, cycle, source bindings, assumptions and bounded steps",
    );
  const stale = spec.bindings.filter(
    (b) => sources.find((o) => o.path === b.path)?.sha256 !== b.sha256,
  );
  if (stale.length)
    return {
      status: "stale",
      evidence: "offline-model",
      stale,
      executed: false,
      plcSimulation: false,
    };
  let state = initialState(),
    scan = 0;
  const results = [];
  for (const step of spec.steps) {
    if (
      !Number.isInteger(step.scans) ||
      step.scans < 1 ||
      step.scans > 100000 ||
      scan + step.scans > 1000000 ||
      Object.values(step.inputs).some((v) => typeof v !== "boolean")
    )
      throw new AppError("REGRESSION_INVALID", "Invalid scan count or input");
    for (let n = 0; n < step.scans; n++) {
      state = scanModel(spec.model, state, step.inputs, spec.cycleMs);
      scan++;
    }
    const failures = Object.entries(step.expect)
      .filter(
        ([key, value]) => !(key in state) || (state as any)[key] !== value,
      )
      .map(([key, expected]) => ({
        key,
        expected,
        actual: (state as any)[key],
      }));
    results.push({
      scan,
      timeMs: scan * spec.cycleMs,
      state: { ...state },
      passed: failures.length === 0,
      failures,
    });
  }
  return {
    status: results.every((r) => r.passed) ? "passed" : "failed",
    evidence: "offline-model",
    executed: true,
    plcSimulation: false,
    model: spec.model,
    assumptions: spec.assumptions,
    bindings: spec.bindings,
    results,
    limits:
      "Deterministic model only; not arbitrary ST execution, servo physics or proof of source equivalence.",
  };
}
export function defaultScenarios(
  model: RegressionSpec["model"],
  sources: SourceObject[],
): RegressionSpec {
  const steps: RegressionSpec["steps"] =
    model === "cylinder"
      ? [
          {
            inputs: { extend: true },
            scans: 1,
            expect: {
              state: "extending",
              extend: true,
              retract: false,
              entered: true,
            },
          },
          {
            inputs: { extended: true },
            scans: 1,
            expect: { state: "done", done: true },
          },
          {
            inputs: { stop: true },
            scans: 1,
            expect: { state: "idle", extend: false, retract: false },
          },
          {
            inputs: { retract: true },
            scans: 1,
            expect: { state: "retracting", retract: true },
          },
          { inputs: {}, scans: 1251, expect: { state: "fault", fault: true } },
          {
            inputs: { reset: true },
            scans: 1,
            expect: { state: "idle", fault: false },
          },
        ]
      : model === "initialization"
        ? [
            {
              inputs: { start: true },
              scans: 1,
              expect: { state: "clear", pump: false, trigger: false },
            },
            { inputs: {}, scans: 1, expect: { state: "homing", home: true } },
            {
              inputs: { homeDone: true },
              scans: 1,
              expect: { state: "positioning", move: true },
            },
            {
              inputs: { positionDone: true },
              scans: 1,
              expect: { state: "done", done: true, move: false },
            },
          ]
        : [
            {
              inputs: { home: true, move: true },
              scans: 1,
              expect: { state: "homing", home: true, move: false },
            },
            {
              inputs: { stop: true },
              scans: 1,
              expect: { state: "idle", home: false, move: false },
            },
            {
              inputs: { move: true, homed: true },
              scans: 1,
              expect: { state: "positioning", move: true },
            },
            {
              inputs: { fault: true },
              scans: 1,
              expect: { state: "fault", fault: true, move: false },
            },
            {
              inputs: { reset: true },
              scans: 1,
              expect: { state: "idle", fault: false },
            },
          ];
  return {
    version: 1,
    name: model + "-reference-scenarios",
    model,
    cycleMs: 4,
    bindings: sources.map((o) => ({ path: o.path, sha256: o.sha256 })),
    assumptions: [
      "Reference contract must be compared with the bound ST before interpreting results",
      "4 ms scan; abstract Done/fault signals; no physical I/O or servo dynamics",
    ],
    steps,
  };
}
export function importManualEvidence(
  spec: RegressionSpec,
  sources: SourceObject[],
  record: {
    source: string;
    ideVersion: string;
    project: string;
    simulation: boolean;
    cycleMs: number;
    observations: { scan: number; values: Record<string, unknown> }[];
    attachments: { path: string; sha256: string }[];
  },
) {
  if (
    !record.source ||
    !record.ideVersion ||
    !record.project ||
    !record.simulation ||
    record.cycleMs !== spec.cycleMs ||
    !record.observations?.length ||
    !record.attachments?.length ||
    record.attachments.some((a) => !/^[a-f0-9]{64}$/.test(a.sha256))
  )
    throw new AppError(
      "EVIDENCE_INCOMPLETE",
      "IDE simulation requires identity, matching cycle, observations and hashed evidence attachments",
    );
  const stale = spec.bindings.some(
    (b) => sources.find((o) => o.path === b.path)?.sha256 !== b.sha256,
  );
  let scan = 0;
  const checks = spec.steps.map((step) => {
    scan += step.scans;
    const observed = record.observations.find((r) => r.scan === scan);
    return {
      scan,
      observed,
      passed:
        !!observed &&
        Object.entries(step.expect).every(([k, v]) => observed.values[k] === v),
    };
  });
  return {
    evidence: "human-reported-ide-simulation",
    independentExecutionVerified: false,
    status: stale
      ? "stale"
      : checks.every((c) => c.passed)
        ? "passed-as-reported"
        : "failed-or-incomplete",
    record,
    checks,
    bindings: spec.bindings,
  };
}
export function ideHarness(spec: RegressionSpec) {
  const inputs = [...new Set(spec.steps.flatMap((s) => Object.keys(s.inputs)))];
  const observed = [
    ...new Set(spec.steps.flatMap((s) => Object.keys(s.expect))),
  ];
  const literal = (v: unknown): string =>
    typeof v === "boolean"
      ? v
        ? "TRUE"
        : "FALSE"
      : typeof v === "number" && Number.isFinite(v)
        ? String(v)
        : typeof v === "string"
          ? "'" +
            v
              .replaceAll("$", () => "$$")
              .replaceAll("'", () => "$'")
              .replaceAll("\r", "$R")
              .replaceAll("\n", "$N") +
            "'"
          : (() => {
              throw new AppError(
                "HARNESS_INVALID",
                "Only boolean, finite numeric and string expectations are supported",
              );
            })();
  const wiring = {
    inputs: inputs.map((key, i) => ({
      key,
      variable: "xInput" + i,
      type: "BOOL",
    })),
    observations: observed.map((key, i) => {
      const values = spec.steps
        .filter((s) => key in s.expect)
        .map((s) => s.expect[key]);
      if (new Set(values.map((v) => typeof v)).size !== 1)
        throw new AppError(
          "HARNESS_INVALID",
          "Observation types differ between steps",
        );
      return {
        key,
        variable: "vObserved" + i,
        type:
          typeof values[0] === "boolean"
            ? "BOOL"
            : typeof values[0] === "number"
              ? "LREAL"
              : "STRING(255)",
      };
    }),
  };
  let total = 0;
  const steps = spec.steps.map((s) => ({ ...s, lastScan: (total += s.scans) }));
  const drive =
    steps
      .map(
        (s, i) =>
          `${i ? "ELSIF" : "IF"} udiScan <= ${s.lastScan} THEN\n${wiring.inputs.map((v) => `    ${v.variable} := ${literal(s.inputs[v.key] ?? v.key === "enabled")};`).join("\n")}`,
      )
      .join("\n") + "\nEND_IF;";
  const assertions = steps
    .map(
      (s) =>
        `    ${s.lastScan}:\n        xObservationReady := TRUE;\n        IF NOT (${
          Object.entries(s.expect)
            .map(
              ([key, v]) =>
                `${wiring.observations.find((o) => o.key === key)!.variable} = ${literal(v)}`,
            )
            .join(" AND ") || "TRUE"
        }) THEN\n            xFailed := TRUE;\n            udiFailedAt := udiScan;\n        END_IF;`,
    )
    .join("\n");
  return {
    declaration: `PROGRAM PRG_McpRegression\nVAR\n    xRun : BOOL;\n    xWiringVerified : BOOL;\n    udiScan : UDINT;\n    udiFailedAt : UDINT;\n    xObservationReady : BOOL;\n    xComplete : BOOL;\n    xFailed : BOOL;\n${[...wiring.inputs, ...wiring.observations].map((v) => `    ${v.variable} : ${v.type};`).join("\n")}\nEND_VAR\n`,
    implementation: `(* 人工配置隔离仿真任务：${spec.cycleMs} ms。不得映射物理 I/O。 *)\n(* 按 wiring 表接线并审阅被测 FB 的每周期调用后，才允许 xWiringVerified。 *)\nIF NOT xRun OR NOT xWiringVerified THEN\n    udiScan := 0;\n    xComplete := FALSE;\n    xFailed := FALSE;\n    xObservationReady := FALSE;\n    RETURN;\nEND_IF;\nIF xComplete OR xFailed THEN\n    RETURN;\nEND_IF;\nudiScan := udiScan + 1;\nxObservationReady := FALSE;\n${drive}\n\n(* 接线位置：将 xInputN 连接至隔离被测实例，调用一次，再采集 vObservedN。 *)\n(* 此处必须由操作者补齐真实接口调用；当前模板未调用用户设备。 *)\n\nCASE udiScan OF\n${assertions}\nEND_CASE;\nxComplete := udiScan >= ${total};\n`,
    wiring,
    scenarios: spec.steps,
    needsWiring: true,
    automaticSimulation: false,
  };
}
