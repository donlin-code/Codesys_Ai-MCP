export type StandardDomain =
  | "language"
  | "exchange"
  | "guidance"
  | "fieldbus"
  | "opcua"
  | "safety"
  | "integration"
  | "security";
export const standards = [
  [
    "IEC 61131-3",
    "language",
    "ST language, types and program organization; default 2013-compatible target",
  ],
  [
    "GB/T 15969.3-2017",
    "language",
    "2013-compatible Chinese language baseline",
  ],
  [
    "IEC 61131-10",
    "exchange",
    "Supported PLCopen XML elements; vendor objects require explicit capability",
  ],
  [
    "IEC 61131-8",
    "guidance",
    "Implementation guidance; recommendations are not language syntax requirements",
  ],
  [
    "PLCopen Motion Control",
    "guidance",
    "Target library signatures and cyclic command/status contracts",
  ],
  [
    "IEC 61158",
    "fieldbus",
    "Fieldbus families require the actual controller, device and protocol profile",
  ],
  [
    "IEC 61784",
    "fieldbus",
    "Communication profiles; no assumed cycle time or vendor compatibility",
  ],
  [
    "IEC 62541",
    "opcua",
    "OPC UA identity, security, data types, status and timestamps",
  ],
  [
    "IEC 61508",
    "safety",
    "Safety lifecycle and evidence; ordinary ST checks do not certify safety functions",
  ],
  [
    "IEC 62061",
    "safety",
    "Machine safety control design requires a validated safety platform",
  ],
  [
    "ISO 13849-1",
    "safety",
    "Required performance level and architecture require separate assessment",
  ],
  [
    "IEC 61784-3",
    "safety",
    "Certified safety communication profile, not ordinary Modbus/UA data access",
  ],
  [
    "IEC 62264",
    "integration",
    "Enterprise/control integration context and information boundaries",
  ],
  [
    "IEC 61512",
    "integration",
    "Batch/equipment/procedural models where the application uses them",
  ],
  [
    "IEC 62714",
    "integration",
    "AutomationML exchange context; not native project compatibility",
  ],
  [
    "IEC 62443",
    "security",
    "Least privilege, local access, secrets, trust and audit controls",
  ],
  [
    "IEC 61499",
    "guidance",
    "Separate distributed/event architecture; not silently substituted for cyclic ST",
  ],
  [
    "IEC 60559",
    "language",
    "Floating-point precision and non-finite value handling",
  ],
  [
    "ISO/IEC 10646",
    "language",
    "Character encoding must match the target compiler",
  ],
].map(([id, domain, purpose]) => ({
  id,
  domain: domain as StandardDomain,
  purpose,
  source:
    "Bibliographic reference; verify applicable edition against licensed text and vendor documentation",
  certification: false,
}));
export interface TargetProfile {
  id: string;
  languageEdition: "2013" | "2025";
  verifiedFeatures: string[];
  naming: "preserve";
  indent: 4;
}
export const defaultProfile: TargetProfile = {
  id: "iec2013-codesys-sp20",
  languageEdition: "2013",
  verifiedFeatures: [],
  naming: "preserve",
  indent: 4,
};
export function targetProfile(
  edition: "2013" | "2025" = "2013",
): TargetProfile {
  return edition === "2013"
    ? defaultProfile
    : {
        ...defaultProfile,
        id: "iec2025-sp20-capability-preview",
        languageEdition: "2025",
        verifiedFeatures: [],
      };
}
export const domainGuidance = [
  {
    domain: "language",
    standards: ["IEC 61131-3", "GB/T 15969.3-2017", "IEC 61131-8"],
    checks:
      "Confirm compiler edition, task cycle, variable lifetime, explicit units and library interfaces. Preserve scan semantics and expose unsupported syntax.",
    verification:
      "Static rules plus target IDE full build; behavior requires regression.",
  },
  {
    domain: "exchange",
    standards: ["IEC 61131-10", "IEC 62714"],
    checks:
      "Declare supported XML elements and vendor extensions. Do not infer lossless import, native project compatibility or AutomationML support from text search.",
    verification: "Round-trip evidence for each supported object type.",
  },
  {
    domain: "fieldbus",
    standards: ["IEC 61158", "IEC 61784"],
    checks:
      "Require actual controller, device identity, communication profile, process-data mapping, cycle and watchdog settings. Handle lost communication and stale data explicitly; do not invent mappings.",
    verification:
      "Vendor configuration and device tests; catalogue only, no fieldbus driver supplied.",
  },
  {
    domain: "opcua",
    standards: ["IEC 62541"],
    checks:
      "Require endpoint, NodeId, type, quality, source timestamp and certificate trust. Use selected security policy and distinguish stale or bad values from valid process state.",
    verification: "Local protocol tests; real endpoint acceptance is separate.",
  },
  {
    domain: "safety",
    standards: ["IEC 61508", "IEC 62061", "ISO 13849-1", "IEC 61784-3"],
    checks:
      "Identify safety functions and validated safety controller, I/O and protocol. Ordinary ST, stop commands, Modbus and general UA telemetry must not be presented as a certified safety channel. Require separate safety requirements and evidence.",
    verification:
      "Qualified safety assessment outside this toolkit; never infer SIL/PL or certification.",
  },
  {
    domain: "integration",
    standards: ["IEC 62264", "IEC 61512", "IEC 62714"],
    checks:
      "Confirm equipment hierarchy, unit/procedure ownership, command/status contracts and system boundaries before generating integration code. Apply batch models only when relevant.",
    verification: "Project interface review and integration scenarios.",
  },
  {
    domain: "security",
    standards: ["IEC 62443"],
    checks:
      "Use least privilege, explicit trust, secret isolation, local access control and audit trails. Confirm zones/conduits and deployment requirements with the project; no arbitrary network scanning or runtime writes.",
    verification:
      "Tool access-control tests are implementation evidence, not system certification.",
  },
] as const;
export function generationContract(
  profile: TargetProfile = defaultProfile,
): string {
  return `Generate Structured Text for ${profile.id}. IEC 61131-3:${profile.languageEdition}; preserve existing external names and interfaces. Four-space indentation, uppercase keywords, explicit types, units and Chinese intent comments. Use simple CASE states and explicit stop/fault/reset/command priorities. Never simplify away scan-cycle behavior, retained state or side effects. Do not invent library signatures, I/O addresses, units or certified safety behavior. 2025-only features require verifiedFeatures: ${profile.verifiedFeatures.join(", ") || "(none)"}. Cite applicable standard identifiers and separate language rules, vendor extensions and project style. Return a draft plus dependencies and regression scenarios; draft is not compiler or runtime evidence. Relevant references: ${standards.map((s) => s.id).join(", ")}.\nApply the following checks only to relevant domains; list missing inputs instead of guessing:\n${domainGuidance.map((r) => `${r.standards.join(" / ")}: ${r.checks} Validation: ${r.verification}`).join("\n")}`;
}
