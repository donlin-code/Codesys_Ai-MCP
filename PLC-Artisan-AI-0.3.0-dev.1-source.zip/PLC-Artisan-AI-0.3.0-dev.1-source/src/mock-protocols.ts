#!/usr/bin/env node
import { createRequire } from "node:module";
import { createServer } from "node:net";
import { join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import {
  OPCUAServer,
  Variant,
  DataType,
  AccessLevelFlag,
  MessageSecurityMode,
  SecurityPolicy,
} from "node-opcua";
const { ServerTCP } = createRequire(import.meta.url)("modbus-serial");
async function freePort() {
  const s = createServer();
  await new Promise<void>((r) => s.listen(0, "127.0.0.1", r));
  const port = (s.address() as any).port;
  await new Promise<void>((r) => s.close(() => r()));
  return port as number;
}
export async function startMocks(
  directory: string,
  ports: { modbus?: number; opcua?: number } = {},
) {
  const modbusPort = ports.modbus ?? (await freePort()),
    opcuaPort = ports.opcua ?? (await freePort());
  let tick = 0;
  const server = new ServerTCP(
    {
      getCoil: (address: number) => address % 2 === 0,
      getDiscreteInput: (address: number) => address % 2 === 1,
      getHoldingRegister: (address: number) =>
        address === 0 ? tick % 65536 : address,
      getInputRegister: (address: number) => address + 100,
    },
    { host: "127.0.0.1", port: modbusPort, unitID: 1 },
  );
  await new Promise<void>((resolve, reject) => {
    server.once("initialized", resolve);
    server.once("serverError", reject);
    server.once("error", reject);
  });
  const ua = new OPCUAServer({
    port: opcuaPort,
    hostname: "127.0.0.1",
    alternateHostname: ["localhost"],
    resourcePath: "/donlinxg-mock",
    nodeset_filename: [],
    securityModes: [
      MessageSecurityMode.None,
      MessageSecurityMode.SignAndEncrypt,
    ],
    securityPolicies: [SecurityPolicy.None, SecurityPolicy.Basic256Sha256],
    allowAnonymous: true,
    serverInfo: {
      applicationUri: "urn:donlinxg:mcp:mock",
      productUri: "urn:donlinxg:mcp:mock",
      applicationName: { text: "donlinxg local protocol test service" },
    },
    userManager: { isValidUser: () => false },
  });
  try {
    await ua.initialize();
    const ns = ua.engine.addressSpace!.getOwnNamespace();
    const folder = ns.addObject({
      organizedBy: ua.engine.addressSpace!.rootFolder.objects,
      browseName: "McpMock",
    });
    ns.addVariable({
      componentOf: folder,
      nodeId: "s=Counter",
      browseName: "Counter",
      dataType: "UInt32",
      minimumSamplingInterval: 100,
      accessLevel: AccessLevelFlag.CurrentRead,
      userAccessLevel: AccessLevelFlag.CurrentRead,
      value: {
        get: () => new Variant({ dataType: DataType.UInt32, value: tick }),
      },
    });
    ns.addVariable({
      componentOf: folder,
      nodeId: "s=Ready",
      browseName: "Ready",
      dataType: "Boolean",
      minimumSamplingInterval: 100,
      accessLevel: AccessLevelFlag.CurrentRead,
      userAccessLevel: AccessLevelFlag.CurrentRead,
      value: {
        get: () => new Variant({ dataType: DataType.Boolean, value: true }),
      },
    });
    await ua.start();
  } catch (e) {
    await new Promise<void>((r) => server.close(() => r()));
    throw e;
  }
  const timer = setInterval(() => tick++, 100);
  return {
    modbusPort,
    opcuaPort,
    endpoint: `opc.tcp://127.0.0.1:${opcuaPort}/donlinxg-mock`,
    nodeIds: ["ns=1;s=Counter", "ns=1;s=Ready"],
    close: async () => {
      clearInterval(timer);
      await ua.shutdown(0);
      await new Promise<void>((r) => server.close(() => r()));
    },
  };
}
if (
  process.argv[1] &&
  resolve(process.argv[1]) === fileURLToPath(import.meta.url)
) {
  startMocks(join(process.cwd(), "artifacts", "mock-protocols"), {
    modbus: 1502,
    opcua: 4841,
  })
    .then((m) => {
      process.stdout.write(
        JSON.stringify({
          modbus: { host: "127.0.0.1", port: m.modbusPort, unitId: 1 },
          opcua: { endpoint: m.endpoint, nodeIds: m.nodeIds },
          origin: "local-test-service",
        }) + "\n",
      );
      process.once("SIGINT", () => {
        void m.close().then(() => process.exit(0));
      });
    })
    .catch((e) => {
      console.error(e.message);
      process.exitCode = 1;
    });
}
