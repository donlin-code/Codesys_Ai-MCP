import { readdir, stat } from "node:fs/promises";
import { join, resolve } from "node:path";
import { doctor, readExecutableVersion } from "./doctor.js";

async function exists(path: string) {
  return stat(path).then(
    () => true,
    () => false,
  );
}

/** Filesystem detection is deliberately separate from a live IDE handshake. */
export async function workbenchDoctor(
  options: { sp20Root?: string; sp22Root?: string } = {},
) {
  const root = resolve(
    options.sp20Root ?? String.raw`D:\Program Files\CODESYS 3.5.20.60`,
  );
  const codesys = /codesys$/i.test(root) ? root : join(root, "CODESYS");
  const executable = join(codesys, "Common", "CODESYS.exe");
  const profiles = await readdir(join(codesys, "Profiles")).catch(() => []);
  const checks = [
    { id: "ide", path: executable, available: await exists(executable) },
    {
      id: "scripting-api-stubs",
      path: join(codesys, "ScriptLib", "Stubs", "scriptengine"),
      available: await exists(
        join(codesys, "ScriptLib", "Stubs", "scriptengine"),
      ),
    },
    {
      id: "profile",
      available: profiles.some((p) => /SP20.*Patch 6/i.test(p)),
      candidates: profiles,
    },
  ];
  return {
    node: {
      version: process.version,
      supported: Number(process.versions.node.split(".")[0]) >= 22,
    },
    sp20: {
      adapter: "experimental-scriptengine",
      checks,
      version: await readExecutableVersion(executable),
      prerequisitesPresent: checks.every((c) => c.available),
      connectionVerified: false,
    },
    sp22: await doctor({ ideRoot: options.sp22Root }),
    oem: ["InoProShop", "EcoStruxure Motion Expert"].map((name) => ({
      name,
      status: "unverified",
      reason:
        "Requires explicit installation/profile and adapter acceptance; no compatibility inferred from shared CODESYS ancestry",
    })),
    nextSteps: [
      "Use connection status for the live identity and guarded-write handshake.",
      "Restart the isolated test bridge after upgrading bridge scripts; existing IDE workers keep their loaded code.",
      "Filesystem presence does not prove PDE entitlement, Scripting API execution or project compatibility.",
    ],
  };
}
