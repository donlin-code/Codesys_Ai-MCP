import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StdioClientTransport } from "@modelcontextprotocol/sdk/client/stdio.js";
import { randomUUID } from "node:crypto";
import { join } from "node:path";
import { doctor } from "./doctor.js";
import { AppError, saveJson, SerialQueue, sha256 } from "./core.js";
import { canonicalJson } from "./snapshot.js";
import type { Adapter } from "./engineering.js";

// Do not trust annotations alone. This discovery client never forwards writes,
// compilation, task/library edits, or arbitrary tools from a newer server.
export const officialReadTools = new Set([
  "browse_project_tree",
  "get_active_app_as_path",
  "get_active_path_and_selection",
  "get_structured_text_content",
  "search_in_files_by_regex",
  "search_path_by_glob",
  "get_device_and_io_configuration",
  "get_libraries_referenced_in_application",
  "get_available_libraries_list",
  "get_library_documentation",
  "get_detailed_library_documentation",
  "search_libraries_for_type",
]);

export interface OfficialConfig {
  backend: "sp22-official";
  ideRoot: string;
  bridge: string;
}

export class OfficialConnection {
  readonly queue = new SerialQueue();
  readonly sessionId = randomUUID();
  private client = new Client(
    { name: "plc-artisan-official-probe", version: "0.3.0-dev.1" },
    { capabilities: {} },
  );
  private transport?: StdioClientTransport;
  tools: any[] = [];
  inventory: any;
  private connected = false;
  constructor(private directory: string) {}
  async connect(config: OfficialConfig) {
    const prerequisites = await doctor({
      ideRoot: config.ideRoot,
      bridge: config.bridge,
    });
    await saveJson(join(this.directory, "prerequisites.json"), prerequisites);
    if (!prerequisites.ready)
      throw new AppError(
        "OFFICIAL_PREREQUISITES",
        "Official Bridge/IDE validation failed; inspect prerequisites.json",
      );
    const started = performance.now();
    this.transport = new StdioClientTransport({
      command: config.bridge,
      args: [],
      stderr: "pipe",
    });
    // Drain stderr without persisting uncontrolled vendor logs or credentials.
    this.transport.stderr?.on("data", () => {});
    try {
      await this.client.connect(this.transport, { timeout: 15000 });
      const initializeMs = performance.now() - started;
      const pages = [],
        seen = new Set<string>();
      let cursor: string | undefined;
      do {
        if (pages.length >= 100 || (cursor && seen.has(cursor)))
          throw new AppError(
            "DISCOVERY_INCOMPLETE",
            "Tool pagination did not terminate",
          );
        if (cursor) seen.add(cursor);
        const page = await this.client.listTools(cursor ? { cursor } : {}, {
          timeout: 15000,
        });
        pages.push(page);
        this.tools.push(...page.tools);
        cursor = page.nextCursor;
      } while (cursor);
      if (new Set(this.tools.map((t) => t.name)).size !== this.tools.length)
        throw new AppError(
          "DISCOVERY_INVALID",
          "Duplicate official tool names",
        );
      this.inventory = {
        schemaVersion: 1,
        origin: "official-mcp",
        sessionId: this.sessionId,
        capturedAt: new Date().toISOString(),
        prerequisites,
        server: this.client.getServerVersion(),
        capabilities: this.client.getServerCapabilities(),
        initializeMs,
        discoveryMs: performance.now() - started - initializeMs,
        schemaHash: sha256(canonicalJson(this.tools)),
        pages,
        integrationStatus: "contract-unverified",
        writeEnabled: false,
      };
      await saveJson(join(this.directory, "discovery.json"), this.inventory);
      this.connected = true;
      this.client.onclose = () => {
        this.connected = false;
      };
      return this.inventory;
    } catch (e) {
      await this.close();
      throw e;
    }
  }
  async read(name: string, args: Record<string, unknown> = {}) {
    if (!officialReadTools.has(name))
      throw new AppError(
        "OFFICIAL_ACTION_DENIED",
        "Only explicit discovery read tools are allowed",
      );
    return this.queue.run(async () => {
      if (!this.connected)
        throw new AppError(
          "OFFICIAL_OFFLINE",
          "Reconnect explicitly; previous session is invalid",
        );
      if (!this.tools.some((t) => t.name === name))
        throw new AppError(
          "OFFICIAL_UNSUPPORTED",
          "Tool absent from actual tools/list",
        );
      const requestId = randomUUID(),
        started = performance.now(),
        at = new Date().toISOString();
      try {
        const result = await this.client.callTool(
          { name, arguments: args },
          undefined,
          { timeout: 30000 },
        );
        const evidence = {
          origin: "official-mcp",
          sessionId: this.sessionId,
          requestId,
          at,
          name,
          args,
          result,
          elapsedMs: performance.now() - started,
        };
        await saveJson(
          join(this.directory, "calls", requestId + ".json"),
          evidence,
        );
        return evidence;
      } catch (e) {
        await saveJson(join(this.directory, "calls", requestId + ".json"), {
          origin: "official-mcp",
          sessionId: this.sessionId,
          requestId,
          at,
          name,
          args,
          error: { message: (e as Error).message },
          elapsedMs: performance.now() - started,
        });
        throw e;
      }
    });
  }
  async close() {
    this.connected = false;
    await this.client.close();
  }
}

// A deliberately gated service adapter. Never invent split source/GUID mappings
// from prose responses. Enable engineering operations only after native contracts
// and lifecycle identity have actually been verified for an installed version.
export class OfficialDiscoveryAdapter implements Adapter {
  readonly name = "sp22-official";
  readonly officialMcp = true;
  readonly guardedWrites = false;
  readonly verifiedCreateKinds: string[] = [];
  readonly actions = ["ping", "capabilities"];
  session: Adapter["session"];
  constructor(private connection: OfficialConnection) {
    this.session = {
      sessionId: connection.sessionId,
      projectIdentity: {
        path: "unverified",
        handle: 0,
        instanceId: connection.sessionId,
      },
    };
  }
  async invoke(action: string) {
    if (action === "ping")
      return { ok: true, result: { pong: true, engineeringReady: false } };
    if (action === "capabilities")
      return {
        ok: true,
        result: {
          adapter: this.name,
          officialMcp: true,
          status: "contract-unverified",
          schemaHash: this.connection.inventory.schemaHash,
          officialTools: this.connection.tools.map((t) => t.name),
          guardedWrites: false,
          verifiedCreateKinds: [],
          reason:
            "Transport discovery is not proof of source completeness, project identity, compilation or approved editing. Run official probe and verify the native contract first.",
        },
      };
    throw new AppError(
      "OFFICIAL_CONTRACT_UNVERIFIED",
      "Native response mapping has not passed acceptance; no engineering request was forwarded",
    );
  }
  close() {
    return this.connection.close();
  }
}
