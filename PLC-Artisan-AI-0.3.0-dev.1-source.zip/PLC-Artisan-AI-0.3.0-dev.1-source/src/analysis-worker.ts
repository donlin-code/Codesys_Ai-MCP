import { parentPort, isMainThread, Worker } from "node:worker_threads";
import { AnalysisIndex, type SourceObject } from "./st-analysis.js";
import { AppError } from "./core.js";

if (!isMainThread && parentPort) {
  const index = new AnalysisIndex();
  parentPort.on("message", ({ id, mode, objects }) => {
    try {
      parentPort!.postMessage({
        id,
        result:
          mode === "references"
            ? index.referenceIndex(objects)
            : index.analyze(objects),
      });
    } catch (e) {
      parentPort!.postMessage({ id, error: (e as Error).message });
    }
  });
}

export class AnalysisWorker {
  private worker?: Worker;
  private sequence = 0;
  private pending = new Map<
    number,
    { resolve: (value: any) => void; reject: (e: Error) => void }
  >();
  run(
    objects: SourceObject[],
    mode: "analyze" | "references" = "analyze",
  ): Promise<any> {
    if (!this.worker) {
      const worker = (this.worker = new Worker(
        new URL("./analysis-worker.js", import.meta.url),
      ));
      worker.on("message", ({ id, result, error }) => {
        const entry = this.pending.get(id);
        this.pending.delete(id);
        if (!this.pending.size) worker.unref();
        if (error) entry?.reject(new AppError("ANALYSIS_FAILED", error));
        else entry?.resolve(result);
      });
      const fail = (e: Error) => {
        if (this.worker !== worker) return;
        for (const p of this.pending.values()) p.reject(e);
        this.pending.clear();
        this.worker = undefined;
      };
      worker.on("error", fail);
      worker.on("exit", () =>
        fail(new AppError("WORKER_CLOSED", "Analysis worker stopped")),
      );
    }
    this.worker.ref();
    return new Promise((resolve, reject) => {
      const id = ++this.sequence;
      this.pending.set(id, { resolve, reject });
      this.worker!.postMessage({ id, mode, objects });
    });
  }
  async close() {
    for (const p of this.pending.values())
      p.reject(new AppError("WORKER_CLOSED", "Service closed"));
    this.pending.clear();
    const worker = this.worker;
    this.worker = undefined;
    if (worker) await worker.terminate();
  }
}
