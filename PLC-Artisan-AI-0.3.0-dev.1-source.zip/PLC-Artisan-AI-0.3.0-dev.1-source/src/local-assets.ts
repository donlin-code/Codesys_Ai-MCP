import { readdir, readFile, stat } from "node:fs/promises";
import { join, extname, relative } from "node:path";
import { spawn } from "node:child_process";
import { AppError, inside, sha256, decodeLocalText } from "./core.js";

export async function searchDocuments(roots: string[], query: string) {
  if (!query || query.length > 256)
    throw new AppError("INVALID_QUERY", "Query length 1..256");
  const results: any[] = [],
    issues: any[] = [];
  let files = 0;
  async function walk(root: string, path: string, depth: number) {
    if (depth > 20 || files > 5000 || results.length >= 500) return;
    for (const entry of await readdir(path, { withFileTypes: true })) {
      if (
        entry.isSymbolicLink() ||
        ["node_modules", ".git", "artifacts", "private-evidence"].includes(
          entry.name,
        )
      )
        continue;
      const file = join(path, entry.name);
      if (entry.isDirectory()) {
        await walk(root, file, depth + 1);
        continue;
      }
      if (![".md", ".txt", ".st", ".xml"].includes(extname(file).toLowerCase()))
        continue;
      files++;
      try {
        await inside(root, file);
        if ((await stat(file)).size > 2 * 1024 * 1024) {
          issues.push({ file, reason: "File exceeds 2 MiB document limit" });
          continue;
        }
        const text = decodeLocalText(await readFile(file)),
          hash = sha256(text);
        text.split("\n").forEach((line, i) => {
          if (
            results.length < 500 &&
            line.toLowerCase().includes(query.toLowerCase())
          )
            results.push({
              file,
              line: i + 1,
              text: line,
              sha256: hash,
              source: "authorized-local-document",
              xmlSemanticCoverage:
                extname(file) === ".xml" ? "text-only" : undefined,
            });
        });
      } catch (e) {
        issues.push({ file, reason: (e as Error).message });
      }
    }
  }
  for (const root of roots) await walk(root, root, 0);
  return {
    results,
    issues,
    scannedFiles: files,
    bounded: files > 5000 || results.length >= 500,
  };
}
function git(root: string, args: string[]): Promise<string> {
  return new Promise((resolve, reject) => {
    const p = spawn("git", ["-C", root, "--no-pager", ...args], {
      windowsHide: true,
      shell: false,
      stdio: ["ignore", "pipe", "pipe"],
    });
    let out = "",
      error = "";
    p.stdout.on("data", (c) => {
      out += c;
      if (out.length > 4 * 1024 * 1024) p.kill();
    });
    p.stderr.on("data", (c) => (error += c));
    p.on("error", reject);
    p.on("close", (code) =>
      code === 0
        ? resolve(out)
        : reject(new AppError("GIT_FAILED", error.slice(0, 2000))),
    );
  });
}
export async function gitInspect(root: string) {
  return {
    status: await git(root, ["status", "--short"]),
    diff: await git(root, [
      "diff",
      "--",
      "src",
      "tests",
      "docs",
      "workflows",
      "scripts",
      "web",
      "distribution",
    ]),
  };
}
export async function gitCheckpoint(
  root: string,
  files: string[],
  message: string,
) {
  if (
    !files.length ||
    files.length > 500 ||
    !message.trim() ||
    message.length > 256
  )
    throw new AppError(
      "CHECKPOINT_INVALID",
      "Select explicit source files and a short message",
    );
  for (const file of files) {
    const actual = await inside(root, file),
      rel = relative(root, actual).replace(/\\/g, "/");
    if (
      !/^(?:src|tests|docs|workflows|scripts|web|distribution)\//.test(rel) ||
      /(?:^|\/)(?:\.env[^/]*|.*(?:secret|bootstrap|nonce|session|credential)[^/]*)$/i.test(
        rel,
      ) ||
      !/\.(ts|tsx|js|mjs|py|ps1|md|json|css|html|yml|yaml)$/.test(rel)
    )
      throw new AppError(
        "CHECKPOINT_DENIED",
        "Not an allowed source/document file: " + rel,
      );
    const contents = decodeLocalText(await readFile(actual));
    if (
      /\b(?:ghp_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}|sk-[A-Za-z0-9_-]{24,})\b/.test(
        contents,
      )
    )
      throw new AppError(
        "SECRET_DETECTED",
        "Potential credential in selected file",
      );
  }
  // Commit only the explicit pathspec; unrelated staged changes remain untouched.
  await git(root, ["add", "--", ...files]);
  return {
    commit: await git(root, [
      "commit",
      "--only",
      "-m",
      message,
      "--",
      ...files,
    ]),
    pushed: false,
  };
}
