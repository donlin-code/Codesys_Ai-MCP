[CmdletBinding()]
param([string]$Node, [string]$Config, [switch]$NoBrowser)
$ErrorActionPreference = 'Stop'
$workspace = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
if (-not $Node) {
  $nodeCommand = Get-Command node -ErrorAction SilentlyContinue
  if ($nodeCommand) { $Node = $nodeCommand.Source }
}
if (-not $Node -or -not (Test-Path -LiteralPath $Node)) { throw 'Node.js 22+ is required. Pass -Node with its executable path.' }
$version = & $Node --version
if ([int]($version.TrimStart('v').Split('.')[0]) -lt 22) { throw 'Node.js 22+ is required' }
$cli = Join-Path $workspace 'dist\src\cli.js'
if (-not (Test-Path -LiteralPath $cli)) { throw 'Build source first, or use a prepared runtime package' }
$argsForCli = @($cli, 'workbench')
if ($Config) { $argsForCli += @('--config', [IO.Path]::GetFullPath($Config)) }
$url = & $Node @argsForCli
if ($LASTEXITCODE -ne 0) { throw 'Workbench startup failed' }
Write-Output $url
if (-not $NoBrowser) { Start-Process -FilePath $url -WindowStyle Hidden }
