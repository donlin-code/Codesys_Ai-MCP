import { readFile, writeFile, cp, mkdir } from "node:fs/promises";
import { join, resolve, dirname, basename } from "node:path";
import { fileURLToPath } from "node:url";
import { spawnSync } from "node:child_process";
const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const pkg = JSON.parse(await readFile(join(root, "package.json"), "utf8")),
  lock = JSON.parse(await readFile(join(root, "package-lock.json"), "utf8"));
function run(args) {
  const r = spawnSync(process.execPath, args, {
    cwd: root,
    stdio: "inherit",
    env: {
      ...process.env,
      PATH: dirname(process.execPath) + ";" + process.env.PATH,
    },
  });
  if (r.error) throw r.error;
  if (r.status !== 0)
    throw new Error("Required release check failed: " + args.join(" "));
}
run(["scripts/dev.mjs", "test", "--core"]);
const python = process.env.MCP_TEST_PYTHON ?? "python";
const py = spawnSync(python, ["tests/sp20-bridge-contract.py"], {
  cwd: root,
  stdio: "inherit",
});
if (py.error || py.status !== 0)
  throw new Error(
    "Python bridge contracts failed; set MCP_TEST_PYTHON to a working Python 3 executable",
  );
run([
  "node_modules/vite/bin/vite.js",
  "build",
  "--config",
  "web/vite.config.ts",
]);
run([
  "node_modules/@playwright/test/cli.js",
  "test",
  "--config",
  "web/playwright.config.ts",
]);
const stamp = new Date().toISOString().replace(/[:.]/g, "-"),
  folder = join(root, "artifacts", "release", stamp);
await mkdir(folder, { recursive: true });
const source = join(folder, `PLC-Artisan-AI-${pkg.version}-source`),
  runtime = join(folder, `PLC-Artisan-AI-${pkg.version}-runtime`);
await mkdir(source);
await mkdir(runtime);
const sourcePaths = [
  "src",
  "tests",
  "web",
  "scripts/dev.mjs",
  "scripts/release-v2.mjs",
  "scripts/package-core-v03.mjs",
  "scripts/benchmark-v03.mjs",
  "scripts/prepare-native-smoke.mjs",
  "scripts/sp20_bridge.py",
  "scripts/Start-SP20Bridge.ps1",
  "scripts/Start-Workbench.ps1",
  "scripts/Start-ProtocolMocks.ps1",
  "scripts/Configure-SP20Mcp.ps1",
  "scripts/Configure-CodesysMcp.ps1",
  "examples/smoke",
  "package.json",
  "package-lock.json",
  "tsconfig.json",
  "distribution/README.md",
  "distribution/README.en.md",
  "distribution/acceptance-v02.md",
  "distribution/mcp.example.json",
  "distribution/performance-v02.json",
  "distribution/performance-v03.json",
  "distribution/acceptance-v03.md",
  "docs/v03-guide.md",
  "docs/v03-guide.en.md",
];
for (const path of sourcePaths) {
  await mkdir(dirname(join(source, path)), { recursive: true });
  await cp(join(root, path), join(source, path), {
    recursive: true,
    filter: (p) => !p.includes("__pycache__") && !p.endsWith(".pyc"),
  });
}
await writeFile(
  join(source, "package.json"),
  JSON.stringify(
    {
      ...pkg,
      scripts: {
        build: "node scripts/dev.mjs build",
        test: "node scripts/dev.mjs test --core",
        "build:web": "vite build --config web/vite.config.ts",
        "test:web": "playwright test --config web/playwright.config.ts",
        workbench: "node dist/src/workbench-server.js",
        "package:release": "node scripts/release-v2.mjs",
      },
    },
    null,
    2,
  ) + "\n",
);
const runtimePaths = [
  "scripts/prepare-native-smoke.mjs",
  "dist/src",
  "web-dist",
  "scripts/sp20_bridge.py",
  "scripts/Start-SP20Bridge.ps1",
  "scripts/Start-Workbench.ps1",
  "scripts/Start-ProtocolMocks.ps1",
  "scripts/Configure-SP20Mcp.ps1",
  "scripts/Configure-CodesysMcp.ps1",
];
for (const path of runtimePaths) {
  await mkdir(dirname(join(runtime, path)), { recursive: true });
  await cp(join(root, path), join(runtime, path), { recursive: true });
}
for (const target of [source, runtime]) {
  await cp(join(root, "distribution", "README.md"), join(target, "README.md"));
  await cp(
    join(root, "distribution", "README.en.md"),
    join(target, "README.en.md"),
  );
  await mkdir(join(target, "docs"), {recursive: true});
  await cp(
    join(root, "docs", "v02-guide.md"),
    join(target, "docs", "v02-guide.md"),
  );
  await cp(
    join(root, "distribution", "acceptance-v03.md"),
    join(target, "docs", "acceptance.md"),
  );
  await cp(
    join(root, "docs", "standards-policy.md"),
    join(target, "docs", "standards-policy.md"),
  );
  await cp(
    join(root, "distribution", "performance-v02.json"),
    join(target, "docs", "performance-v02.json"),
  );
  for (const name of ["v03-guide.md", "v03-guide.en.md"])
    await cp(join(root, "docs", name), join(target, "docs", name));
  await cp(
    join(root, "distribution", "performance-v03.json"),
    join(target, "docs", "performance-v03.json"),
  );
  await writeFile(
    join(target, "docs", "tools.json"),
    JSON.stringify(
      (await import("../dist/src/toolkit.js")).publicTools,
      null,
      2,
    ) + "\n",
  );
  const { standards, domainGuidance } =
    await import("../dist/src/standards.js");
  await writeFile(
    join(target, "docs", "standards.json"),
    JSON.stringify({ standards, domainGuidance }, null, 2) + "\n",
  );
  await mkdir(join(target, "config"));
  await cp(
    join(root, "distribution", "mcp.example.json"),
    join(target, "config", "mcp.example.json"),
  );
  await mkdir(join(target, "workflows"));
  for (const w of ["ANALYZE.md", "EDIT.md", "CONNECT.md"])
    await cp(join(root, "workflows", w), join(target, "workflows", w));
  await writeFile(
    join(target, "AGENTS.md"),
    "# Operator rules\nRead docs/acceptance.md and workflows before engineering work. Use isolated test copies. Human approval of the exact batch hash is required in the workbench before any IDE write; reread and stop on conflicts or unknown outcomes. No automatic save/reopen, PLC download/start/force or device writes. Fixture, offline model, IDE compilation and actual behavior evidence must remain distinct. Never package user projects, transport credentials or provider secrets.\n",
  );
}
await writeFile(
  join(source, ".gitignore"),
  "node_modules/\ndist/\nweb-dist/\nartifacts/\n.env\n.env.*\n*.project\n*.projectarchive\n__pycache__/\n",
);
await mkdir(join(source, ".github", "workflows"), { recursive: true });
await writeFile(
  join(source, ".github", "workflows", "ci.yml"),
  `name: Check\non: [push, pull_request, workflow_dispatch]\npermissions:\n  contents: read\njobs:\n  test:\n    runs-on: windows-latest\n    steps:\n      - uses: actions/checkout@v4\n      - uses: actions/setup-node@v4\n        with:\n          node-version: 22\n          cache: npm\n      - uses: actions/setup-python@v5\n        with:\n          python-version: '3.12'\n      - run: npm ci\n      - run: npm test\n      - run: python tests/sp20-bridge-contract.py\n      - run: npm run build:web\n      - run: npm run test:web\n`,
);
await writeFile(
  join(runtime, "package.json"),
  JSON.stringify(
    {
      ...pkg,
      scripts: {
        workbench: "node dist/src/workbench-server.js",
        doctor: "node dist/src/cli.js doctor",
      },
      devDependencies: undefined,
    },
    null,
    2,
  ) + "\n",
);
const dependencies = [],
  missingOptional = [];
for (const [path, metadata] of Object.entries(lock.packages ?? {})) {
  if (
    !path.startsWith("node_modules/") ||
    metadata.dev === true ||
    path.includes("/@types/") ||
    path.endsWith("/typescript")
  )
    continue;
  if (metadata.link || path.split("/").includes(".."))
    throw new Error("Unexpected dependency path");
  let installed;
  try {
    installed = JSON.parse(
      await readFile(join(root, path, "package.json"), "utf8"),
    );
  } catch (e) {
    if (metadata.optional) {
      missingOptional.push(path);
      continue;
    }
    throw e;
  }
  if (installed.version !== metadata.version)
    throw new Error("Installed dependency differs from lock: " + path);
  await mkdir(dirname(join(runtime, path)), { recursive: true });
  const origin = join(root, path);
  await cp(origin, join(runtime, path), {
    recursive: true,
    filter: (p) => p === origin || basename(p) !== "node_modules",
  });
  dependencies.push({
    path,
    version: installed.version,
    license: installed.license ?? null,
  });
}
await writeFile(
  join(runtime, "RUNTIME-PACKAGE.json"),
  JSON.stringify(
    {
      version: pkg.version,
      node: "22+ external installation required",
      dependencies,
      missingOptional,
      source: "production dependency tree from lockfile",
      plcRuntimeControl: false,
    },
    null,
    2,
  ) + "\n",
);
// Consolidate public third-party notices in a conventional distribution notice.
// Keep the original UTF-8 text and a path/hash map; never omit license content.
// This also avoids platform archive handlers rewriting individual .txt notices.
const notices = spawnSync(
  python,
  [
    "-c",
    String.raw`from pathlib import Path
import sys, json, hashlib
root=Path(sys.argv[1])
files=[]
blocks=['# Third-party license notices\n\nOriginal notice text is reproduced below. Original dependency paths and SHA-256 digests are recorded in THIRD-PARTY-NOTICES.json. Other dependency license files remain in place.\n']
for file in sorted(root.rglob('*.txt')):
    if file.name.lower() not in ('license.txt','copyrightnotice.txt','thirdpartynotices.txt'):
        continue
    rel=file.relative_to(root).as_posix()
    if not rel.startswith('node_modules/'):
        raise RuntimeError('Unexpected notice path: '+rel)
    data=file.read_bytes()
    if data.startswith(b'%TSD-Header-###%'):
        raise RuntimeError('Notice plaintext unavailable: '+rel)
    text=data.decode('utf-8-sig')
    heading='notice-'+str(len(files)+1)
    blocks.append('\n<a id="'+heading+'"></a>\n\n## '+rel+'\n\n'+text+'\n')
    files.append(dict(originalPath=rel,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),notice='THIRD-PARTY-NOTICES.md#'+heading))
document=''.join(blocks)
# Verify every original notice remains present verbatim before removing only
# those explicitly selected files from this generated staging directory.
for entry in files:
    file=root/entry['originalPath']
    if file.read_bytes().decode('utf-8-sig') not in document:
        raise RuntimeError('Notice aggregation incomplete')
(root/'THIRD-PARTY-NOTICES.md').write_text(document,encoding='utf-8',newline='')
(root/'THIRD-PARTY-NOTICES.json').write_text(json.dumps(files,indent=2)+'\n',encoding='utf-8')
for entry in files:
    (root/entry['originalPath']).unlink()
print(json.dumps(dict(consolidatedNotices=len(files))))
`,
    runtime,
  ],
  { encoding: "utf8", windowsHide: true },
);
if (notices.error || notices.status !== 0)
  throw new Error(
    "License aggregation failed: " + (notices.stderr ?? notices.error),
  );
async function manifest(directory) {
  // Use the same permitted file reader as the ZIP writer. Some Windows
  // transparent-encryption drivers expose different bytes to Node and Python.
  const result = spawnSync(
    python,
    [
      "-c",
      String.raw`from pathlib import Path
import sys, json, hashlib, re
root=Path(sys.argv[1])
entries=[]
for file in sorted(root.rglob('*')):
    if not file.is_file():
        continue
    rel=file.relative_to(root).as_posix()
    if re.search(r'(?:^|/)(?:bootstrap\.json|ready\.json|service\.json|private-providers\.json|\.env[^/]*|.*\.(?:project|projectarchive))$',rel,re.I):
        raise RuntimeError('Forbidden release file: '+rel)
    data=file.read_bytes()
    if re.search(r'\.(?:ts|tsx|js|mjs|py|ps1|md|json|txt|html|css)$',rel) and not rel.startswith('node_modules/'):
        text=data.decode('utf-8-sig')
        if re.search(r'\b(?:ghp_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}|sk-[A-Za-z0-9_-]{24,})\b',text):
            raise RuntimeError('Potential credential in '+rel)
    entries.append(dict(path=rel,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
print(json.dumps(entries))
`,
      directory,
    ],
    { encoding: "utf8", windowsHide: true, maxBuffer: 32 * 1024 * 1024 },
  );
  if (result.error || result.status !== 0)
    throw new Error("Manifest/scan failed: " + (result.stderr ?? result.error));
  return JSON.parse(result.stdout);
}
for (const target of [source, runtime]) {
  const entries = await manifest(target);
  await writeFile(
    join(target, "SHA256SUMS.json"),
    JSON.stringify(entries, null, 2) + "\n",
  );
}
const validation = {
  version: pkg.version,
  at: new Date().toISOString(),
  localChecks:
    "Node suite, Python contracts, TypeScript backend+web, Vite build, Playwright fixture E2E passed in this run",
  liveIdeEdits: "Not inferred from automated tests; consult acceptance record",
  telemetry: "Local simulated Modbus TCP and OPC UA tested",
  cloudModels: "Adapter contract tests; real provider credentials not included",
  node: process.version,
};
await writeFile(
  join(folder, "VALIDATION.json"),
  JSON.stringify(validation, null, 2) + "\n",
);
const artifacts = [];
for (const target of [source, runtime]) {
  const zip = target + ".zip";
  const result = spawnSync(
    python,
    [
      "-c",
      `from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import sys
root = Path(sys.argv[1])
with ZipFile(sys.argv[2], 'w', ZIP_DEFLATED, compresslevel=6) as archive:
    for file in sorted(root.rglob('*')):
        if file.is_file():
            archive.write(file, str(Path(root.name) / file.relative_to(root)))
import json, hashlib
with ZipFile(sys.argv[2]) as archive:
    manifest=json.loads(archive.read(root.name+'/SHA256SUMS.json'))
    for entry in manifest:
        data=archive.read(root.name+'/'+entry['path'])
        if len(data)!=entry['bytes'] or hashlib.sha256(data).hexdigest()!=entry['sha256']:
            raise RuntimeError('ZIP manifest mismatch: '+entry['path'])
payload=Path(sys.argv[2]).read_bytes()
print(json.dumps(dict(file=Path(sys.argv[2]).name,bytes=len(payload),sha256=hashlib.sha256(payload).hexdigest())))
`,
      target,
      zip,
    ],
    { encoding: "utf8", windowsHide: true },
  );
  if (result.error || result.status !== 0)
    throw new Error(
      "ZIP generation/validation failed: " + (result.stderr ?? result.error),
    );
  artifacts.push(JSON.parse(result.stdout));
}
await writeFile(
  join(folder, "DOWNLOAD-SHA256.json"),
  JSON.stringify(artifacts, null, 2) + "\n",
);
console.log(JSON.stringify({ folder, source, runtime, artifacts }, null, 2));

run(["scripts/package-core-v03.mjs", folder]);
artifacts.push(
  JSON.parse(await readFile(join(folder, "CORE-SHA256.json"), "utf8")),
);
await writeFile(
  join(folder, "DOWNLOAD-SHA256.json"),
  JSON.stringify(artifacts, null, 2) + "\n",
);
