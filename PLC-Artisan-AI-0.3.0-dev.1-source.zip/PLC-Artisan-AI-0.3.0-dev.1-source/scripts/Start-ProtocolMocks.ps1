[CmdletBinding()]
param([string]$Node = 'node')
$ErrorActionPreference = 'Stop'
$workspace = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
& $Node (Join-Path $workspace 'dist\src\mock-protocols.js')
