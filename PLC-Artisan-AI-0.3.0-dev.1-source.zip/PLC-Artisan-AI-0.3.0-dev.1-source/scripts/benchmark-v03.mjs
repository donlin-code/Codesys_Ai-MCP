import { mkdir, writeFile } from "node:fs/promises";
import { resolve, join } from "node:path";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StdioClientTransport } from "@modelcontextprotocol/sdk/client/stdio.js";
import { EngineeringService } from "../dist/src/engineering.js";
import { AnalysisIndex } from "../dist/src/st-analysis.js";
import { sourceHash } from "../dist/src/core.js";
import { startWorkbench } from "../dist/src/workbench-server.js";

const out = resolve(process.argv[2] ?? "artifacts/performance-v03");
await mkdir(out, { recursive: true });
const objects = Array.from({ length: 149 }, (_, i) => {
  const declaration = `PROGRAM P${i}\nVAR\n    counter : DINT;\n    label : STRING := '中文';\nEND_VAR`;
  const implementation = Array.from(
    { length: 24 },
    (_, line) => `IF counter > ${line} THEN GVL.Output${i} := FALSE; END_IF;`,
  ).join("\n");
  return {
    path: `/Application/P${i}`,
    id: `fixture-${i}`,
    declaration,
    implementation,
    sha256: sourceHash(declaration, implementation),
    sourceComplete: true,
  };
});
const service = new EngineeringService(join(out, "fixture-service"));
service.snapshot = {
  schemaVersion: 2,
  origin: "fixture",
  session: { sessionId: "fixture-only" },
  objects,
  capturedAt: new Date().toISOString(),
  freshness: "fixture",
};
const stats = (values) => {
  const sorted = [...values].sort((a, b) => a - b);
  const p = (fraction) => sorted[Math.ceil(sorted.length * fraction) - 1];
  return {
    samples: values.length,
    p50Ms: p(0.5),
    p95Ms: p(0.95),
    p99Ms: p(0.99),
    minMs: sorted[0],
    maxMs: sorted.at(-1),
  };
};
const timing = async (fn, n = 200) => {
  const values = [];
  for (let i = 0; i < n; i++) {
    const start = performance.now();
    await fn(i);
    values.push(performance.now() - start);
  }
  return stats(values);
};
try {
  const initialStart = performance.now();
  await service.analyze();
  await service.references("GVL.Output1");
  service.search("counter");
  const initialIndexMs = performance.now() - initialStart;
  const search = await timing(() => service.search("Output1"));
  const references = await timing(() => service.references("GVL.Output1"));
  const cachedAnalysis = await timing(() => service.analyze());
  const index = new AnalysisIndex();
  const changedObjectCheck = await timing((i) =>
    index.analyze([
      {
        ...objects[0],
        implementation: objects[0].implementation + `\ncounter := ${i};`,
      },
    ]),
  );
  // Explicit algorithm baseline, not a claim that the released v0.2 binary ran.
  const previousSearchAlgorithm = await timing(() =>
    objects
      .flatMap((o) =>
        ["declaration", "implementation"].flatMap((part) =>
          o[part]
            .split("\n")
            .flatMap((text, i) =>
              text.toLowerCase().includes("Output1".toLowerCase())
                ? [{ path: o.path, part, line: i + 1, text, sha256: o.sha256 }]
                : [],
            ),
        ),
      )
      .slice(0, 500),
  );
  const coldDiscovery = await timing(async () => {
    const c = new Client({ name: "benchmark", version: "1" });
    try {
      await c.connect(
        new StdioClientTransport({
          command: process.execPath,
          args: [
            resolve("dist/src/mcp-server.js"),
            "--config",
            join(out, "intentionally-absent.json"),
          ],
          stderr: "pipe",
        }),
        { timeout: 15000 },
      );
      await c.listTools();
    } finally {
      await c.close();
    }
  }, 5);
  const app = await startWorkbench({
    directory: join(out, "fixture-service"),
    root: resolve("."),
    service,
  });
  const mcp = new Client({ name: "fixture-roundtrip", version: "1" });
  let mcpSearch, mcpReferences;
  try {
    await mcp.connect(
      new StdioClientTransport({
        command: process.execPath,
        args: [
          resolve("dist/src/mcp-server.js"),
          "--data",
          join(out, "fixture-service"),
        ],
        stderr: "pipe",
      }),
    );
    const call = (name) =>
      mcp.callTool({ name, arguments: { query: "GVL.Output1" } });
    await call("codesys_search");
    mcpSearch = await timing(async () => {
      const r = await call("codesys_search");
      if (r.isError) throw new Error("Search failed");
    });
    mcpReferences = await timing(async () => {
      const r = await call("codesys_references");
      if (r.isError) throw new Error("References failed");
    });
  } finally {
    await mcp.close();
    await app.close();
  }
  const report = {
    version: "0.3.0-dev.1",
    origin: "fixture",
    at: new Date().toISOString(),
    node: process.version,
    scope: {
      objects: objects.length,
      sourceBytes: objects.reduce(
        (n, o) => n + Buffer.byteLength(o.declaration + o.implementation),
        0,
      ),
      query: "Output1",
      resultLimit: 500,
    },
    initialIndexMs,
    search,
    references,
    cachedAnalysis,
    changedObjectCheck,
    previousSearchAlgorithm,
    coldDiscovery,
    mcpSearch,
    mcpReferences,
    nativeComparison: {
      status: "blocked",
      reason:
        "SP22 official PackageManagerCLI.exe crashed in cpsrt.dll; Bridge unavailable. No native or 100ms IDE-sync claim.",
    },
    boundary:
      "Local service timings exclude transports. mcpSearch/mcpReferences include SDK client, stdio process, authenticated loopback RPC and serialization, against an in-memory fixture. All exclude AI inference, IDE transport, compilation and source synchronization. Cold discovery includes Node+MCP initialize/tools/list; no IDE needed.",
  };
  await writeFile(
    join(out, "performance.json"),
    JSON.stringify(report, null, 2) + "\n",
  );
  console.log(JSON.stringify(report, null, 2));
} finally {
  await service.close();
}
