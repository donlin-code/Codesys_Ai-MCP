// Build the slim archive directly from the full ZIP; never extract an archive.
import { readFile, writeFile } from "node:fs/promises";
import { resolve, join, posix } from "node:path";
import { spawnSync } from "node:child_process";
const directory = resolve(process.argv[2] ?? "");
if (!process.argv[2]) throw new Error("Pass a completed release directory");
const pkg = JSON.parse(await readFile("package.json", "utf8"));
const lock = JSON.parse(await readFile("package-lock.json", "utf8"));
const roots = ["@modelcontextprotocol/sdk", "zod"],
  needed = new Set();
function locate(from, name) {
  let current = from;
  for (;;) {
    const key = posix.join(current, "node_modules", name);
    if (lock.packages[key]) return key;
    if (current === ".") break;
    current = posix.dirname(current);
  }
}
function visit(key) {
  if (needed.has(key)) return;
  needed.add(key);
  const meta = lock.packages[key];
  for (const name of new Set([
    ...Object.keys(meta.dependencies ?? {}),
    ...Object.keys(meta.optionalDependencies ?? {}),
    ...Object.keys(meta.peerDependencies ?? {}),
  ])) {
    const dependency = locate(key, name);
    if (dependency) visit(dependency);
    else if (
      !meta.optionalDependencies?.[name] &&
      !meta.peerDependenciesMeta?.[name]?.optional
    )
      throw new Error(`Missing dependency ${name} of ${key}`);
  }
}
for (const name of roots) visit(locate(".", name));
const plan = join(directory, "core-package-plan.json");
await writeFile(
  plan,
  JSON.stringify({
    paths: [...needed],
    dependencies: Object.fromEntries(
      roots.map((name) => [name, pkg.dependencies[name]]),
    ),
  }),
);
const script = String.raw`
import sys,json,zipfile,hashlib,re
from pathlib import Path
folder=Path(sys.argv[1]);version=sys.argv[2];plan=json.loads(Path(sys.argv[3]).read_text())
source=folder/('PLC-Artisan-AI-'+version+'-runtime.zip')
destination=folder/('PLC-Artisan-AI-'+version+'-core.zip')
with zipfile.ZipFile(source) as original:
    names=original.namelist()
    prefix=next(n[:-len('package.json')] for n in names if n.endswith('/package.json') and '/node_modules/' not in n and '/dist/' not in n)
    entries={}
    for info in original.infolist():
        if info.is_dir():continue
        if not info.filename.startswith(prefix):raise RuntimeError('Unexpected ZIP root')
        rel=info.filename[len(prefix):]
        if rel=='SHA256SUMS.json':continue
        if rel.startswith('node_modules/'):
            owner=re.match(r'^(.*node_modules/(?:@[^/]+/)?[^/]+)(?:/|$)',rel).group(1)
            if owner not in plan['paths']:continue
        entries[rel]=original.read(info)
    package=json.loads(entries['package.json']);package['dependencies']=plan['dependencies']
    entries['package.json']=(json.dumps(package,ensure_ascii=False,indent=2)+'\n').encode()
    meta=json.loads(entries['RUNTIME-PACKAGE.json']);meta['profile']='core';meta['optionalModules']='Telemetry requires the full runtime ZIP. Official Bridge is separately installed.'
    meta['dependencies']=[d for d in meta['dependencies'] if d['path'] in plan['paths']]
    entries['RUNTIME-PACKAGE.json']=(json.dumps(meta,indent=2)+'\n').encode()
    entries['CORE-PACKAGE.md']=b'# Core runtime\n\nUse Node.js 22+. Start dist/src/mcp-server.js or dist/src/cli.js. Includes MCP, engineering service, approval UI and local analysis. Modbus/OPC UA require the full runtime archive; no official CODESYS binaries included. Install packages separately; never overlay running installations.\n'
    manifest=[dict(path=k,bytes=len(v),sha256=hashlib.sha256(v).hexdigest()) for k,v in sorted(entries.items())]
    entries['SHA256SUMS.json']=(json.dumps(manifest,indent=2)+'\n').encode()
    newprefix='PLC-Artisan-AI-'+version+'-core/'
    with zipfile.ZipFile(destination,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as result:
        for name,data in entries.items():result.writestr(newprefix+name,data)
with zipfile.ZipFile(destination) as check:
    assert check.testzip() is None
    for entry in manifest:
        data=check.read(newprefix+entry['path'])
        if hashlib.sha256(data).hexdigest()!=entry['sha256']:raise RuntimeError('Manifest mismatch')
data=destination.read_bytes()
record=dict(file=destination.name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),dependencies=len(meta['dependencies']),verified='in-memory ZIP member validation; no extraction')
(folder/'CORE-SHA256.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
`;
const result = spawnSync(
  process.env.MCP_TEST_PYTHON ?? "python",
  ["-c", script, directory, pkg.version, plan],
  { encoding: "utf8", windowsHide: true },
);
if (result.error || result.status !== 0)
  throw new Error(result.stderr || String(result.error));
console.log(result.stdout);
