# -*- coding: utf-8 -*-
"""Experimental SP20 ScriptEngine bridge; run only in a NEW isolated GUI IDE.

IronPython 2.7 compatible. No request may contain executable Python. The thread
dispatch mechanism follows the approach in luke-harriman/Codesys-MCP and the
local plcwright watcher; the protocol and handlers here are independent.
"""
from __future__ import print_function
import datetime
import hashlib
import hmac
import io
import json
import os
import re
import sys
import time
import uuid
import xml.etree.ElementTree as ElementTree

PROTOCOL = 1
ACTIONS = ('ping', 'project_info', 'list', 'read', 'read_many', 'fingerprint_many', 'read_page', 'context', 'capabilities', 'create_st', 'replace_st', 'compile')
UUID_RE = re.compile(r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$')
SHA_RE = re.compile(r'^[0-9a-f]{64}$')
MAX_REQUEST_BYTES = 4 * 1024 * 1024
try:
    text_type = unicode
except NameError:
    text_type = str


class BridgeError(Exception):
    def __init__(self, code, message, partial=False, details=None):
        Exception.__init__(self, message)
        self.code, self.partial, self.details = code, partial, details


def utc_now():
    return datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.%fZ')


def require_text(value, field):
    if not isinstance(value, text_type):
        raise BridgeError('INVALID_REQUEST', field + ' must be a string')
    if u'\x00' in value:
        raise BridgeError('INVALID_REQUEST', field + ' must not contain NUL')
    try:
        value.encode('utf-8', 'strict')
    except UnicodeError:
        raise BridgeError('INVALID_REQUEST', field + ' contains invalid Unicode')
    return value


def sha256(text):
    return hashlib.sha256(text.encode('utf-8')).hexdigest()


def source_sha256(declaration, implementation):
    return sha256(declaration + u'\x00' + implementation)


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':'))


def child_fingerprint(children):
    return sha256(canonical(sorted(children, key=lambda item: (item['name'], item['id']))))


def normalized_source(value, field):
    value = require_text(value, field)
    return value.replace(u'\r\n', u'\n').replace(u'\r', u'\n')


def requested_implementation(args):
    value = args.get('implementation')
    return normalized_source(u'' if value is None else value, 'implementation')


def path_segment(name):
    return name.replace(u'~', u'~0').replace(u'/', u'~1')


def object_segments(path):
    require_text(path, 'path')
    if path == '/':
        return []
    if not path.startswith('/') or path.endswith('/'):
        raise BridgeError('INVALID_PATH', 'Object paths must start with / and have no trailing /')
    parts = path[1:].split('/')
    if len(parts) > 128:
        raise BridgeError('PATH_TOO_DEEP', 'Object path exceeds the 128 segment limit')
    result = []
    for part in parts:
        selector = None
        # Names escape every literal tilde as ~0. An unescaped ~2 therefore
        # unambiguously introduces a full GUID selector, never a name suffix.
        if '~2' in part:
            part, selector = part.rsplit('~2', 1)
            if not re.match(r'\A[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\Z', selector):
                raise BridgeError('INVALID_PATH', 'Object selector must be a full GUID')
        if not part or re.search(r'~(?![01])', part):
            raise BridgeError('INVALID_PATH', 'Invalid escaped object name')
        result.append((part.replace('~1', '/').replace('~0', '~'), selector))
    return result


def parse_utc(value):
    require_text(value, 'timestamp')
    if not re.match(r'^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d{1,6})?Z$', value):
        raise BridgeError('INVALID_REQUEST', 'Timestamps must be UTC ISO 8601 with Z')
    try:
        return datetime.datetime.strptime(value, '%Y-%m-%dT%H:%M:%S.%fZ' if '.' in value else '%Y-%m-%dT%H:%M:%SZ')
    except ValueError:
        raise BridgeError('INVALID_REQUEST', 'Invalid UTC timestamp')


def validate_request(request, filename_id, ready, now=None):
    if not isinstance(request, dict):
        raise BridgeError('INVALID_REQUEST', 'Request must be an object')
    if not UUID_RE.match(filename_id) or request.get('id') != filename_id:
        raise BridgeError('IDENTITY_MISMATCH', 'Request UUID does not match its filename')
    for key in ('protocolVersion', 'sessionId', 'nonce', 'pid', 'projectIdentity'):
        if request.get(key) != ready[key]:
            raise BridgeError('IDENTITY_MISMATCH', 'Request identity differs: ' + key)
    if request.get('action') not in ACTIONS or not isinstance(request.get('args', {}), dict):
        raise BridgeError('INVALID_REQUEST', 'Unknown action or invalid args')
    if request.get('createdAt') is not None:
        parse_utc(request['createdAt'])
    if request.get('deadlineUtc') is not None:
        deadline = parse_utc(request['deadlineUtc'])
        if (now or datetime.datetime.utcnow()) >= deadline:
            raise BridgeError('EXPIRED', 'Request expired before IDE execution')
    return request


def read_json(path):
    if os.path.getsize(path) > MAX_REQUEST_BYTES:
        raise BridgeError('INVALID_REQUEST', 'JSON file exceeds the 4 MiB limit')
    with io.open(path, 'r', encoding='utf-8-sig') as handle:
        return json.load(handle)


def atomic_json(path, value):
    temporary = path + '.' + str(uuid.uuid4()) + '.tmp'
    with io.open(temporary, 'w', encoding='utf-8') as handle:
        handle.write(text_type(json.dumps(value, ensure_ascii=False, indent=2)))
        handle.flush()
    if sys.platform == 'cli':
        from System.IO import File
        if File.Exists(path):
            File.Replace(temporary, path, None)
        else:
            File.Move(temporary, path)
    else:
        os.replace(temporary, path)


def child_records(obj):
    return [{'name': text_type(child.get_name()), 'id': text_type(child.guid)}
            for child in obj.get_children(False)]


def resolve(project, path):
    obj = project
    inspected = 0
    for name, selector in object_segments(path):
        children = list(obj.get_children(False))
        inspected += len(children)
        if inspected > 20000:
            raise BridgeError('TREE_TOO_LARGE', 'Path lookup exceeds the 20000 inspected object limit')
        matches = [child for child in children if text_type(child.get_name()) == name
                   and (selector is None or text_type(child.guid).lower() == selector.lower())]
        if len(matches) != 1:
            raise BridgeError('OBJECT_NOT_UNIQUE', 'Expected exactly one object at ' + path)
        obj = matches[0]
    return obj


def source_metadata(obj):
    """Only PLCopen's own body tag identifies ST; textual also includes IL.

    A declaration of a graphical POU is readable but not its complete source.
    Export failure/unknown extensions conservatively disable ST replacement.
    """
    result = {'language': 'unknown', 'sourceKind': 'unknown',
              'sourceComplete': False, 'languageSource': 'unknown'}
    try:
        xml = text_type(obj.export_xml(recursive=False, declarations_as_plaintext=True))
        # IronPython 2.7's XML parser expects encoded bytes for non-ASCII/BOM input.
        root = ElementTree.fromstring(xml.encode('utf-8'))
        name = text_type(obj.get_name())
        local = lambda tag: tag.rsplit('}', 1)[-1].lower()
        kinds = {'datatype': 'DUT', 'globalvars': 'GVL', 'pou': 'POU', 'interface': 'INTERFACE', 'property': 'PROPERTY',
                 'method': 'METHOD', 'action': 'ACTION', 'transition': 'TRANSITION'}
        matches = [node for node in root.iter()
                   if local(node.tag) in kinds and node.get('name') == name]
        if len(matches) != 1:
            return result
        node = matches[0]
        result['sourceKind'] = kinds[local(node.tag)]
        result['languageSource'] = 'plcopenxml'
        if result['sourceKind'] == 'POU' and node.get('pouType') in ('program', 'functionBlock', 'function'):
            result['pouType'] = node.get('pouType')
        if result['sourceKind'] in ('DUT', 'GVL', 'INTERFACE') or (result['sourceKind'] == 'PROPERTY' and not bool(getattr(obj, 'has_textual_implementation', False))):
            result['sourceComplete'] = bool(getattr(obj, 'has_textual_declaration', False))
            return result
        bodies = [child for child in node if local(child.tag) == 'body']
        if len(bodies) == 1:
            languages = [local(child.tag).upper() for child in bodies[0]
                         if local(child.tag) in ('st', 'il', 'ld', 'fbd', 'sfc')]
            if len(languages) == 1:
                result['language'] = languages[0]
                result['sourceComplete'] = (languages[0] == 'ST'
                                           and bool(getattr(obj, 'has_textual_implementation', False)))
    except Exception as error:
        result['languageDetectionError'] = text_type(error)
    return result


def read_source(obj, path, metadata=True):
    has_declaration = bool(getattr(obj, 'has_textual_declaration', False))
    has_implementation = bool(getattr(obj, 'has_textual_implementation', False))
    if not has_declaration and not has_implementation:
        raise BridgeError('NOT_TEXTUAL', 'Object has no textual source: ' + path)
    declaration = text_type(obj.textual_declaration.text) if has_declaration else u''
    implementation = text_type(obj.textual_implementation.text) if has_implementation else u''
    result = {'path': path, 'id': text_type(obj.guid), 'declaration': declaration,
            'implementation': implementation, 'hasDeclaration': has_declaration,
            'hasImplementation': has_implementation,
            'text': declaration + (u'\n' + implementation if implementation else u''),
            'sha256': source_sha256(declaration, implementation), 'complete': True,
            'capturedAt': utc_now()}
    if metadata:
        result.update(source_metadata(obj))
    return result


def collect_build_diagnostics(system):
    """Normalize CLR message fields before returning them over the JSON bridge."""
    diagnostics = []
    for category in system.get_message_categories():
        category_name = text_type(system.get_message_category_description(category))
        for message in system.get_message_objects(category):
            original_severity = text_type(message.severity)
            severity = ('error' if original_severity.lower() in ('error', 'fatal') else
                        'warning' if original_severity.lower() == 'warning' else 'info')
            message_text = text_type(message.text)
            location = {}
            try:
                position = message.position
                for key in ('line', 'column', 'offset'):
                    if hasattr(position, key): location[key] = int(getattr(position, key))
            except Exception:
                pass
            object_path = None
            object_id = None
            try:
                current, segments, visited = message.object, [], set()
                object_id = text_type(current.guid) if current is not None else None
                while current is not None and hasattr(current, 'get_name') and len(segments) < 128:
                    identity = text_type(current.guid)
                    if identity in visited: break
                    visited.add(identity)
                    parent = getattr(current, 'parent', None)
                    if parent is None: break
                    name = text_type(current.get_name())
                    segment = path_segment(name)
                    if sum(1 for c in parent.get_children(False) if text_type(c.get_name()) == name) > 1: segment += '~2' + identity
                    segments.insert(0, segment)
                    current = parent
                if segments: object_path = '/' + '/'.join(segments)
            except Exception:
                pass
            diagnostics.append({
                'category': text_type(category), 'categoryName': category_name,
                'severity': severity, 'message': message_text,
                'originalSeverity': original_severity, 'text': message_text,
                'number': int(message.number) if message.number is not None else None,
                'prefix': text_type(message.prefix) if message.prefix is not None else None,
                'position': text_type(message.position_text) if message.position_text is not None else None,
                'object': text_type(message.object.get_name()) if message.object is not None else None,
                'objectPath': object_path, 'objectId': object_id, 'location': location})
    return diagnostics


class BoundBridge(object):
    def __init__(self, engine, project, config, pid):
        self.engine, self.project = engine, project
        self.path = os.path.normcase(os.path.abspath(text_type(project.path)))
        self.handle = int(project.handle)
        self.authorization_key = config.get('authorizationKey', '')
        self.directory = config.get('ipcDirectory')
        self.used_grants = set()
        # New object kinds stay disabled until native IDE acceptance is recorded.
        self.verified_create_kinds = ['PROGRAM', 'FUNCTION_BLOCK', 'GVL', 'DUT', 'METHOD', 'ACTION']
        self.ready = {'protocolVersion': PROTOCOL, 'status': 'ready',
                      'sessionId': config['sessionId'], 'nonce': config['nonce'], 'pid': pid,
                      'projectIdentity': {'path': text_type(project.path), 'handle': self.handle,
                                          'instanceId': str(uuid.uuid4())},
                      'actions': list(ACTIONS), 'startedAt': utc_now(),
                      'adapter': 'experimental-sp20-scriptengine', 'officialMcp': False,
                      'bridgeSourceSha256': hashlib.sha256(open(__file__, 'rb').read()).hexdigest(),
                      'isolatedTestProject': True, 'writeAuthorization': 'hmac-sha256-v1',
                      'verifiedCreateKinds': self.verified_create_kinds}

    def authorize_write(self, request):
        auth = request.get('authorization', {})
        payload, signature = auth.get('payload'), auth.get('signature')
        if not self.authorization_key or not isinstance(payload, text_type) or not isinstance(signature, text_type):
            raise BridgeError('UNAUTHORIZED_WRITE', 'A signed, approved v0.2 batch operation is required')
        expected = hmac.new(self.authorization_key.encode('utf-8'), payload.encode('utf-8'), hashlib.sha256).hexdigest()
        # compare_digest is not available in every IronPython build.
        if len(signature) != len(expected) or sum(ord(a) ^ ord(b) for a, b in zip(signature, expected)) != 0:
            raise BridgeError('UNAUTHORIZED_WRITE', 'Invalid operation signature')
        grant = json.loads(payload)
        for key in ('sessionId', 'projectIdentity', 'action', 'args'):
            wanted = self.ready[key] if key in ('sessionId', 'projectIdentity') else request.get(key, {})
            if grant.get(key) != wanted:
                raise BridgeError('UNAUTHORIZED_WRITE', 'Signed operation differs: ' + key)
        if parse_utc(grant.get('expiresAt')) <= datetime.datetime.utcnow():
            raise BridgeError('UNAUTHORIZED_WRITE', 'Batch approval expired')
        for key in ('grantId', 'batchId', 'operationId'):
            if not isinstance(grant.get(key), text_type) or not UUID_RE.match(grant[key]):
                raise BridgeError('UNAUTHORIZED_WRITE', 'Invalid batch grant identity')
        marker = None
        if self.directory:
            marker = os.path.join(self.directory, 'grant-' + grant['batchId'] + '-' + grant['operationId'] + '.used.json')
        operation = grant['batchId'] + ':' + grant['operationId']
        if operation in self.used_grants or (marker and os.path.exists(marker)):
            raise BridgeError('AUTHORIZATION_REPLAY', 'Operation was already consumed; inspect outcome, never retry')
        if marker:
            atomic_json(marker, {'batchId': grant['batchId'], 'operationId': grant['operationId'], 'requestId': request['id'], 'at': utc_now()})
        self.used_grants.add(operation)

    def assert_bound(self):
        current = self.engine.projects.primary
        if current is None or int(current.handle) != self.handle:
            raise BridgeError('PROJECT_CHANGED', 'Bound primary project was closed or replaced')
        current_path = os.path.normcase(os.path.abspath(text_type(current.path)))
        if current_path != self.path or int(self.project.handle) != self.handle:
            raise BridgeError('PROJECT_CHANGED', 'Bound project identity changed')

    def inventory(self):
        objects = []

        def walk(parent, parent_path, depth, children=None):
            children = list(parent.get_children(False)) if children is None else children
            if children and depth >= 128:
                raise BridgeError('TREE_TOO_DEEP', 'Tree exceeds the 128 level limit',
                                  details={'parentPath': parent_path})
            if len(objects) + len(children) > 20000:
                raise BridgeError('TREE_TOO_LARGE', 'Tree exceeds the 20000 object limit')
            names, sibling_ids = {}, set()
            for child in children:
                name, identity = text_type(child.get_name()), text_type(child.guid)
                key = (name, identity.lower())
                if key in sibling_ids:
                    raise BridgeError('AMBIGUOUS_TREE', 'Duplicate sibling name and GUID',
                                      details={'parentPath': parent_path, 'name': name, 'id': identity})
                sibling_ids.add(key)
                names[name] = names.get(name, 0) + 1
            for child in children:
                name, identity = text_type(child.get_name()), text_type(child.guid)
                segment = path_segment(name)
                grandchildren = list(child.get_children(False))
                if names[name] > 1:
                    if not re.match(r'\A[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\Z', identity):
                        raise BridgeError('INVALID_OBJECT_ID', 'Duplicate names require full GUID identities',
                                          details={'parentPath': parent_path, 'name': name, 'id': identity})
                    segment += '~2' + identity
                path = ('' if parent_path == '/' else parent_path) + '/' + segment
                objects.append({'path': path, 'parentPath': parent_path, 'name': name, 'id': identity,
                                'typeGuid': text_type(child.type),
                                'isApplication': bool(getattr(child, 'is_application', False)),
                                'hasDeclaration': bool(getattr(child, 'has_textual_declaration', False)),
                                'hasImplementation': bool(getattr(child, 'has_textual_implementation', False)),
                                'childrenSha256': child_fingerprint([{'name': text_type(c.get_name()), 'id': text_type(c.guid)} for c in grandchildren])})
                if len(objects) > 20000:
                    raise BridgeError('TREE_TOO_LARGE', 'Tree exceeds the 20000 object limit')
                # The same GUID can occur in distinct hierarchy branches. Do
                # not prune or reject those appearances using a global set.
                walk(child, path, depth + 1, grandchildren)
        root_children = list(self.project.get_children(False))
        walk(self.project, '/', 0, root_children)
        return {'rootPath': '/', 'objects': objects, 'treeComplete': True,
                'inventorySha256': sha256(canonical(objects)),
                'rootChildrenSha256': child_fingerprint([{'name': text_type(c.get_name()), 'id': text_type(c.guid)} for c in root_children]), 'capturedAt': utc_now()}

    def context(self):
        result = {'tasks': [], 'devices': [], 'io': [], 'libraries': [], 'issues': [], 'capturedAt': utc_now()}
        inventory = self.inventory()
        for entry in inventory['objects']:
            obj = resolve(self.project, entry['path'])
            def attempt(section, function):
                try:
                    result[section].append({'path': entry['path'], 'status': 'available', 'data': function()})
                except Exception as exc:
                    result['issues'].append({'path': entry['path'], 'section': section, 'status': 'failed', 'reason': text_type(exc)})
            if bool(getattr(obj, 'is_task', False)):
                attempt('tasks', lambda: {'kind': text_type(obj.kind_of_task), 'priority': text_type(obj.priority),
                    'interval': text_type(obj.interval), 'intervalUnit': text_type(obj.interval_unit),
                    'pous': [text_type(p) for p in obj.pous]})
            if bool(getattr(obj, 'is_device', False)):
                attempt('devices', lambda: {'identification': text_type(obj.get_device_identification())})
                def mappings():
                    values = []
                    def visit(element, depth=0):
                        if depth > 32 or len(values) >= 20000:
                            raise BridgeError('CONTEXT_LIMIT', 'I/O traversal limit reached')
                        if bool(getattr(element, 'is_mappable_io', False)):
                            mapping = element.io_mapping
                            values.append({'name': text_type(element.visible_name), 'identifier': text_type(element.identifier),
                                'variable': text_type(mapping.variable), 'address': text_type(mapping.manual_iec_address),
                                'defaultValue': text_type(getattr(element, 'default_value', '')), 'unit': text_type(getattr(element, 'unit', ''))})
                        if bool(getattr(element, 'has_sub_elements', False)):
                            for child in element: visit(child, depth + 1)
                    for connector in obj.connectors:
                        for parameter in connector.host_parameters: visit(parameter)
                    for parameter in obj.device_parameters: visit(parameter)
                    return values
                attempt('io', mappings)
            if bool(getattr(obj, 'is_libman', False)) or hasattr(obj, 'get_libraries'):
                def libraries():
                    values = []
                    # SP20 get_libraries returns names, while references exposes
                    # ScriptLibraryReference objects (including placeholders).
                    for name in obj.get_libraries(False):
                        ref = obj.references[name]
                        item = {'name': text_type(name), 'namespace': text_type(ref.namespace),
                                'isManaged': bool(ref.is_managed), 'isPlaceholder': bool(ref.is_placeholder)}
                        if item['isManaged']:
                            item['resolved'] = text_type(ref.managed_library)
                        elif item['isPlaceholder']:
                            item['resolved'] = text_type(ref.effective_resolution)
                        values.append(item)
                    return values
                attempt('libraries', libraries)
        result['coverage'] = {}
        for section in ('tasks', 'devices', 'io', 'libraries'):
            failures = [i for i in result['issues'] if i['section'] == section]
            result['coverage'][section] = {'status': 'failed' if failures else 'available' if result[section] else 'unsupported',
                'reason': None if result[section] else 'No readable instance exposed by this adapter; absence is not proven'}
        return result

    def replacement(self, obj, path, args, before=None, created=False):
        declaration = normalized_source(args.get('declaration'), 'declaration')
        implementation = requested_implementation(args)
        before = before or read_source(obj, path)
        if not before['sourceComplete'] or (before['language'] != 'ST' and before['sourceKind'] not in ('DUT', 'GVL', 'INTERFACE', 'PROPERTY')):
            raise BridgeError('UNSUPPORTED_LANGUAGE', 'ST replacement requires a confirmed ST body or a complete GVL/DUT declaration')
        if not before['hasDeclaration'] and declaration:
            raise BridgeError('NOT_TEXTUAL', 'Object cannot accept a declaration')
        if not before['hasImplementation'] and implementation:
            raise BridgeError('NOT_TEXTUAL', 'Object cannot accept an implementation')
        try:
            if before['hasDeclaration']:
                obj.textual_declaration.replace(new_text=declaration)
            if before['hasImplementation']:
                obj.textual_implementation.replace(new_text=implementation)
            after = read_source(obj, path)
            if after['declaration'] != declaration or after['implementation'] != implementation:
                raise BridgeError('READBACK_MISMATCH', 'IDE source differs from requested LF-normalized source', True, after)
            return {'created': created, 'verified': True, 'saved': False,
                    'beforeSha256': None if created else before['sha256'], 'readback': after}
        except BridgeError as exc:
            exc.partial = True
            raise
        except Exception as exc:
            try:
                details = read_source(obj, path)
            except Exception:
                details = {'path': path, 'readbackUnavailable': True}
            raise BridgeError('WRITE_FAILED', text_type(exc), True, details)

    def compile_application(self, application_path):
        application = resolve(self.project, application_path)
        if not bool(getattr(application, 'is_application', False)):
            raise BridgeError('INVALID_APPLICATION', 'Compile target must be an Application object')
        # rebuild() can return normally even with compiler errors. Clear stale
        # categories, run the complete rebuild, then inspect every diagnostic.
        system = self.engine.system
        previous = collect_build_diagnostics(system)
        for category in system.get_message_categories():
            system.clear_messages(category)
        returned, exception = False, None
        try:
            application.rebuild()
            returned = True
        except Exception as error:
            exception = text_type(error)
        self.assert_bound()
        diagnostics = collect_build_diagnostics(system)
        errors = sum(1 for item in diagnostics if item['severity'] == 'error')
        warnings = sum(1 for item in diagnostics if item['severity'] == 'warning')
        return {'applicationPath': application_path, 'fullBuild': True,
                'rebuildReturned': returned, 'success': returned and exception is None and errors == 0,
                'exception': exception, 'diagnostics': diagnostics, 'previousDiagnostics': previous,
                'newDiagnostics': [item for item in diagnostics if item not in previous],
                'errorCount': errors, 'warningCount': warnings,
                'saved': False, 'plcConnected': False, 'completedAt': utc_now()}

    def execute(self, request):
        validate_request(request, request['id'], self.ready)
        self.assert_bound()
        action, args = request['action'], request.get('args', {})
        if action in ('replace_st', 'create_st'):
            self.authorize_write(request)
        if action == 'ping':
            return {'pong': True, 'projectIdentity': self.ready['projectIdentity'], 'capturedAt': utc_now()}
        if action == 'project_info':
            ide_version = None
            if sys.platform == 'cli':
                from System.Diagnostics import Process
                ide_version = text_type(Process.GetCurrentProcess().MainModule.FileVersionInfo.FileVersion)
            return {'projectIdentity': self.ready['projectIdentity'], 'projectPath': text_type(self.project.path),
                    'ideVersion': ide_version,
                    'primary': True, 'rootPath': '/', 'dirty': getattr(self.project, 'dirty', None), 'savedByBridge': False, 'capturedAt': utc_now()}
        if action == 'capabilities':
            return {'actions': list(ACTIONS), 'writeAuthorization': 'hmac-sha256-v1', 'verifiedCreateKinds': self.verified_create_kinds,
                    'implementedUnverifiedKinds': ['FUNCTION', 'INTERFACE', 'PROPERTY', 'DUT_ENUM', 'DUT_ALIAS', 'DUT_UNION'], 'runtimeControl': False}
        if action == 'context':
            return self.context()
        if action == 'list':
            return self.inventory()
        if action == 'read':
            path = args.get('path')
            return read_source(resolve(self.project, path), path)
        if action == 'read_many':
            paths = args.get('paths')
            if not isinstance(paths, list) or not 1 <= len(paths) <= 25:
                raise BridgeError('INVALID_REQUEST', 'read_many requires 1..25 paths')
            values, size = [], 0
            for path in paths:
                try:
                    source = read_source(resolve(self.project, path), path)
                    length = len(canonical(source).encode('utf-8'))
                    if size + length > 1024 * 1024:
                        values.append({'ok': True, 'path': path, 'paged': True, 'sha256': source['sha256']})
                    else:
                        values.append({'ok': True, 'source': source})
                        size += length
                except Exception as exc:
                    values.append({'ok': False, 'path': path, 'error': {'code': getattr(exc, 'code', 'READ_FAILED'), 'message': text_type(exc)}})
            return {'objects': values, 'complete': True, 'capturedAt': utc_now()}
        if action == 'fingerprint_many':
            paths = args.get('paths')
            if not isinstance(paths, list) or not 1 <= len(paths) <= 25:
                raise BridgeError('INVALID_REQUEST', 'fingerprint_many requires 1..25 paths')
            values = []
            for path in paths:
                try:
                    source = read_source(resolve(self.project, path), path, metadata=False)
                    values.append({'ok': True, 'source': {'path': path, 'id': source['id'], 'sha256': source['sha256'], 'capturedAt': source['capturedAt']}})
                except Exception as exc:
                    values.append({'ok': False, 'path': path, 'error': text_type(exc)})
            return {'objects': values, 'complete': True, 'metadataCoverageVerified': False}
        if action == 'read_page':
            path, part, cursor = args.get('path'), args.get('part'), args.get('cursor')
            count = args.get('maxChars', 65536)
            if part not in ('declaration', 'implementation') or not isinstance(cursor, int) or isinstance(cursor, bool) or cursor < 0 or not isinstance(count, int) or not 1 <= count <= 65536:
                raise BridgeError('INVALID_REQUEST', 'Invalid page bounds')
            source = read_source(resolve(self.project, path), path)
            value = source[part]
            if cursor > len(value): raise BridgeError('INVALID_REQUEST', 'Page cursor past end')
            end = min(cursor + count, len(value))
            # Avoid splitting UTF-16 surrogate pairs in IronPython.
            if end < len(value) and end > cursor and 0xD800 <= ord(value[end - 1]) <= 0xDBFF: end -= 1
            return {'path': path, 'id': source['id'], 'sha256': source['sha256'], 'sourceComplete': source['sourceComplete'],
                    'sourceKind': source['sourceKind'], 'language': source['language'], 'part': part, 'cursor': cursor,
                    'chunk': value[cursor:end], 'nextCursor': end if end < len(value) else None}
        if action == 'compile':
            if args.get('fullBuild') is not True:
                raise BridgeError('INVALID_REQUEST', 'compile requires fullBuild: true')
            return self.compile_application(args.get('applicationPath'))
        if action == 'replace_st':
            path = args.get('path')
            obj = resolve(self.project, path)
            before = read_source(obj, path)
            if args.get('expectedObjectId') is not None and text_type(obj.guid) != args['expectedObjectId']:
                raise BridgeError('CONFLICT', 'Target GUID changed since approval', False, before)
            expected = args.get('expectedSha256')
            if not isinstance(expected, text_type) or not SHA_RE.match(expected):
                raise BridgeError('INVALID_REQUEST', 'expectedSha256 must be a SHA256 digest')
            if before['sha256'] != expected:
                raise BridgeError('CONFLICT', 'Source changed since baseline read', False, before)
            return self.replacement(obj, path, args, before)
        if action == 'create_st':
            parent_path = args.get('parentPath')
            parent = resolve(self.project, parent_path)
            if args.get('expectedParentId') is not None and text_type(parent.guid) != args['expectedParentId']:
                raise BridgeError('CONFLICT', 'Parent GUID changed since approval')
            name = require_text(args.get('name'), 'name')
            if not re.match(r'^[A-Za-z_][A-Za-z0-9_]*$', name):
                raise BridgeError('INVALID_REQUEST', 'Creation requires an ASCII IEC identifier')
            kind = args.get('kind')
            if kind not in ('PROGRAM', 'FUNCTION_BLOCK', 'FUNCTION', 'GVL', 'DUT', 'METHOD', 'ACTION', 'INTERFACE', 'PROPERTY'):
                raise BridgeError('INVALID_REQUEST', 'Unsupported object kind')
            if kind not in self.verified_create_kinds:
                raise BridgeError('KIND_UNVERIFIED', 'Object kind awaits native IDE validation: ' + kind)
            dut_kind = args.get('dutKind', 'Structure')
            if kind == 'DUT' and dut_kind != 'Structure' and ('DUT_' + dut_kind.upper()) not in self.verified_create_kinds:
                raise BridgeError('KIND_UNVERIFIED', 'DUT subtype awaits native IDE validation: ' + dut_kind)
            # Validate all source fields before any creation side effects.
            declaration = normalized_source(args.get('declaration'), 'declaration')
            implementation = requested_implementation(args)
            if kind in ('GVL', 'DUT', 'INTERFACE', 'PROPERTY') and implementation:
                raise BridgeError('INVALID_REQUEST', 'GVL and DUT do not have implementations')
            if kind == 'ACTION' and declaration:
                raise BridgeError('INVALID_REQUEST', 'ACTION has no declaration; submit an empty string')
            children = child_records(parent)
            if args.get('expectedChildrenSha256') != child_fingerprint(children):
                raise BridgeError('CONFLICT', 'Parent children changed or baseline is missing')
            if any(child['name'].lower() == name.lower() for child in children):
                raise BridgeError('ALREADY_EXISTS', 'An object with this name already exists')
            if kind == 'METHOD':
                parent_source = read_source(parent, parent_path)['declaration']
                if not re.search(r'(?im)^\s*FUNCTION_BLOCK\s+', parent_source):
                    raise BridgeError('INVALID_PARENT', 'METHOD requires a function block parent')
            if kind == 'ACTION':
                parent_metadata = source_metadata(parent)
                if parent_metadata.get('sourceKind') != 'POU' or parent_metadata.get('pouType') not in ('program', 'functionBlock'):
                    raise BridgeError('INVALID_PARENT', 'ACTION requires a PLCopen-confirmed PROGRAM or FUNCTION_BLOCK parent')
            path = ('' if parent_path == '/' else parent_path) + '/' + path_segment(name)
            try:
                if kind in ('PROGRAM', 'FUNCTION_BLOCK', 'FUNCTION'):
                    pou_type = getattr(self.engine.PouType, {'PROGRAM': 'Program', 'FUNCTION_BLOCK': 'FunctionBlock', 'FUNCTION': 'Function'}[kind])
                    options = {'name': name, 'type': pou_type, 'language': self.engine.ImplementationLanguages.st}
                    if kind == 'FUNCTION': options['return_type'] = args.get('returnType')
                    obj = parent.create_pou(**options)
                elif kind == 'GVL':
                    obj = parent.create_gvl(name)
                elif kind == 'DUT':
                    if dut_kind not in ('Structure', 'Enumeration', 'Alias', 'Union'):
                        raise BridgeError('INVALID_REQUEST', 'Unsupported DUT subtype')
                    options = {'name': name, 'type': getattr(self.engine.DutType, dut_kind)}
                    if dut_kind == 'Alias': options['baseType'] = args.get('baseType')
                    obj = parent.create_dut(name, self.engine.DutType.Structure) if dut_kind == 'Structure' else parent.create_dut(**options)
                elif kind == 'INTERFACE':
                    obj = parent.create_interface(name)
                elif kind == 'PROPERTY':
                    obj = parent.create_property(name=name, return_type=args.get('returnType', 'BOOL'), language=self.engine.ImplementationLanguages.st)
                elif kind == 'ACTION':
                    obj = parent.create_action(name=name, language=self.engine.ImplementationLanguages.st)
                else:
                    obj = parent.create_method(name=name, language=self.engine.ImplementationLanguages.st)
                obj = resolve(self.project, path) if obj is None else obj
                return self.replacement(obj, path, args, created=True)
            except BridgeError as exc:
                exc.partial = True
                raise
            except Exception as exc:
                raise BridgeError('CREATE_FAILED', text_type(exc), True, {'path': path})
        raise BridgeError('INVALID_REQUEST', 'Action is unavailable')

    def respond(self, request, filename_id):
        response = {key: self.ready[key] for key in ('protocolVersion', 'sessionId', 'nonce', 'pid', 'projectIdentity')}
        response['id'] = filename_id
        try:
            validate_request(request, filename_id, self.ready)
            response.update({'ok': True, 'result': self.execute(request)})
        except Exception as exc:
            response.update({'ok': False, 'error': {'code': getattr(exc, 'code', 'IDE_ERROR'),
                             'message': text_type(exc), 'partial': getattr(exc, 'partial', False),
                             'details': getattr(exc, 'details', None)}})
        response['completedAt'] = utc_now()
        return response


def validate_bootstrap(config):
    if not isinstance(config, dict) or config.get('protocolVersion') != PROTOCOL:
        raise BridgeError('INVALID_BOOTSTRAP', 'Expected protocolVersion 1')
    for key in ('sessionId', 'nonce', 'ipcDirectory', 'projectPath'):
        require_text(config.get(key), key)
    if not UUID_RE.match(config['sessionId']) or len(config['nonce']) < 32:
        raise BridgeError('INVALID_BOOTSTRAP', 'Expected UUID sessionId and nonce of at least 32 characters')
    if config.get('mode') not in ('create', 'open') or config.get('isolatedTestProject') is not True:
        raise BridgeError('INVALID_BOOTSTRAP', 'Only isolated test project create/open is supported')
    for key in ('ipcDirectory', 'projectPath'):
        if not os.path.isabs(config[key]):
            raise BridgeError('INVALID_BOOTSTRAP', key + ' must be absolute')
    sandbox = os.path.normcase(os.path.realpath(os.path.join(os.path.dirname(__file__), '..', 'artifacts')))
    project = os.path.normcase(os.path.realpath(config['projectPath']))
    if not project.startswith(sandbox + os.sep) or not project.lower().endswith('.project'):
        raise BridgeError('INVALID_BOOTSTRAP', 'Experimental bridge projects must be below this repository artifacts directory')
    return config


def start(config):
    import clr
    import scriptengine as se
    from System import GC, IntPtr
    from System.Diagnostics import Process
    from System.Threading import Thread, ThreadStart, ManualResetEvent
    validate_bootstrap(config)
    directory = config['ipcDirectory']
    if not os.path.isdir(directory):
        os.makedirs(directory)
    # Never reuse an IPC session after a crash; this avoids replaying uncertain writes.
    lock = os.open(os.path.join(directory, 'session.lock'), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    os.close(lock)
    if se.projects.primary is not None:
        raise BridgeError('EXISTING_PROJECT', 'Start a new IDE with no primary project')
    path = config['projectPath']
    if config['mode'] == 'create':
        if os.path.exists(path):
            raise BridgeError('ALREADY_EXISTS', 'Refusing to overwrite an existing project')
        project = se.projects.create(path, primary=True)
    else:
        if not os.path.isfile(path):
            raise BridgeError('NOT_FOUND', 'Independent project copy does not exist')
        project = se.projects.open(path, primary=True,
                    update_flags=se.VersionUpdateFlags.NoUpdates | se.VersionUpdateFlags.SilentMode)
    bridge = BoundBridge(se, project, config, Process.GetCurrentProcess().Id)
    bridge.assert_bound()

    def dispatch(callback):
        done = ManualResetEvent(False)
        state = {}
        def invoke():
            try:
                state['result'] = callback()
            except Exception as exc:
                state['error'] = exc
            finally:
                done.Set()
        # Positional True selects SP20's async overload, leaving the worker free
        # to report an unknown outcome. Callback checks deadline before any write.
        se.system.execute_on_primary_thread(invoke, True)
        if not done.WaitOne(120000):
            raise BridgeError('EXECUTION_UNKNOWN', 'Primary thread did not finish within 120 seconds', True)
        if 'error' in state:
            raise state['error']
        return state.get('result')

    def log(message):
        with io.open(os.path.join(directory, 'bridge.log'), 'a', encoding='utf-8') as handle:
            handle.write(utc_now() + u' ' + text_type(message) + u'\n')

    def worker():
        try:
            # Startup script has returned and primary-thread dispatch is proven.
            dispatch(bridge.assert_bound)
            atomic_json(os.path.join(directory, 'ready.json'), bridge.ready)
            log('ready')
            while True:
                stop_path = os.path.join(directory, 'stop.json')
                if os.path.isfile(stop_path):
                    stop = read_json(stop_path)
                    if stop.get('sessionId') == config['sessionId'] and stop.get('nonce') == config['nonce']:
                        log('worker stopped; IDE and project left open')
                        return
                process = Process.GetCurrentProcess()
                process.Refresh()
                if process.MainWindowHandle == IntPtr.Zero:
                    log('IDE window closed; worker stopped')
                    return
                names = [name for name in os.listdir(directory) if name.endswith('.req.json') and UUID_RE.match(name[:-9])]
                names.sort(key=lambda name: (os.path.getmtime(os.path.join(directory, name)), name))
                for name in names:
                    request_id = name[:-9]
                    output = os.path.join(directory, request_id + '.res.json')
                    if os.path.exists(output):
                        continue
                    request = read_json(os.path.join(directory, name))
                    # Mark every started operation durably. Never retry after an
                    # ambiguous timeout; only read-only client reconciliation is safe.
                    atomic_json(os.path.join(directory, request_id + '.started.json'), {'id': request_id, 'startedAt': utc_now()})
                    try:
                        response = dispatch(lambda: bridge.respond(request, request_id))
                    except BridgeError as exc:
                        response = {key: bridge.ready[key] for key in ('protocolVersion', 'sessionId', 'nonce', 'pid', 'projectIdentity')}
                        response.update({'id': request_id, 'ok': False, 'completedAt': utc_now(),
                                         'error': {'code': exc.code, 'message': text_type(exc), 'partial': exc.partial}})
                        atomic_json(output, response)
                        # A queued callback may still complete. Stop dispatching
                        # after unknown execution; no subsequent write can race it.
                        if exc.code == 'EXECUTION_UNKNOWN':
                            log('execution unknown; worker stopped; inspect IDE before restarting')
                            return
                    atomic_json(output, response)
                Thread.Sleep(100)
        except Exception as exc:
            log('worker failed: ' + text_type(exc))
            atomic_json(os.path.join(directory, 'worker-error.json'), {'ok': False, 'error': text_type(exc), 'completedAt': utc_now()})

    thread = Thread(ThreadStart(worker))
    thread.IsBackground = False
    thread.Start()
    GC.KeepAlive(thread)
    return bridge


if __name__ == '__main__':
    configuration = None
    try:
        if len(sys.argv) != 2:
            raise BridgeError('INVALID_BOOTSTRAP', 'Pass exactly one bootstrap JSON filename via --scriptargs')
        configuration = read_json(sys.argv[1])
        start(configuration)
    except Exception as error:
        if isinstance(configuration, dict) and os.path.isdir(configuration.get('ipcDirectory', '')):
            atomic_json(os.path.join(configuration['ipcDirectory'], 'startup-error.json'),
                        {'ok': False, 'error': text_type(error), 'completedAt': utc_now()})
        raise
