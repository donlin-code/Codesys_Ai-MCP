import { resolve, join } from "node:path";
import { mkdir, writeFile } from "node:fs/promises";
import { ensureService, rpc } from "../dist/src/service-client.js";

const args = process.argv.slice(2);
const option = (name) => {
  const i = args.indexOf("--" + name);
  return i < 0 ? undefined : args[i + 1];
};
if (!option("config") || !option("data"))
  throw new Error(
    "Pass --config <fresh test bridge> --data <shared service directory>; optional --application and --replace-path",
  );
const data = resolve(option("data"));
const endpoint = await ensureService(data, resolve(option("config")));
const call = async (name, arguments_ = {}) =>
  (await rpc(endpoint, { method: "tools/call", name, arguments: arguments_ }))
    .result;
const status = await call("codesys_status");
if (!status.guardedWrites || status.state !== "online")
  throw new Error(
    "A fresh matching isolated test bridge with guarded writes is required",
  );
const tree = await call("codesys_list_objects");
const applications = tree.objects.filter((o) => o.isApplication);
const applicationPath =
  option("application") ??
  (applications.length === 1 ? applications[0].path : undefined);
if (!applicationPath || !applications.some((o) => o.path === applicationPath))
  throw new Error(
    "Select an Application from the actual tree with --application",
  );
const objects = [
  {
    name: "ST_McpV02Smoke",
    kind: "DUT",
    declaration:
      "TYPE ST_McpV02Smoke :\nSTRUCT\n    xRequest : BOOL;\n    uiCommand : UINT;\nEND_STRUCT\nEND_TYPE",
    implementation: "",
  },
  {
    name: "GVL_McpV02Smoke",
    kind: "GVL",
    declaration:
      "VAR_GLOBAL\n    xRequest : BOOL := FALSE;\nEND_VAR\nVAR_GLOBAL CONSTANT\n    uiSchema : UINT := 2;\nEND_VAR",
    implementation: "",
  },
  {
    name: "PRG_McpV02Smoke",
    kind: "PROGRAM",
    declaration:
      "PROGRAM PRG_McpV02Smoke\nVAR\n    stCommand : ST_McpV02Smoke;\n    xObserved : BOOL;\nEND_VAR",
    implementation:
      "(* 仅用于隔离工程源码与编译验收；不接物理 I/O，不加入任务。 *)\nstCommand.xRequest := GVL_McpV02Smoke.xRequest;\nxObserved := stCommand.xRequest;",
  },
];
const operations = objects.map((args) => ({
  action: "create_st",
  args: { parentPath: applicationPath, ...args },
}));
if (option("replace-path")) {
  const path = option("replace-path");
  if (!path.startsWith(applicationPath + "/"))
    throw new Error(
      "Replacement must be within the selected isolated Application",
    );
  const before = await call("codesys_read_object", { path });
  if (!before.sourceComplete || before.language !== "ST")
    throw new Error("Replacement requires complete ST source");
  operations.push({
    action: "replace_st",
    args: {
      path,
      declaration: before.declaration,
      implementation:
        before.implementation +
        "\n(* v0.2 signed-write and independent-readback smoke marker; no logic change. *)",
    },
  });
}
const batch = await call("codesys_batch_prepare", {
  applicationPath,
  operations,
});
const review = join(data, "review", batch.id);
await mkdir(review, { recursive: true });
await writeFile(
  join(review, "plan.json"),
  JSON.stringify(batch, null, 2) + "\n",
);
await writeFile(
  join(review, "focused.diff"),
  batch.operations.map((o) => o.diff).join("\n"),
);
await writeFile(
  join(review, "README.md"),
  `# 原生验收待审批批次\n\n工程：${batch.session.projectIdentity.path}\n\nApplication：${applicationPath}\n\n计划哈希：${batch.planHash}\n\n新建通用 DUT、GVL、PROGRAM；程序不加入任务，不接物理 I/O。若指定替换路径，只添加验收注释。无下载、启动、强制或保存。\n\n准备阶段未写入 IDE。请审阅 focused.diff，在本机工作台批准后逐项执行、回读并完整编译。保存重开由用户操作。故意编译错误及修复需要后续独立批次。\n`,
);
console.log(
  JSON.stringify(
    {
      batchId: batch.id,
      planHash: batch.planHash,
      review,
      workbench: endpoint.url,
      ideWritten: false,
    },
    null,
    2,
  ),
);
