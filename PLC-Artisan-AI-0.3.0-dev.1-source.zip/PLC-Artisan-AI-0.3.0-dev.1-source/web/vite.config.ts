import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
export default defineConfig({
  root: "web",
  plugins: [react()],
  build: {
    outDir: "../web-dist",
    emptyOutDir: true,
    chunkSizeWarningLimit: 1500,
  },
  server: { host: "127.0.0.1" },
});
