import { test, expect } from "@playwright/test";
import { readFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { readdir } from "node:fs/promises";
import { join } from "node:path";
async function login(page: any) {
  const dirs = (await readdir(tmpdir())).filter((n) =>
    n.startsWith("donlinxg-web-e2e-"),
  );
  let endpoint: any;
  for (const d of dirs) {
    try {
      const e = JSON.parse(
        await readFile(join(tmpdir(), d, "service.json"), "utf8"),
      );
      if (
        e.url === "http://127.0.0.1:18765" &&
        (!endpoint || e.startedAt > endpoint.startedAt)
      )
        endpoint = e;
    } catch {}
  }
  expect(endpoint).toBeTruthy();
  await page.goto(endpoint.url + "/#ticket=" + endpoint.browserTicket);
  await expect(
    page.getByRole("heading", { name: "PLC 工程工作台" }),
  ).toBeVisible();
}
test("fixture UI reads code, creates exact diff, requires explicit review, writes and rebuilds", async ({
  page,
}) => {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await login(page);
  await expect(page.locator(".brand")).toContainText("PLC工匠 AI");
  await page.getByRole("button", { name: "逻辑诊断" }).click();
  await expect(
    page.getByRole("textbox", { name: "Search expression" }),
  ).toHaveValue("");
  await expect(
    page.getByRole("button", { name: "变量交叉引用" }),
  ).toBeDisabled();
  await page.getByRole("button", { name: "工程与源码" }).click();
  await page.getByRole("button", { name: "PRG_Test" }).click();
  await expect(page.locator(".monaco").first()).toBeVisible();
  await page.locator(".monaco").first().click();
  await page.keyboard.press("Control+A");
  await page.keyboard.type("GVL_IO.abDO[11] := TRUE;");
  await page.getByRole("button", { name: "生成修改批次" }).click();
  await expect(page.getByRole("heading", { name: "修改审批" })).toBeVisible();
  const approve = page.getByRole("button", { name: "批准这一批" });
  await expect(approve).toBeDisabled();
  await page.getByRole("checkbox").check();
  await expect(approve).toBeEnabled();
  await approve.click();
  await page.getByRole("button", { name: "执行下一项并回读" }).click();
  await expect(page.getByText("verified", { exact: true })).toBeVisible();
  await page.getByRole("button", { name: "完整编译", exact: true }).click();
  await expect(page.getByText("完整编译结果", { exact: true })).toBeVisible();
  await page.screenshot({
    path: "artifacts/web-tests/batch-review.png",
    fullPage: true,
  });
  expect(errors).toEqual([]);
});
test("standard catalogue, bilingual navigation, model settings and read-only telemetry render", async ({
  page,
}) => {
  await login(page);
  await page.getByRole("button", { name: "标准与规则" }).click();
  await expect(
    page.getByRole("heading", { name: "IEC 62443", exact: true }),
  ).toBeVisible();
  await expect(
    page.getByRole("heading", { name: "IEC 61784-3", exact: true }),
  ).toBeVisible();
  await page.screenshot({
    path: "artifacts/web-tests/standards.png",
    fullPage: true,
  });
  await page.getByRole("button", { name: "模型与资料" }).click();
  await expect(
    page.getByText("API key (DPAPI)", { exact: true }),
  ).toBeVisible();
  await page.getByRole("button", { name: "运行数据" }).click();
  await expect(
    page.getByRole("heading", { name: "只读通信配置" }),
  ).toBeVisible();
  await page.getByRole("button", { name: "中文 / English" }).click();
  await expect(
    page.getByRole("heading", { name: "Read-only connections" }),
  ).toBeVisible();
});

test("creation UI only offers verified kinds and prepares an unapproved concrete addition", async ({
  page,
}) => {
  await login(page);
  await page.getByText("新建 ST 对象草稿", { exact: true }).click();
  await page.getByRole("button", { name: "读取创建能力" }).click();
  const kind = page.getByLabel("对象类型");
  await expect(kind.locator("option")).toHaveText(["PROGRAM"]);
  await page.getByLabel("对象名称").fill("PRG_NewFixture");
  await page.getByRole("button", { name: "生成声明骨架" }).click();
  await page.getByRole("button", { name: "生成新建批次" }).click();
  await expect(page.getByRole("heading", { name: "修改审批" })).toBeVisible();
  const batch = page
    .locator(".batch")
    .filter({ hasText: "/Fixture/Application/PRG_NewFixture" });
  await expect(
    batch.getByRole("button", { name: "批准这一批" }),
  ).toBeDisabled();
  await expect(batch).toContainText("PROGRAM PRG_NewFixture");
});
