import { defineConfig } from "@playwright/test";
import { fileURLToPath } from "node:url";
export default defineConfig({
  testDir: "./tests",
  outputDir: "../artifacts/web-tests",
  timeout: 45000,
  retries: 0,
  workers: 1,
  use: {
    channel: "msedge",
    headless: true,
    viewport: { width: 1440, height: 1080 },
    screenshot: "only-on-failure",
    trace: "retain-on-failure",
  },
  reporter: [
    ["list"],
    ["json", { outputFile: "artifacts/web-tests/results.json" }],
  ],
  webServer: {
    command: "node tests/fixtures/workbench.mjs",
    cwd: fileURLToPath(new URL("..", import.meta.url)),
    url: "http://127.0.0.1:18765",
    timeout: 30000,
    reuseExistingServer: false,
    stdout: "pipe",
  },
});
