import React, { useEffect, useRef } from "react";
import * as echarts from "echarts/core";
import { LineChart } from "echarts/charts";
import {
  GridComponent,
  TooltipComponent,
  LegendComponent,
} from "echarts/components";
import { CanvasRenderer } from "echarts/renderers";
echarts.use([
  LineChart,
  GridComponent,
  TooltipComponent,
  LegendComponent,
  CanvasRenderer,
]);
export default function Trend({ samples }: { samples: any[] }) {
  const el = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!el.current) return;
    const chart = echarts.init(el.current, "dark");
    const ids = [...new Set(samples.map((s) => s.point))];
    chart.setOption({
      backgroundColor: "transparent",
      tooltip: { trigger: "axis" },
      legend: { data: ids },
      grid: { left: 55, right: 25, top: 45, bottom: 40 },
      xAxis: { type: "time" },
      yAxis: { type: "value" },
      series: ids.map((id) => ({
        name: id,
        type: "line",
        showSymbol: false,
        connectNulls: false,
        data: samples
          .filter((s) => s.point === id)
          .map((s) => [
            s.receivedAt,
            s.quality === "Good" && !s.stale
              ? typeof s.value === "boolean"
                ? Number(s.value)
                : typeof s.value === "number"
                  ? s.value
                  : null
              : null,
          ]),
      })),
    });
    const resize = new ResizeObserver(() => chart.resize());
    resize.observe(el.current);
    return () => {
      resize.disconnect();
      chart.dispose();
    };
  }, [samples]);
  return <div className="trend" ref={el} />;
}
