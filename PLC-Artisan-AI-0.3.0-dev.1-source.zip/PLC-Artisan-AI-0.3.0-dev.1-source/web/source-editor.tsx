import React, { useEffect, useRef } from "react";
import * as monaco from "monaco-editor/editor/editor.api";
import EditorWorker from "monaco-editor/editor/editor.worker?worker";
(self as any).MonacoEnvironment = { getWorker: () => new EditorWorker() };
monaco.languages.register({ id: "structured-text" });
monaco.languages.setMonarchTokensProvider("structured-text", {
  tokenizer: {
    root: [
      [/\(\*/, "comment", "@comment"],
      [/\/\/.*$/, "comment"],
      [/'(?:[^'$]|\$.)*'/, "string"],
      [
        /\b(?:IF|THEN|ELSE|ELSIF|END_IF|CASE|OF|END_CASE|VAR|VAR_INPUT|VAR_OUTPUT|END_VAR|PROGRAM|FUNCTION_BLOCK|FUNCTION|METHOD|TYPE|STRUCT|END_STRUCT|END_TYPE|TRUE|FALSE|FOR|DO|END_FOR|WHILE|END_WHILE|RETAIN|PERSISTENT|CONSTANT)\b/i,
        "keyword",
      ],
      [/\b\d+(?:\.\d+)?\b/, "number"],
    ],
    comment: [
      [/[^(*]+/, "comment"],
      [/\*\)/, "comment", "@pop"],
      [/[(*]/, "comment"],
    ],
  },
});
export default function SourceEditor({
  text,
  original,
  onChange,
  readOnly = false,
  diff = false,
}: {
  text: string;
  original?: string;
  onChange?: (v: string) => void;
  readOnly?: boolean;
  diff?: boolean;
}) {
  const el = useRef<HTMLDivElement>(null),
    editor = useRef<any>(null),
    onEdit = useRef(onChange);
  onEdit.current = onChange;
  useEffect(() => {
    if (!el.current) return;
    const model = monaco.editor.createModel(text, "structured-text");
    const before = diff
      ? monaco.editor.createModel(original ?? "", "structured-text")
      : null;
    const instance = diff
      ? monaco.editor.createDiffEditor(el.current, {
          theme: "vs-dark",
          readOnly: true,
          automaticLayout: true,
          minimap: { enabled: false },
          renderSideBySide: true,
        })
      : monaco.editor.create(el.current, {
          model,
          theme: "vs-dark",
          readOnly,
          automaticLayout: true,
          minimap: { enabled: false },
          fontSize: 13,
          tabSize: 4,
          scrollBeyondLastLine: false,
        });
    if (diff) (instance as any).setModel({ original: before, modified: model });
    editor.current = { instance, model, before };
    const sub = model.onDidChangeContent(() =>
      onEdit.current?.(model.getValue()),
    );
    return () => {
      sub.dispose();
      instance.dispose();
      model.dispose();
      before?.dispose();
      editor.current = null;
    };
  }, [diff, readOnly]);
  useEffect(() => {
    if (editor.current && editor.current.model.getValue() !== text)
      editor.current.model.setValue(text);
    if (
      editor.current?.before &&
      editor.current.before.getValue() !== (original ?? "")
    )
      editor.current.before.setValue(original ?? "");
  }, [text, original]);
  return <div className="monaco" ref={el} />;
}
