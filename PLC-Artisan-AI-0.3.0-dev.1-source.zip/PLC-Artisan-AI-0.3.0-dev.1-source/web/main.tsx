import React, { useState, useEffect, useRef, lazy, Suspense } from "react";
import { createRoot } from "react-dom/client";
import "./style.css";
import { CreateObject, ReconcileWrite } from "./engineering-controls";
const Editor = lazy(() => import("./source-editor"));
const Trend = lazy(() => import("./trend"));
let csrf = "";
async function api(path: string, body?: any) {
  const response = await fetch(
    "/api/" + path,
    body === undefined
      ? {}
      : {
          method: "POST",
          headers: { "Content-Type": "application/json", "X-CSRF-Token": csrf },
          body: JSON.stringify(body),
        },
  );
  const result = await response.json();
  if (!response.ok || result?.ok === false)
    throw new Error(result.error?.message ?? "Request failed");
  return result;
}
const tool = (name: string, args = {}) =>
  api("tool", { name, arguments: args });
const pretty = (value: any) => JSON.stringify(value, null, 2);
function download(name: string, value: any) {
  const url = URL.createObjectURL(
    new Blob([pretty(value)], { type: "application/json" }),
  );
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  URL.revokeObjectURL(url);
}

function App() {
  const [language, setLanguage] = useState("zh"),
    [tab, setTab] = useState("project"),
    [authenticated, setAuthenticated] = useState(false),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  const [status, setStatus] = useState<any>({ state: "disconnected" }),
    [snapshot, setSnapshot] = useState<any>(null),
    [tree, setTree] = useState<any[]>([]),
    [application, setApplication] = useState(""),
    [config, setConfig] = useState(
      "artifacts/sp20-bridge/current-session.json",
    );
  const [selected, setSelected] = useState<any>(null),
    [part, setPart] = useState<"declaration" | "implementation">(
      "implementation",
    ),
    [draft, setDraft] = useState(""),
    [analysis, setAnalysis] = useState<any>(null),
    [query, setQuery] = useState(""),
    [search, setSearch] = useState<any>(null);
  const [batches, setBatches] = useState<any[]>([]),
    [reviewed, setReviewed] = useState<string>(""),
    [result, setResult] = useState<any>(null),
    [standards, setStandards] = useState<any[]>([]);
  const [providers, setProviders] = useState<any[]>([]),
    [providerId, setProviderId] = useState(""),
    [provider, setProvider] = useState<any>({
      name: "",
      kind: "openai-chat",
      baseUrl: "https://api.openai.com/v1",
      model: "",
      apiKey: "",
      keyEnv: "",
      supportsTools: true,
    });
  const [prompt, setPrompt] = useState(
      "分析当前代码的启动、状态机和命令优先级，提出带源码定位的建议。",
    ),
    [selections, setSelections] = useState<any[]>([]),
    [preview, setPreview] = useState<any>(null),
    [chat, setChat] = useState(""),
    [aiBusy, setAiBusy] = useState(false);
  const controller = useRef<AbortController | null>(null);
  const [followSelected, setFollowSelected] = useState(false);
  const [telemetry, setTelemetry] = useState<any>({
      configs: [],
      connections: [],
    }),
    [history, setHistory] = useState<any[]>([]),
    [connectionText, setConnectionText] = useState(
      pretty({
        id: "local-modbus",
        protocol: "modbus-tcp",
        host: "127.0.0.1",
        port: 1502,
        unitId: 1,
        intervalMs: 500,
        points: [
          {
            id: "counter",
            fc: 3,
            address: 0,
            addressBase: "zero",
            dataType: "UINT",
            byteOrder: "BE",
            wordOrder: "high-low",
          },
        ],
      }),
    );
  const [model, setModel] = useState("cylinder"),
    [scenario, setScenario] = useState(""),
    [harness, setHarness] = useState<any>(null),
    [manual, setManual] = useState(""),
    [regression, setRegression] = useState<any>(null),
    [roots, setRoots] = useState(""),
    [documents, setDocuments] = useState<any>(null),
    [gitFiles, setGitFiles] = useState(""),
    [gitMessage, setGitMessage] = useState("Engineering checkpoint");
  const t = (zh: string, en: string) => (language === "zh" ? zh : en);
  async function run(action: () => Promise<any>) {
    setBusy(true);
    setError("");
    try {
      return await action();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function refresh() {
    const current = await api("status");
    setStatus(current);
    setBatches(await api("batches"));
    setSnapshot(await api("snapshot"));
    return current;
  }
  useEffect(() => {
    void (async () => {
      try {
        const ticket = new URLSearchParams(location.hash.slice(1)).get(
          "ticket",
        );
        const session = ticket
          ? await api("session", { ticket })
          : await api("session");
        csrf = session.csrf;
        historyReplace();
        setAuthenticated(true);
        const current = await refresh();
        if (["online", "unresolved-write"].includes(current.state)) {
          const inventory = await tool("codesys_list_objects");
          setTree(inventory.objects);
          setApplication(
            inventory.objects.find((o: any) => o.isApplication)?.path ?? "",
          );
        }
        setStandards(await api("standards"));
        setRoots((await api("documents")).join("\n"));
      } catch (e) {
        setError((e as Error).message);
      }
    })();
  }, []);
  useEffect(() => {
    if (authenticated && ["ai", "settings"].includes(tab))
      void api("providers")
        .then(setProviders)
        .catch((e) => setError(e.message));
  }, [authenticated, tab]);
  useEffect(() => {
    if (
      !followSelected ||
      !authenticated ||
      !selected ||
      busy ||
      draft !== selected[part] ||
      !snapshot?.objects.some((o: any) => o.path === selected.path)
    )
      return;
    let stopped = false;
    let timer: ReturnType<typeof setTimeout>;
    const poll = async () => {
      try {
        const observation = await tool("codesys_refresh", {
          paths: [selected.path],
        });
        if (!stopped && observation.changedPaths.length) {
          const fresh = await api("snapshot");
          if (!stopped) {
            const object = fresh.objects.find(
              (o: any) => o.path === selected.path,
            );
            setSnapshot(fresh);
            setSelected(object);
            setDraft(object[part]);
            setAnalysis(null);
            setPreview(null);
          }
        }
      } catch (e) {
        if (!stopped) {
          setFollowSelected(false);
          setError((e as Error).message);
        }
      } finally {
        if (!stopped) timer = setTimeout(poll, 1000);
      }
    };
    timer = setTimeout(poll, 1000);
    return () => {
      stopped = true;
      clearTimeout(timer);
    };
  }, [
    followSelected,
    authenticated,
    selected?.path,
    selected?.sha256,
    part,
    draft,
    busy,
    snapshot,
  ]);
  useEffect(() => {
    if (!authenticated) return;
    const timer = setInterval(() => {
      void api("status")
        .then(setStatus)
        .catch(() => {});
      if (tab === "telemetry")
        void api("telemetry")
          .then(setTelemetry)
          .catch(() => {});
    }, 1500);
    return () => clearInterval(timer);
  }, [authenticated, tab]);
  useEffect(() => {
    if (selected) setDraft(selected[part] ?? "");
  }, [selected?.path, part]);
  const apps = tree.filter((o) => o.isApplication),
    objects = snapshot?.objects ?? [];
  const [languageEdition, setLanguageEdition] = useState<"2013" | "2025">(
    "2013",
  );
  const request = { providerId, prompt, selections, languageEdition };
  function selectObject(o: any) {
    setSelected(o);
    setDraft(o[part] ?? "");
    setPreview(null);
  }
  function addScope() {
    if (!selected) return;
    setSelections((prev: any[]) => [
      ...prev.filter((s) => s.path !== selected.path),
      ...(["declaration", "implementation"] as const).map((p) => ({
        path: selected.path,
        part: p,
        startLine: 1,
        endLine: selected[p].split("\n").length,
        sha256: selected.sha256,
      })),
    ]);
    setPreview(null);
  }
  async function startAI() {
    setAiBusy(true);
    setError("");
    setChat("");
    controller.current = new AbortController();
    try {
      await api("ai/consent", request);
      const response = await fetch("/api/ai/run", {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-CSRF-Token": csrf },
        body: JSON.stringify(request),
        signal: controller.current.signal,
      });
      if (!response.ok || !response.body) throw new Error("AI request failed");
      const reader = response.body.getReader(),
        decoder = new TextDecoder();
      let buffer = "";
      while (true) {
        const { value, done } = await reader.read();
        buffer += decoder.decode(value, { stream: !done });
        let end;
        while ((end = buffer.indexOf("\n")) >= 0) {
          const line = buffer.slice(0, end);
          buffer = buffer.slice(end + 1);
          if (!line) continue;
          const event = JSON.parse(line);
          if (event.type === "stale") {
            setChat(
              t(
                "源码已变化或请求已取消，本轮结果已失效。",
                "Source changed or request cancelled; this result is stale.",
              ),
            );
            continue;
          }
          setChat(
            (text) =>
              text +
              (event.type === "text"
                ? event.text
                : "\n[" + event.type + "] " + pretty(event) + "\n"),
          );
        }
        if (done) break;
      }
      await refresh();
    } catch (e) {
      if ((e as Error).name !== "AbortError") setError((e as Error).message);
    } finally {
      setAiBusy(false);
      setPreview(null);
    }
  }
  return (
    <div className="shell">
      <aside>
        <div className="brand">
          <span className="logo">PA</span>
          <div>
            {t("PLC工匠 AI", "PLC Artisan AI")}
            <span>CODESYS AI-MCP</span>
          </div>
        </div>
        <div className="version">v0.3 dev · {status.adapter ?? "offline"}</div>
        <nav>
          {[
            ["project", "工程与源码", "Project"],
            ["analysis", "逻辑诊断", "Analysis"],
            ["batches", "修改审批", "Batches"],
            ["ai", "AI 助手", "AI assistant"],
            ["telemetry", "运行数据", "Telemetry"],
            ["regression", "仿真回归", "Regression"],
            ["standards", "标准与规则", "Standards"],
            ["settings", "模型与资料", "Settings"],
          ].map(([id, zh, en]) => (
            <button
              key={id}
              className={tab === id ? "active" : ""}
              onClick={() => setTab(id)}
            >
              {t(zh, en)}
              {id === "batches" &&
                batches.filter((b) => !b.approval && !b.halted).length > 0 && (
                  <i>
                    {batches.filter((b) => !b.approval && !b.halted).length}
                  </i>
                )}
            </button>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <span
            className={"dot " + (status.state === "online" ? "online" : "")}
          />
          {status.state}
          <p>
            {t(
              "源码 / 编译 / 仿真分别验证",
              "Source / build / behavior verified separately",
            )}
          </p>
          <button onClick={() => setLanguage(language === "zh" ? "en" : "zh")}>
            中文 / English
          </button>
        </div>
      </aside>
      <main>
        <header>
          <div>
            <span className="eyebrow">LOCAL ENGINEERING WORKSPACE</span>
            <h1>{t("PLC 工程工作台", "PLC engineering workbench")}</h1>
          </div>
          <div className="header-actions">
            <span className="pill">
              {status.guardedWrites
                ? t("受控编辑", "Guarded edit")
                : t("只读 / 待连接", "Read only / disconnected")}
            </span>
            <button
              disabled={!authenticated || busy}
              onClick={() =>
                run(async () =>
                  download("engineering-report.json", await api("report")),
                )
              }
            >
              {t("导出报告", "Export report")}
            </button>
          </div>
        </header>
        {error && (
          <div role="alert" className="error">
            {error}
          </div>
        )}
        {!authenticated && (
          <section className="card">
            <h2>{t("需要本机启动链接", "Local launcher link required")}</h2>
            <p>
              {t(
                "运行 scripts/Start-Workbench.ps1，通过包含 ticket 的链接进入。",
                "Run scripts/Start-Workbench.ps1 and open its ticket link.",
              )}
            </p>
          </section>
        )}
        {authenticated && (
          <>
            {tab === "project" && (
              <>
                <section className="card toolbar">
                  <label>
                    {t("测试副本桥接配置", "Test-copy bridge configuration")}
                    <input
                      value={config}
                      onChange={(e) => setConfig(e.target.value)}
                    />
                  </label>
                  <button
                    className="primary"
                    disabled={busy}
                    onClick={() =>
                      run(async () => {
                        setStatus(await api("connect", { config }));
                        const r = await tool("codesys_list_objects");
                        setTree(r.objects);
                        const app = r.objects.find((o: any) => o.isApplication);
                        if (app) setApplication(app.path);
                      })
                    }
                  >
                    {t("连接工程", "Connect")}
                  </button>
                  <button
                    disabled={busy}
                    onClick={() =>
                      run(async () => setResult(await api("doctor", {})))
                    }
                  >
                    {t("环境检查", "Doctor")}
                  </button>
                </section>
                <div className="metrics">
                  <Metric
                    name={t("工程身份", "Project identity")}
                    value={
                      status.session?.projectIdentity?.path
                        ?.split(/[\\/]/)
                        .pop() ?? "—"
                    }
                  />
                  <Metric
                    name={t("完整 ST 对象", "Complete ST objects")}
                    value={objects.length}
                  />
                  <Metric
                    name={t("采集耗时", "Capture time")}
                    value={
                      snapshot
                        ? (snapshot.metrics.elapsedMs / 1000).toFixed(2) + " s"
                        : "—"
                    }
                  />
                  <Metric
                    name={t("未保存", "Unsaved")}
                    value={status.dirty === null ? "—" : String(status.dirty)}
                  />
                </div>
                <section className="card">
                  <div className="toolbar">
                    <select
                      value={application}
                      onChange={(e) => setApplication(e.target.value)}
                      aria-label="Application"
                    >
                      <option value="">Application</option>
                      {apps.map((o) => (
                        <option key={o.path} value={o.path}>
                          {o.path}
                        </option>
                      ))}
                    </select>
                    <button
                      disabled={!application || busy}
                      onClick={() =>
                        run(async () => {
                          const s = await tool("codesys_snapshot", {
                            applicationPath: application,
                          });
                          setSnapshot(s);
                          if (s.objects.length) selectObject(s.objects[0]);
                        })
                      }
                      className="primary"
                    >
                      {t("采集并校验源码", "Capture & verify")}
                    </button>
                    <button
                      disabled={!application || busy}
                      onClick={() =>
                        run(async () =>
                          setResult(await tool("codesys_context")),
                        )
                      }
                    >
                      {t("任务 / I/O / 库", "Tasks / I/O / libraries")}
                    </button>
                  </div>
                  {status.progress && <p>{pretty(status.progress)}</p>}
                  {snapshot && (
                    <p className="muted">
                      {snapshot.freshness} · {snapshot.issues.length}{" "}
                      {t(
                        "项读取缺口；采集不是原子快照",
                        "coverage gaps; capture is not atomic",
                      )}
                    </p>
                  )}
                </section>
                <div className="editor-grid">
                  <section className="card object-list">
                    <h2>{t("程序对象", "Source objects")}</h2>
                    {objects.map((o: any) => (
                      <button
                        className={selected?.path === o.path ? "selected" : ""}
                        key={o.path}
                        onClick={() => selectObject(o)}
                      >
                        <span>{o.path.split("/").pop()}</span>
                        <small>{o.sourceKind}</small>
                      </button>
                    ))}
                    {!objects.length && (
                      <p className="empty">
                        {t(
                          "连接后采集 Application",
                          "Connect and capture an Application",
                        )}
                      </p>
                    )}
                    {snapshot?.issues.map((i: any) => (
                      <small className="gap" key={i.path}>
                        {i.path}: {i.reason}
                      </small>
                    ))}
                  </section>
                  <section className="card source">
                    <label>
                      <input
                        type="checkbox"
                        checked={followSelected}
                        onChange={(e) => setFollowSelected(e.target.checked)}
                      />
                      {t(
                        "跟随当前对象（轮询；编辑草稿时暂停）",
                        "Follow selected object (polling; paused while drafting)",
                      )}
                    </label>
                    <div className="toolbar">
                      <strong>
                        {selected?.path.split("/").pop() ??
                          t("源码草稿", "Source draft")}
                      </strong>
                      <select
                        value={part}
                        onChange={(e) => setPart(e.target.value as any)}
                      >
                        <option value="declaration">
                          {t("声明", "Declaration")}
                        </option>
                        <option value="implementation">
                          {t("实现", "Implementation")}
                        </option>
                      </select>
                      <button
                        disabled={!selected || busy}
                        onClick={() =>
                          run(async () =>
                            setResult(
                              await tool("codesys_format_st", {
                                text: draft,
                              }).then((r) => {
                                if (r.changed) setDraft(r.text);
                                return r;
                              }),
                            ),
                          )
                        }
                      >
                        {t("格式预览", "Format preview")}
                      </button>
                    </div>
                    <Suspense fallback={<p>Loading editor…</p>}>
                      <Editor text={draft} onChange={setDraft} />
                    </Suspense>
                    <div className="toolbar">
                      <button
                        disabled={!selected || busy}
                        onClick={() =>
                          run(async () =>
                            setResult(
                              await tool("codesys_check_st", {
                                path: selected.path,
                                declaration:
                                  part === "declaration"
                                    ? draft
                                    : selected.declaration,
                                implementation:
                                  part === "implementation"
                                    ? draft
                                    : selected.implementation,
                              }),
                            ),
                          )
                        }
                      >
                        {t("检查草稿", "Check draft")}
                      </button>
                      <button
                        className="primary"
                        disabled={
                          !selected || busy || draft === selected?.[part]
                        }
                        onClick={() =>
                          run(async () => {
                            await tool("codesys_batch_prepare", {
                              applicationPath:
                                application || snapshot.applicationPath,
                              operations: [
                                {
                                  action: "replace_st",
                                  args: {
                                    path: selected.path,
                                    declaration:
                                      part === "declaration"
                                        ? draft
                                        : selected.declaration,
                                    implementation:
                                      part === "implementation"
                                        ? draft
                                        : selected.implementation,
                                  },
                                },
                              ],
                            });
                            await refresh();
                            setTab("batches");
                          })
                        }
                      >
                        {t("生成修改批次", "Prepare edit batch")}
                      </button>
                      <button
                        disabled={!selected}
                        onClick={() => {
                          addScope();
                          setTab("ai");
                        }}
                      >
                        {t("加入 AI 范围", "Select for AI")}
                      </button>
                    </div>
                    <small className="muted">
                      {t(
                        "编辑只修改草稿；批准后才写入 IDE。",
                        "Editing changes drafts only. IDE writes require approval.",
                      )}
                    </small>
                  </section>
                </div>
                <CreateObject
                  application={application || snapshot?.applicationPath || ""}
                  tree={tree.length ? tree : (snapshot?.inventory ?? [])}
                  t={t}
                  getCapabilities={() => tool("codesys_capabilities")}
                  onPrepare={async (args) => {
                    await tool("codesys_batch_prepare", {
                      applicationPath: application || snapshot.applicationPath,
                      operations: [{ action: "create_st", args }],
                    });
                    await refresh();
                    setTab("batches");
                  }}
                />
                {result && (
                  <Details title={t("操作结果", "Result")} value={result} />
                )}
              </>
            )}
            {tab === "analysis" && (
              <>
                <section className="card toolbar">
                  <button
                    className="primary"
                    disabled={!snapshot || busy}
                    onClick={() =>
                      run(async () =>
                        setAnalysis(await tool("codesys_analyze")),
                      )
                    }
                  >
                    {t("分析已采集源码", "Analyze captured source")}
                  </button>
                  <input
                    aria-label="Search expression"
                    placeholder={t(
                      "输入要诊断的变量或表达式",
                      "Enter a variable or expression",
                    )}
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                  />
                  <button
                    disabled={!snapshot || busy || !query.trim()}
                    onClick={() =>
                      run(async () =>
                        setSearch(await tool("codesys_references", { query })),
                      )
                    }
                  >
                    {t("变量交叉引用", "References")}
                  </button>
                  <button
                    disabled={!snapshot || busy || !query.trim()}
                    onClick={() =>
                      run(async () =>
                        setSearch(await tool("codesys_search", { query })),
                      )
                    }
                  >
                    {t("搜索源码", "Search source")}
                  </button>
                </section>
                {analysis && (
                  <>
                    <div className="metrics">
                      <Metric
                        name={t("静态发现", "Static findings")}
                        value={analysis.findings.length}
                      />
                      <Metric
                        name={t("分析缺口", "Analysis gaps")}
                        value={analysis.gaps.length}
                      />
                      <Metric name={t("证据类型", "Evidence")} value="static" />
                    </div>
                    {analysis.findings.map((f: any, i: number) => (
                      <section className="card finding" key={i}>
                        <span className={"tag " + f.severity}>{f.rule}</span>
                        <strong>{f.message}</strong>
                        <p>
                          {f.path} · {f.part}:{f.line}
                        </p>
                        <pre>{f.snippet}</pre>
                        <small>
                          {f.standard} · {f.confidence} · {f.verification}
                        </small>
                      </section>
                    ))}
                    <Details
                      title={t("分析缺口", "Analysis gaps")}
                      value={analysis.gaps}
                    />
                  </>
                )}
                {search && (
                  <Details
                    title={t("查询证据", "Query evidence")}
                    value={search}
                  />
                )}
              </>
            )}
            {tab === "batches" && (
              <>
                <div className="section-heading">
                  <div>
                    <h2>{t("修改审批", "Batch review")}</h2>
                    <p className="muted">
                      {t(
                        "核对完整差异和哈希。批准有效 30 分钟，执行前实时检查。",
                        "Review complete diff and hash. Approval expires after 30 minutes; live baselines are checked.",
                      )}
                    </p>
                  </div>
                  <button onClick={() => run(refresh)}>
                    {t("刷新", "Refresh")}
                  </button>
                </div>
                {!batches.length && (
                  <section className="card empty">
                    {t("尚无修改批次", "No edit batches yet")}
                  </section>
                )}
                {[...batches].reverse().map((b) => (
                  <section className="card batch" key={b.id}>
                    <div className="toolbar">
                      <h2>{b.id.slice(0, 8)}</h2>
                      <span className="pill">
                        {b.halted
                          ? "HALTED"
                          : b.approval
                            ? "APPROVED"
                            : "PENDING"}
                      </span>
                    </div>
                    <p className="path">
                      {b.session.projectIdentity.path}
                      <br />
                      Application: {b.applicationPath}
                      <br />
                      SHA256: {b.planHash}
                    </p>
                    {b.operations.map((o: any) => (
                      <div key={o.id}>
                        <div className="toolbar">
                          <strong>{o.path}</strong>
                          <span className="tag">{o.state}</span>
                        </div>
                        <Suspense fallback={<pre>{o.diff}</pre>}>
                          <Editor
                            original={
                              o.before
                                ? o.before.declaration +
                                  "\n" +
                                  o.before.implementation
                                : ""
                            }
                            text={
                              o.args.declaration + "\n" + o.args.implementation
                            }
                            readOnly
                            diff
                          />
                        </Suspense>
                        <details>
                          <summary>
                            {t("完整差异与执行证据", "Full diff & evidence")}
                          </summary>
                          <pre>{o.diff}</pre>
                          <pre>{pretty(o.result)}</pre>
                        </details>
                        {["unknown", "executing"].includes(o.state) && (
                          <ReconcileWrite
                            batchId={b.id}
                            operation={o}
                            t={t}
                            read={(path) =>
                              tool("codesys_read_object", { path })
                            }
                            reconcile={async (args) => {
                              await tool("codesys_reconcile_write", args);
                              await refresh();
                            }}
                          />
                        )}
                      </div>
                    ))}
                    {!b.approval && !b.halted && (
                      <>
                        <label className="checkbox">
                          <input
                            type="checkbox"
                            checked={reviewed === b.id}
                            onChange={(e) =>
                              setReviewed(e.target.checked ? b.id : "")
                            }
                          />
                          {t(
                            "我已审阅上述工程身份、完整差异和计划哈希",
                            "I reviewed the project identity, complete diff and plan hash",
                          )}
                        </label>
                        <button
                          className="primary"
                          disabled={reviewed !== b.id || busy}
                          onClick={() =>
                            run(async () => {
                              await api("batch/approve", {
                                batchId: b.id,
                                planHash: b.planHash,
                              });
                              setReviewed("");
                              await refresh();
                            })
                          }
                        >
                          {t("批准这一批", "Approve this batch")}
                        </button>
                      </>
                    )}
                    {b.approval && !b.halted && (
                      <div className="toolbar">
                        <small>
                          {t("有效至", "Expires")} {b.approval.expiresAt}
                        </small>
                        <button
                          disabled={
                            busy ||
                            !b.operations.some(
                              (o: any) => o.state === "planned",
                            )
                          }
                          className="primary"
                          onClick={() =>
                            run(async () => {
                              const next = b.operations.find(
                                (o: any) => o.state !== "verified",
                              );
                              if (next)
                                await tool("codesys_batch_execute", {
                                  batchId: b.id,
                                  operationId: next.id,
                                });
                              await refresh();
                            })
                          }
                        >
                          {t("执行下一项并回读", "Execute next & read back")}
                        </button>
                        <button
                          disabled={
                            busy ||
                            b.operations.some(
                              (o: any) => o.state !== "verified",
                            )
                          }
                          onClick={() =>
                            run(async () => {
                              setResult(
                                await tool("codesys_compile", {
                                  applicationPath: b.applicationPath,
                                  fullBuild: true,
                                  batchId: b.id,
                                }),
                              );
                              await refresh();
                            })
                          }
                        >
                          {t("完整编译", "Full rebuild")}
                        </button>
                      </div>
                    )}
                    {b.halted && <p className="error">{b.halted}</p>}
                    {b.compile && (
                      <Details
                        title={t("完整编译结果", "Full build result")}
                        value={b.compile}
                      />
                    )}
                    <p className="muted">
                      {t(
                        "持久化：未验证。请在 IDE 保存、关闭并重开后另行核对。",
                        "Persistence unverified. Save, close and reopen in the IDE, then verify separately.",
                      )}
                    </p>
                  </section>
                ))}
                {result && <Details title="Build" value={result} />}
              </>
            )}
            {tab === "ai" && (
              <div className="ai-grid">
                <section className="card">
                  <h2>{t("分析与生成", "Analyze & generate")}</h2>
                  <label>
                    {t("语言目标", "Language target")}
                    <select
                      value={languageEdition}
                      onChange={(e) => {
                        setLanguageEdition(e.target.value as "2013" | "2025");
                        setPreview(null);
                      }}
                    >
                      <option value="2013">
                        IEC 61131-3:2013 / GB/T 15969.3-2017
                      </option>
                      <option value="2025">
                        IEC 61131-3:2025 —{" "}
                        {t(
                          "未验证新特性保持关闭",
                          "unverified new features disabled",
                        )}
                      </option>
                    </select>
                  </label>
                  <label>
                    {t("模型供应商", "Provider")}
                    <select
                      value={providerId}
                      onChange={(e) => {
                        setProviderId(e.target.value);
                        setPreview(null);
                      }}
                    >
                      <option value="">{t("请选择", "Select")}</option>
                      {providers.map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.name} / {p.model}
                        </option>
                      ))}
                    </select>
                  </label>
                  <label>
                    {t("任务", "Task")}
                    <textarea
                      rows={6}
                      value={prompt}
                      onChange={(e) => {
                        setPrompt(e.target.value);
                        setPreview(null);
                      }}
                    />
                  </label>
                  <h3>{t("本轮源码范围", "Source scope for this request")}</h3>
                  {selections.map((s, i) => (
                    <div className="scope-row" key={s.path + s.part}>
                      <small>
                        {s.path.split("/").pop()} · {s.part}
                      </small>
                      <input
                        type="number"
                        aria-label="Start line"
                        value={s.startLine}
                        onChange={(e) => {
                          setSelections((prev) =>
                            prev.map((v, n) =>
                              n === i
                                ? { ...v, startLine: Number(e.target.value) }
                                : v,
                            ),
                          );
                          setPreview(null);
                        }}
                      />
                      <input
                        type="number"
                        aria-label="End line"
                        value={s.endLine}
                        onChange={(e) => {
                          setSelections((prev) =>
                            prev.map((v, n) =>
                              n === i
                                ? { ...v, endLine: Number(e.target.value) }
                                : v,
                            ),
                          );
                          setPreview(null);
                        }}
                      />
                      <button
                        onClick={() => {
                          setSelections((prev) =>
                            prev.filter((_, n) => n !== i),
                          );
                          setPreview(null);
                        }}
                      >
                        ×
                      </button>
                    </div>
                  ))}
                  <p className="muted">
                    {t(
                      "在工程页选择对象加入范围；可缩小行范围。额外源码不会自动发送。",
                      "Select an object in Project, then narrow line ranges. Additional source is not sent automatically.",
                    )}
                  </p>
                  <button
                    disabled={!providerId || aiBusy || busy}
                    onClick={() =>
                      run(async () =>
                        setPreview(await api("ai/preview", request)),
                      )
                    }
                  >
                    {t("预览发送内容", "Preview sending scope")}
                  </button>
                  {preview && (
                    <div className="consent">
                      <strong>
                        {preview.provider.name} · {preview.provider.baseUrl} ·{" "}
                        {preview.provider.model} · {preview.bytes} bytes
                      </strong>
                      <pre>{preview.text}</pre>
                      <button
                        className="primary"
                        disabled={aiBusy}
                        onClick={startAI}
                      >
                        {t("确认本轮发送并运行", "Confirm sending & run")}
                      </button>
                    </div>
                  )}
                  <button
                    disabled={!aiBusy}
                    onClick={() => controller.current?.abort()}
                  >
                    {t("取消", "Cancel")}
                  </button>
                </section>
                <section className="card">
                  <h2>{t("AI 输出", "AI output")}</h2>
                  <p className="muted">
                    {t(
                      "生成结果为草稿；批准批次后才能编辑工程。",
                      "Generated code is a draft; IDE edits require human batch approval.",
                    )}
                  </p>
                  <pre className="chat-output">
                    {chat || t("等待本轮分析", "Waiting for analysis")}
                  </pre>
                </section>
              </div>
            )}
            {tab === "telemetry" && (
              <>
                <div className="two-columns">
                  <section className="card">
                    <h2>{t("只读通信配置", "Read-only connections")}</h2>
                    <textarea
                      className="json-input"
                      rows={17}
                      value={connectionText}
                      onChange={(e) => setConnectionText(e.target.value)}
                    />
                    <div className="toolbar">
                      <button
                        className="primary"
                        disabled={busy}
                        onClick={() =>
                          run(async () => {
                            await api(
                              "telemetry/config",
                              JSON.parse(connectionText),
                            );
                            setTelemetry(await api("telemetry"));
                          })
                        }
                      >
                        {t("保存点表", "Save point map")}
                      </button>
                      <button
                        disabled={busy}
                        onClick={() =>
                          run(async () =>
                            setResult(
                              await api("telemetry/discover", {
                                endpoint: JSON.parse(connectionText).endpoint,
                              }),
                            ),
                          )
                        }
                      >
                        {t("发现 UA 端点", "Discover UA endpoints")}
                      </button>
                    </div>
                    <p className="muted">
                      {t(
                        "地址基准、功能码、数据类型、字节与字序均需明确。未知 UA 证书不会自动信任。",
                        "Address base, function code, data type and byte/word order must be explicit. Unknown UA certificates are not trusted automatically.",
                      )}
                    </p>
                  </section>
                  <section className="card">
                    <h2>{t("连接与采样", "Connections & samples")}</h2>
                    {telemetry.configs.map((c: any) => (
                      <div key={c.id} className="connection">
                        <strong>{c.id}</strong>
                        <span>{c.protocol}</span>
                        <div className="toolbar">
                          <button
                            onClick={() =>
                              run(async () => {
                                await api("telemetry/start", { id: c.id });
                                setTelemetry(await api("telemetry"));
                              })
                            }
                          >
                            {t("开始读取", "Start reads")}
                          </button>
                          <button
                            onClick={() =>
                              run(async () => {
                                await api("telemetry/stop", { id: c.id });
                                setTelemetry(await api("telemetry"));
                              })
                            }
                          >
                            {t("停止采集", "Stop sampling")}
                          </button>
                          <button
                            onClick={() =>
                              run(async () =>
                                setHistory(
                                  await api("telemetry/history", { id: c.id }),
                                ),
                              )
                            }
                          >
                            {t("查看趋势", "View trend")}
                          </button>
                          <a
                            href={
                              "/api/telemetry/csv?id=" +
                              encodeURIComponent(c.id)
                            }
                          >
                            CSV
                          </a>
                        </div>
                      </div>
                    ))}
                    {telemetry.connections.map((c: any) => (
                      <div key={c.id}>
                        <p>
                          {c.id}: {c.state} {c.error}
                        </p>
                        <table>
                          <thead>
                            <tr>
                              <th>Point</th>
                              <th>Value</th>
                              <th>Quality</th>
                              <th>Time</th>
                            </tr>
                          </thead>
                          <tbody>
                            {c.samples.map((s: any) => (
                              <tr key={s.point}>
                                <td>{s.point}</td>
                                <td>{String(s.value)}</td>
                                <td>
                                  {s.quality}
                                  {s.stale ? " · stale" : ""}
                                </td>
                                <td>{s.receivedAt}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    ))}
                  </section>
                </div>
                <section className="card">
                  <Suspense fallback={<p>Loading chart…</p>}>
                    <Trend samples={history} />
                  </Suspense>
                </section>
                {result && <Details title="OPC UA" value={result} />}
                <section className="card toolbar">
                  <input
                    id="ua-fingerprint"
                    placeholder="Explicit SHA256 certificate fingerprint"
                  />
                  <button
                    onClick={() =>
                      run(async () =>
                        setResult(
                          await api("telemetry/trust", {
                            endpoint: JSON.parse(connectionText).endpoint,
                            fingerprint: (
                              document.getElementById(
                                "ua-fingerprint",
                              ) as HTMLInputElement
                            ).value,
                          }),
                        ),
                      )
                    }
                  >
                    {t("确认信任当前证书", "Trust matching certificate")}
                  </button>
                  <button
                    onClick={() =>
                      run(async () =>
                        setResult(
                          await api("telemetry/browse", {
                            config: JSON.parse(connectionText),
                            nodeId: "RootFolder",
                          }),
                        ),
                      )
                    }
                  >
                    {t("浏览 UA 节点", "Browse UA nodes")}
                  </button>
                  <button
                    onClick={() =>
                      run(async () => {
                        const config = JSON.parse(connectionText);
                        setResult(
                          await api("telemetry/attributes", {
                            config,
                            nodes: config.points.flatMap((p: any) => [
                              { nodeId: p.nodeId, attribute: "Value" },
                              { nodeId: p.nodeId, attribute: "DataType" },
                            ]),
                          }),
                        );
                      })
                    }
                  >
                    {t("读取 UA 值与类型", "Read UA values & types")}
                  </button>
                </section>
              </>
            )}
            {tab === "regression" && (
              <>
                <section className="card">
                  <h2>
                    {t(
                      "离线模型与 IDE 验证",
                      "Offline models & IDE validation",
                    )}
                  </h2>
                  <p className="muted">
                    {t(
                      "模型不执行任意 ST；绑定源码哈希仅用于识别版本，不能证明模型与源码等价。",
                      "Models do not execute arbitrary ST. Source hashes identify versions; they do not prove model/source equivalence.",
                    )}
                  </p>
                  <div className="toolbar">
                    <select
                      value={model}
                      onChange={(e) => setModel(e.target.value)}
                    >
                      <option value="cylinder">Cylinder</option>
                      <option value="initialization">Initialization</option>
                      <option value="axis-handshake">Axis handshake</option>
                    </select>
                    <button
                      disabled={!selected || busy}
                      onClick={() =>
                        run(async () => {
                          const r = await api("regression/prepare", {
                            model,
                            paths: [selected.path],
                          });
                          setScenario(pretty(r.spec));
                          setHarness(r.harness);
                        })
                      }
                    >
                      {t(
                        "为当前对象准备场景",
                        "Prepare scenarios for selected object",
                      )}
                    </button>
                  </div>
                  <textarea
                    rows={15}
                    className="json-input"
                    value={scenario}
                    onChange={(e) => setScenario(e.target.value)}
                  />
                  <button
                    className="primary"
                    disabled={!scenario || busy}
                    onClick={() =>
                      run(async () =>
                        setRegression(
                          await api("regression/run", {
                            spec: JSON.parse(scenario),
                          }),
                        ),
                      )
                    }
                  >
                    {t("运行离线参考模型", "Run offline reference model")}
                  </button>
                  {harness && (
                    <Details
                      title={t(
                        "IDE 测试模板：需要人工接线",
                        "IDE harness: manual wiring required",
                      )}
                      value={harness}
                    />
                  )}
                </section>
                {regression && (
                  <Details
                    title={t(
                      "回归结果及证据类型",
                      "Regression result & evidence type",
                    )}
                    value={regression}
                  />
                )}
                <section className="card">
                  <h2>
                    {t(
                      "导入人工 IDE 仿真证据",
                      "Import human IDE simulation evidence",
                    )}
                  </h2>
                  <textarea
                    rows={8}
                    className="json-input"
                    value={manual}
                    placeholder="Identity, simulation=true, cycleMs, observations, hashed attachments"
                    onChange={(e) => setManual(e.target.value)}
                  />
                  <button
                    disabled={!manual || !scenario || busy}
                    onClick={() =>
                      run(async () =>
                        setRegression(
                          await api("regression/manual", {
                            spec: JSON.parse(scenario),
                            record: JSON.parse(manual),
                          }),
                        ),
                      )
                    }
                  >
                    {t("核对观察结果", "Check observations")}
                  </button>
                </section>
              </>
            )}
            {tab === "standards" && (
              <>
                <section className="card">
                  <h2>
                    {t(
                      "适用标准与生成约束",
                      "Applicable standards & generation rules",
                    )}
                  </h2>
                  <p>
                    {t(
                      "默认 IEC 61131-3:2013 兼容 ST。2025 新特性只有目标编译器实际验证后才启用。命名与缩进属于项目风格。",
                      "Default: IEC 61131-3:2013-compatible ST. New 2025 features require verified target support. Naming and indentation are project style.",
                    )}
                  </p>
                  <p className="muted">
                    {t(
                      "此目录保存标准标识、适用性与检查建议，不包含受版权保护的标准全文，也不构成安全或符合性认证。",
                      "Catalogue includes identifiers, applicability and checks; no licensed standard text or certification claim.",
                    )}
                  </p>
                </section>
                <div className="standards-grid">
                  {standards.map((s) => (
                    <section className="card" key={s.id}>
                      <span className="eyebrow">{s.domain}</span>
                      <h2>{s.id}</h2>
                      <p>{s.purpose}</p>
                      <small className="muted">{s.source}</small>
                    </section>
                  ))}
                </div>
              </>
            )}
            {tab === "settings" && (
              <>
                <section className="card">
                  <h2>{t("模型供应商", "Model providers")}</h2>
                  <div className="form-grid">
                    <label>
                      Name
                      <input
                        value={provider.name}
                        onChange={(e) =>
                          setProvider({ ...provider, name: e.target.value })
                        }
                      />
                    </label>
                    <label>
                      Interface
                      <select
                        value={provider.kind}
                        onChange={(e) =>
                          setProvider({ ...provider, kind: e.target.value })
                        }
                      >
                        <option value="openai-chat">
                          OpenAI Chat Completions
                        </option>
                        <option value="openai-responses">
                          OpenAI Responses
                        </option>
                        <option value="anthropic">Anthropic</option>
                        <option value="gemini">Gemini</option>
                      </select>
                    </label>
                    <label>
                      Base URL
                      <input
                        value={provider.baseUrl}
                        onChange={(e) =>
                          setProvider({ ...provider, baseUrl: e.target.value })
                        }
                      />
                    </label>
                    <label>
                      Model
                      <input
                        value={provider.model}
                        onChange={(e) =>
                          setProvider({ ...provider, model: e.target.value })
                        }
                      />
                    </label>
                    <label>
                      API key (DPAPI)
                      <input
                        type="password"
                        autoComplete="off"
                        value={provider.apiKey}
                        onChange={(e) =>
                          setProvider({ ...provider, apiKey: e.target.value })
                        }
                      />
                    </label>
                    <label>
                      Environment variable
                      <input
                        value={provider.keyEnv}
                        onChange={(e) =>
                          setProvider({ ...provider, keyEnv: e.target.value })
                        }
                      />
                    </label>
                  </div>
                  <label className="checkbox">
                    <input
                      type="checkbox"
                      checked={provider.supportsTools}
                      onChange={(e) =>
                        setProvider({
                          ...provider,
                          supportsTools: e.target.checked,
                        })
                      }
                    />
                    {t(
                      "供应商支持原生工具调用",
                      "Provider supports native tool calls",
                    )}
                  </label>
                  <button
                    className="primary"
                    disabled={busy}
                    onClick={() =>
                      run(async () => {
                        await api("providers", provider);
                        setProvider({ ...provider, apiKey: "" });
                        setProviders(await api("providers"));
                      })
                    }
                  >
                    {t("保存供应商", "Save provider")}
                  </button>
                  {providers.map((p) => (
                    <div className="connection" key={p.id}>
                      <strong>{p.name}</strong>
                      <span>
                        {p.kind} · {p.model} ·{" "}
                        {p.hasKey ? "credential configured" : "no credential"}
                      </span>
                      <button onClick={() => setProvider({ ...p, apiKey: "" })}>
                        {t("编辑", "Edit")}
                      </button>
                    </div>
                  ))}
                </section>
                <section className="card">
                  <h2>
                    {t("授权本地资料目录", "Authorized document directories")}
                  </h2>
                  <textarea
                    rows={3}
                    value={roots}
                    onChange={(e) => setRoots(e.target.value)}
                    placeholder="One absolute directory per line"
                  />
                  <div className="toolbar">
                    <button
                      onClick={() =>
                        run(async () =>
                          setRoots(
                            (
                              await api("documents/roots", {
                                roots: roots.split("\n").filter(Boolean),
                              })
                            ).join("\n"),
                          ),
                        )
                      }
                    >
                      {t("保存目录授权", "Save directory selection")}
                    </button>
                    <input
                      value={query}
                      onChange={(e) => setQuery(e.target.value)}
                    />
                    <button
                      onClick={() =>
                        run(async () =>
                          setDocuments(
                            await api("documents/search", { query }),
                          ),
                        )
                      }
                    >
                      {t("检索资料", "Search documents")}
                    </button>
                  </div>
                  {documents && <Details title="Documents" value={documents} />}
                </section>
                <section className="card">
                  <h2>{t("本地 Git 检查点", "Local Git checkpoints")}</h2>
                  <textarea
                    rows={3}
                    value={gitFiles}
                    onChange={(e) => setGitFiles(e.target.value)}
                    placeholder="Explicit repository-relative source files, one per line"
                  />
                  <input
                    value={gitMessage}
                    onChange={(e) => setGitMessage(e.target.value)}
                  />
                  <div className="toolbar">
                    <button
                      onClick={() =>
                        run(async () => setResult(await api("git")))
                      }
                    >
                      {t("查看状态与差异", "Status & diff")}
                    </button>
                    <button
                      onClick={() =>
                        run(async () =>
                          setResult(
                            await api("git/checkpoint", {
                              files: gitFiles.split("\n").filter(Boolean),
                              message: gitMessage,
                            }),
                          ),
                        )
                      }
                    >
                      {t("提交选定源码", "Commit selected source")}
                    </button>
                  </div>
                  <small>
                    {t(
                      "仅本地提交，不自动推送，不包含会话、凭据或工程副本。",
                      "Local commit only; no push, credentials, sessions or native project copies.",
                    )}
                  </small>
                </section>
                {result && <Details title="Result" value={result} />}
              </>
            )}
          </>
        )}
        <footer>
          PLC Artisan AI ·{" "}
          {t(
            "单编辑者 · 独立测试副本 · 无 PLC 下载 / 启动 / 强制",
            "Single editor · Isolated test copy · No PLC download / start / force",
          )}
        </footer>
      </main>
    </div>
  );
}
function historyReplace() {
  window.history.replaceState(null, "", location.pathname);
}
function Metric({ name, value }: { name: string; value: any }) {
  return (
    <div className="metric">
      <small>{name}</small>
      <strong>{value}</strong>
    </div>
  );
}
function Details({ title, value }: { title: string; value: any }) {
  return (
    <section className="card">
      <details open>
        <summary>{title}</summary>
        <pre>{pretty(value)}</pre>
      </details>
    </section>
  );
}
createRoot(document.getElementById("root")!).render(<App />);
