import { useState, useEffect } from "react";

type Translate = (zh: string, en: string) => string;
export function CreateObject({
  application,
  tree,
  t,
  getCapabilities,
  onPrepare,
}: {
  application: string;
  tree: { path: string }[];
  t: Translate;
  getCapabilities: () => Promise<any>;
  onPrepare: (args: any) => Promise<any>;
}) {
  const [kinds, setKinds] = useState<string[]>([]),
    [kind, setKind] = useState("GVL");
  const [parent, setParent] = useState(""),
    [name, setName] = useState("GVL_New");
  const [declaration, setDeclaration] = useState(
    "VAR_GLOBAL\n    xReady : BOOL;\nEND_VAR",
  );
  const [implementation, setImplementation] = useState(""),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  useEffect(() => {
    setKinds([]);
    setParent("");
  }, [application]);
  async function run(action: () => Promise<any>) {
    setBusy(true);
    setError("");
    try {
      await action();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  function skeleton() {
    setImplementation("");
    setDeclaration(
      kind === "ACTION"
        ? ""
        : kind === "GVL"
          ? "VAR_GLOBAL\n    xReady : BOOL;\nEND_VAR"
          : kind === "DUT"
            ? `TYPE ${name} :\nSTRUCT\n    xReady : BOOL;\nEND_STRUCT\nEND_TYPE`
            : `${kind} ${name}\nVAR\nEND_VAR`,
    );
  }
  return (
    <details className="card">
      <summary>{t("新建 ST 对象草稿", "New ST object draft")}</summary>
      <p className="muted">
        {t(
          "先读取当前适配器能力；新建对象也需要独立批次审批。方法和动作须选择正确的父 POU。",
          "Read adapter capabilities first. Creation requires batch approval; methods and actions require a suitable parent POU.",
        )}
      </p>
      <button
        disabled={busy || !application}
        onClick={() =>
          run(async () => {
            const c = await getCapabilities();
            const values = (c.verifiedCreateKinds ?? []).filter((k: string) =>
              [
                "PROGRAM",
                "FUNCTION_BLOCK",
                "GVL",
                "DUT",
                "METHOD",
                "ACTION",
              ].includes(k),
            );
            setKinds(values);
            if (!values.includes(kind) && values.length) setKind(values[0]);
          })
        }
      >
        {t("读取创建能力", "Read creation capabilities")}
      </button>
      <div className="form-grid">
        <label>
          {t("父对象", "Parent")}
          <select
            value={parent || application}
            onChange={(e) => setParent(e.target.value)}
          >
            <option value={application}>{application || "—"}</option>
            {tree
              .filter((o) => o.path.startsWith(application + "/"))
              .map((o) => (
                <option key={o.path} value={o.path}>
                  {o.path}
                </option>
              ))}
          </select>
        </label>
        <label>
          {t("对象类型", "Object kind")}
          <select value={kind} onChange={(e) => setKind(e.target.value)}>
            {kinds.map((k) => (
              <option key={k} value={k}>
                {k}
              </option>
            ))}
          </select>
        </label>
        <label>
          {t("对象名称", "Object name")}
          <input value={name} onChange={(e) => setName(e.target.value)} />
        </label>
      </div>
      <button disabled={!kinds.length} onClick={skeleton}>
        {t("生成声明骨架", "Generate declaration skeleton")}
      </button>
      <label>
        {t("新对象声明", "New declaration")}
        <textarea
          rows={7}
          value={declaration}
          onChange={(e) => setDeclaration(e.target.value)}
        />
      </label>
      <label>
        {t("新对象实现", "New implementation")}
        <textarea
          rows={7}
          value={implementation}
          onChange={(e) => setImplementation(e.target.value)}
        />
      </label>
      {error && <p className="error">{error}</p>}
      <button
        className="primary"
        disabled={busy || !kinds.includes(kind) || !name || !application}
        onClick={() =>
          run(() =>
            onPrepare({
              parentPath: parent || application,
              name,
              kind,
              declaration,
              implementation,
            }),
          )
        }
      >
        {t("生成新建批次", "Prepare creation batch")}
      </button>
    </details>
  );
}

export function ReconcileWrite({
  batchId,
  operation,
  t,
  read,
  reconcile,
}: {
  batchId: string;
  operation: any;
  t: Translate;
  read: (path: string) => Promise<any>;
  reconcile: (args: any) => Promise<any>;
}) {
  const [requestId, setRequestId] = useState(
    operation.result?.error?.details?.id ??
      operation.result?.error?.details?.requestId ??
      "",
  );
  const [observed, setObserved] = useState<any>(null),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  async function run(action: () => Promise<any>) {
    setBusy(true);
    setError("");
    try {
      await action();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <section>
      <p>
        {t(
          "待核实写入：读取当前内容并核对原始请求终态，不会重复写入。",
          "Unresolved write: compare current source and the original terminal response. This never repeats a write.",
        )}
      </p>
      <label>
        Request ID
        <input
          value={requestId}
          onChange={(e) => setRequestId(e.target.value)}
        />
      </label>
      <button
        disabled={busy}
        onClick={() => run(async () => setObserved(await read(operation.path)))}
      >
        {t("读取当前内容", "Read current content")}
      </button>
      {observed && (
        <pre>
          {observed.declaration +
            "\n" +
            observed.implementation +
            "\nSHA256: " +
            observed.sha256}
        </pre>
      )}
      <button
        disabled={busy || !requestId || !observed}
        onClick={() =>
          run(() =>
            reconcile({
              batchId,
              operationId: operation.id,
              requestId,
              observedSha256: observed.sha256,
            }),
          )
        }
      >
        {t("核对原始写入结果", "Reconcile original write")}
      </button>
      {error && <p className="error">{error}</p>}
    </section>
  );
}
