# PLC工匠 AI · PLC Artisan AI v0.2 使用说明

## 安装与启动

运行包需要外部 Node.js 22+，包含生产依赖与已构建网页。源码开发先运行 `npm ci`、`npm run build`、`npm run build:web`。Windows 默认浏览器即可使用，无需在浏览器安装扩展。

```powershell
.\scripts\Start-Workbench.ps1 -Node 'C:\Program Files\nodejs\node.exe'
```

也可以执行 `node dist/src/cli.js workbench`，打开输出的本机链接。链接片段中的 ticket 用于建立本机浏览器会话，登录后从地址栏移除；不要公开该链接或 `artifacts/workbench/service.json`。

启动独立 SP20 GUI 工程副本：

```powershell
.\scripts\Start-SP20Bridge.ps1 -Project 'D:\Tests\YourSavedTest.project'
.\scripts\Start-Workbench.ps1 -Config '.\artifacts\sp20-bridge\current-session.json'
```

脚本默认 EXE/Profile 与本机 SP20 Patch 6 对应，也可通过 `-Ide`、`-Profile` 显式指定。不会自动选择最新安装版本，不自动关闭已有受管测试 IDE。启动失败检查本次会话的日志；不要删除待核实写入或 IDE 锁来强行重试。

MCP 配置使用 `config/mcp.example.json`，把 Node、工具目录与配置路径改为本机绝对路径。MCP 启动共享本机服务；如果服务已绑定另一会话，需要在网页显式重新连接，不能静默切换。

## 分析、生成与编辑

1. 在工程页连接桥接配置，核对工程、会话和未保存状态；选择实时树中的 Application。
2. 采集源码。保留完整声明、实现、对象 GUID、读取缺口与前后复核结果。接口不支持的内容不会算作已完整读取。
3. 使用逻辑诊断、搜索、变量交叉引用和任务/I/O/库读取。检查结果是静态线索，不是运行时结论。
4. 在源码编辑器修改草稿，或在 AI 页选择对象和行范围，预览后确认本轮发送。不同供应商和新增范围必须重新确认。
5. 生成批次，在审批页核对工程、完整差异和哈希；勾选已审阅后批准。MCP/AI 不存在批准工具。
6. 逐项执行并独立回读，失败立即暂停。批次执行、IDE 编译、人工保存重开和行为测试分别记录。

批准有效期 30 分钟；实际参数、目标、工程或会话变化都会拒绝。旧版本只有证据记录的 approve 事件，不能充当新工具的编辑授权。旧桥接会话可以读取，但缺少 v0.2 签名能力时拒绝写入。

写入状态为 planned / executing / verified / failed / unknown。返回 verified 后的独立回读仍失败时停止并保留写入证据。未知结果必须检查请求 ID、终态响应和当前源码，使用 reconcile 工具核对；不能直接重复写入。若旧会话已消失且没有终态证据，保持待人工处理，不自动解除阻止。

扩展 FUNCTION、INTERFACE、PROPERTY 和其他 DUT 类型的适配代码保持能力门控。尚未实际通过创建、读取和编译的类型不会开放给用户；DUT 子类型不能被静默创建为结构体。

## 模型设置

支持 OpenAI Chat Completions、OpenAI Responses、Anthropic Messages、Gemini GenerateContent 四种接口配置。Base URL 是版本前缀，不包括具体动作后缀，例如 `https://api.openai.com/v1`；兼容供应商按实际接口文档配置。

API Key 在服务端使用当前 Windows 用户 DPAPI 加密，或引用环境变量。网页不会读取回显密钥。HTTPS 用于外部服务，HTTP 仅允许本机模型端点。不同供应商模型的真实可用性、费用、限流和工具能力需要使用用户自己的凭据验证，测试数据不代替真实调用。

不支持原生工具调用的模型可分析与生成草稿，不会把自由文本解析成工程操作。工具调用轮数最多 12，单轮超时 120 秒，取消后不再调度后续工具；已经交给 IDE 的写入仍须核对实际结果。

## Modbus TCP 与 OPC UA

运行 `node dist/src/mock-protocols.js` 或 `scripts/Start-ProtocolMocks.ps1` 启动本机只读测试服务：Modbus TCP 127.0.0.1:1502（Unit ID 1），OPC UA 端点 `opc.tcp://127.0.0.1:4841/donlinxg-mock`，变量 `ns=1;s=Counter`、`ns=1;s=Ready`。

通信页点表是 JSON，可明确导入/编辑功能码 01/02/03/04、地址基准、类型、字节和字序。`addressBase=zero` 使用协议零基地址；`reference` 使用 00001/10001/30001/40001 风格编号。默认 500 ms，最小 100 ms。

OPC UA 配置示例：

```json
{"id":"local-ua","protocol":"opcua","endpoint":"opc.tcp://127.0.0.1:4841/donlinxg-mock","securityMode":"None","securityPolicy":"None","intervalMs":500,"points":[{"id":"counter","nodeId":"ns=1;s=Counter","dataType":"UDINT"}]}
```

生产连接应选实际安全模式和证书。未知证书不自动信任；先发现端点，核对 SHA256 指纹，再显式信任匹配证书。用户名密码通过环境变量引用，并要求加密通道。服务端实际修订采样周期、质量、接收/源时间和陈旧状态分别显示。趋势不跨越坏质量数据补线。

本工具没有 Modbus 写功能码、OPC UA Write/Call、PLC 登录、下载、启动或强制功能。首次实机连接必须明确主机、点表、NodeId、证书及允许读取的范围；默认不扫描网络。

## 回归、文档与 Git

离线模型覆盖气缸、初始化与轴命令握手。先选择对象，准备场景，核对模型前提后运行。源码哈希改变会使模型过期；匹配哈希仅证明版本绑定，不证明模型等价执行了 ST。

IDE 模板和步骤需要人工接线及操作仿真。人工证据需填写工程、IDE、周期、逐扫描观察和附件哈希；报告注明人工提供，不声称工具独立执行。编译、离线模型、IDE 仿真和真实设备行为不能混用。

资料检索只访问网页明确授权的目录，支持 MD/TXT/ST/XML 文本，XML 搜索不等于 IEC 61131-10 无损工程解析。文件数、大小和结果数均有限制，符号链接不跟随。

Git 检查点只提交明确选中的源码文件，拒绝项目副本、会话与凭据，不自动推送。网页显示完整差异，用户主动触发提交。

## 开发、测试和发布

```powershell
npm ci
node scripts/dev.mjs test
python tests/sp20-bridge-contract.py
npm run build:web
npm run test:web
npm run package:release
```

如果系统 Node 受保护，使用可工作的 Node 22+ 完整路径，不更改系统保护。发布脚本需要 PowerShell、Python 3、开发依赖和可用的 Edge 用于无头浏览器测试；可用 `MCP_TEST_PYTHON` 指定 Python。

发布输出在 `artifacts/release/<timestamp>`：源码目录、运行目录、两个 ZIP、逐文件清单、下载校验和及本轮验证记录。不包含用户工程、业务源码、原始会话证据、IPC 或模型凭据。依赖中的 `.txt` 许可声明原文汇总到 `THIRD-PARTY-NOTICES.md`，配套 JSON 记录原路径、字节数和哈希；其他许可证随依赖保留。打包和校验使用 Python 同一读取方式，并验证 ZIP 内全部文件。当前版本状态详见 acceptance.md，不能根据历史成功推断当前 IDE 会话在线。


## 原生验收准备

仅准备批次，不自动批准或执行：

```powershell
.\scripts\Start-SP20Bridge.ps1 -Project 'D:\Test\blank.project' -SessionName sp20-v02-smoke
node scripts/prepare-native-smoke.mjs --config artifacts/sp20-v02-smoke/current-session.json --data artifacts/workbench-v02-smoke
```

`SessionName` 为不同测试副本提供独立会话目录，不会自动替换其他测试 IDE。一次服务只绑定一个显式选择的会话。打开该服务工作台，审阅 review 下完整差异、工程身份和计划哈希，再批准并逐项执行。可用 `--replace-path` 为已存在的完整 ST 对象准备仅添加验收注释的替换操作；仍需同批明确审批。

AI 页可以选择 2013 或 2025 语言目标；2025 选择仅改变生成规范上下文，未经 SP20 编译器验证的新特性仍被拒绝，不会因选择新版而自行启用。对应 MCP 工具 `codesys_generation_rules`、`codesys_check_st` 支持可选 `languageEdition`。

采集过程中显示的连接状态来自最近一次实时检查并标注 `liveCheck=false`，进度读取不再排队重复访问 IDE。完整源码对象单个声明/实现采集上限为32 MiB，超过时显式失败，不截断后宣称完整。
