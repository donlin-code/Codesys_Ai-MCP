# PLC Artisan AI v0.3 development build

Version `0.3.0-dev.1`. This is a lightweight engineering toolkit and official MCP discovery foundation, **not an accepted SP22 engineering adapter**. Existing SP20 remains the backend. Original projects stay untouched.

## Changes

MCP initialization and discovery no longer wait for the IDE/service. Core startup avoids telemetry, model, regression and document/Git modules. Search reuses indexed lines; references bypass full diagnostics. Per-object analysis is cached by content, identity, path and rule profile; global writer checks are recomputed. Analysis runs in a worker thread.

`codesys_refresh` rereads 1–25 captured objects twice. Unselected objects retain earlier observations. Identity/content conflicts invalidate the capture. The workbench can poll a selected object one second after each completed refresh, pausing while a draft is modified. This is not a native edit event or a 100 ms synchronization guarantee.

Human-confirmed AI requests wait 750 ms before sending. New requests supersede old runs; changed captures cancel analysis and invalidate old output. Existing provider/source-range consent remains mandatory; typing does not automatically send source to a cloud model.

## Commands

Requires Node.js 22+. Runtime ZIPs include production dependencies. Source builds require `npm ci` and `npm run build`.

```powershell
node .\dist\src\cli.js tools list
node .\dist\src\cli.js tools list --profile full
node .\dist\src\cli.js tools call codesys_status --data .\artifacts\workbench
node .\dist\src\cli.js tools call codesys_search --args-json '{"query":"Axis7"}' --data .\artifacts\workbench
node .\dist\src\cli.js workbench --config .\artifacts\sp20-bridge\current-session.json
```

The MCP command is your Node executable; arguments are the absolute `dist/src/mcp-server.js` path, `--profile core`, `--data` and the shared local service directory, optionally `--config` and a fresh test-session configuration. `full` exposes legacy aliases and telemetry. There is no AI/MCP/CLI approval endpoint. All clients share the same guarded service; unknown outcomes are never automatically retried. Exit code 0 is success, 1 is an input/connection/tool failure; legacy evidence/doctor commands also use 2 for incomplete readiness.

## Official SP22 status

On 2026-10-25 the official package passed its hash check and administrator installation was attempted. `PackageManagerCLI.exe` crashed in `cpsrt.dll` with exception `0xc0000409`; Installer returned -1. No Bridge was installed. The SP22 GUI starts but exposes no MCP commands. PDE entitlement remains unverified. System protection and licensing components were not modified.

After repairing the official installation, verifying PDE, enabling MCP in a test IDE and copying its actual Bridge path:

```powershell
node .\dist\src\cli.js official probe --ide-root '<SP22 installation>' --bridge '<actual CodesysMCPBridge.exe>' --out .\artifacts\official-probe
node .\dist\src\cli.js official read --ide-root '<SP22 installation>' --bridge '<actual CodesysMCPBridge.exe>' --tool get_active_app_as_path --args-json '{}' --out .\artifacts\official-read
```

Discovery preserves initialization metadata, paginated tool schemas, a schema hash, raw read results and timings. Use parameters from actual discovery. A fixed read-only allowlist rejects writes, compilation, deletion and library/task modifications regardless of tool annotations.

An `sp22-official` service configuration currently exposes capability discovery only. It reports `contract-unverified`, with engineering operations disabled. Source/GUID response mapping, reliable project lifecycle binding, approved native edits, readback, full compilation and three-route performance comparisons remain blocked until the official installation works. No default backend switch occurred.

## Distribution and acceptance

Source, core and full-runtime ZIPs are separate. Core includes the MCP dependency closure, service, approval UI and analysis. Modbus/OPC UA require the full runtime. No official proprietary binaries, native projects or credentials are included. ZIPs are generated and inspected in memory without extraction. Public dependency TXT notices are preserved in consolidated Markdown with original path/hash records.

`scripts/benchmark-v03.mjs` measures 149 generated objects, 200 short requests and five cold discoveries. MCP timings include SDK/stdio/loopback serialization, but exclude IDE synchronization and AI inference. See `performance-v03.json`; these are fixture results, not native SP22 evidence. WorkBuddy, TRAE and OEM environments remain unverified. See the acceptance matrix for remaining live work.
