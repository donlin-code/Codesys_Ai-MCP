# PLC工匠 AI v0.3 开发版

英文名 PLC Artisan AI，副标题 CODESYS AI-MCP。版本 `0.3.0-dev.1`。

这是轻量化与官方接入准备版，不是 SP22 已验收版。SP20 仍为现有工程后端；不自动改动原工程或切换后端。

## 本次功能

- MCP 初始化/工具枚举不等待工作台或 IDE；第一次实际调用才连接服务。
- 默认 core 工具集；`--profile full`保留重复创建/替换和遥测工具。批准接口始终只在人工网页中。
- 搜索复用源码行表；引用查询使用独立索引，不再触发完整逻辑诊断。
- 对象局部诊断按源码、路径、身份和规则配置缓存；全局多写入规则仍重新核对。诊断在工作线程执行。
- `codesys_refresh`对1–25个已采集对象重新读取两次；工程其余内容保持原观察时间。对象身份变化/读取不完整时使快照失效。
- 网页可勾选“跟随当前对象”：一次轮询完成后等待1秒再读，草稿有改动时暂停。不是逐键事件同步，不承诺100 ms。
- AI发送前仍需明确确认供应商和源码范围；确认后延迟750 ms执行，同服务新请求取消旧请求，快照变化时取消旧分析并标记结果过期。不会在每次键入后自动发送源码。
- 遥测、模型、回归、Git及文档实现按需加载；模块解析测试证明核心启动没有加载这些可选模块。

## 命令行与通用 MCP

Node.js 22+。运行包已包含对应生产依赖；源码需先`npm ci`再`npm run build`。

```powershell
node .\dist\src\cli.js tools list
node .\dist\src\cli.js tools list --profile full
node .\dist\src\cli.js tools call codesys_status --data .\artifacts\workbench
node .\dist\src\cli.js tools call codesys_search --args-json '{"query":"Axis7"}' --data .\artifacts\workbench
node .\dist\src\cli.js tools call codesys_references --args-file request.json --data .\artifacts\workbench
node .\dist\src\cli.js workbench --data .\artifacts\workbench --config .\artifacts\sp20-bridge\current-session.json
```

`request.json`内容例如`{"query":"Axis7"}`。搜索和引用要求已采集当前测试会话。进程退出码0为成功，1为输入/连接/工具错误，2保留给历史doctor/证据CLI的不完整状态。工具失败不会自动重复写入。CLI没有批准命令；历史batch record只是证据记录。

支持stdio的客户端可使用以下通用配置；按客户端格式粘贴字段，不假定特定产品配置路径：

```json
{
  "mcpServers": {
    "plc-artisan": {
      "command": "C:\\path\\to\\node.exe",
      "args": ["C:\\path\\to\\toolkit\\dist\\src\\mcp-server.js", "--profile", "core", "--data", "C:\\path\\to\\service-data", "--config", "C:\\path\\to\\current-session.json"]
    }
  }
}
```

多个本机客户端使用相同`--data`共享工程服务。配置与活动会话不一致时停止，需人工在工作台明确连接新会话。不要把bootstrap、service.json、凭据或原始工程证据上传到Git。只支持本机；WorkBuddy/TRAE等客户端尚未实测，不能据通用协议宣称已验收。

## SP22 官方验证入口

2026-10-25：官方1.1.0.0包哈希通过，管理员安装已执行；`PackageManagerCLI.exe`在`cpsrt.dll`中以`0xc0000409`崩溃，Installer退出码-1，Bridge未生成。SP22 GUI可启动，但无MCP入口。PDE仍未验证。安装崩溃与许可问题分别记录，不修改CodeMeter或系统保护设置。

先通过官方支持修复安装，核实PDE，在一个SP22测试实例启用MCP，从`Tools → Configure MCP Client`取得真实Bridge路径，然后：

```powershell
node .\dist\src\cli.js official probe --ide-root 'D:\Program Files\CODESYS 3.5.22.30' --bridge '<IDE显示的CodesysMCPBridge.exe绝对路径>' --out .\artifacts\official-probe
node .\dist\src\cli.js official read --ide-root 'D:\Program Files\CODESYS 3.5.22.30' --bridge '<同一路径>' --tool get_active_app_as_path --args-json '{}' --out .\artifacts\official-read
```

探测记录initialize、完整分页tools/list、实际schema哈希、原始只读结果和耗时。只读命令采用明确允许清单，不因服务端标记readOnly就允许编译、删除、改库或写代码；不假设工具名称意味着参数格式，参数以实际tools/list为准。

工作台也能选择`{"backend":"sp22-official","ideRoot":"...","bridge":"..."}`配置，但当前只用于发现能力，显示`contract-unverified`。未实现未经验证的源码/GUID拆分映射，所有工程操作保持拒绝。它不是已经完成的SP22读写适配器。

要解锁官方工程后端，还需取得真实schema及源码证据，完成映射、身份生命周期、审批写入、回读和完整编译验收，再完成同范围三路线对比。不得改一个配置开关就标成通过。

## 性能与分发

`node scripts/benchmark-v03.mjs`生成可复现的149对象模拟测试，短请求200次，冷启动5次；详情见`performance-v03.json`。MCP往返包含SDK、stdio、服务HTTP和序列化，不包含IDE同步和AI推理。现有SP20业务工程历史数据仍单独保留；本次没有新的原生性能对比。

- `*-source.zip`：源码和测试。
- `*-core.zip`：核心依赖、工程服务、审批网页、本地诊断；不含Modbus/OPC UA依赖。
- `*-runtime.zip`：完整生产依赖，通信功能使用此包。

核心包的通信页面会提示使用完整运行包，不自动联网补装依赖。官方Bridge始终单独安装，不随包分发。发布过程直接生成和内存校验ZIP，不解压；第三方TXT许可合并到Markdown并保留路径/哈希，适应本机透明加密环境。

尚未完成：官方SP22真实读写/性能、原生编辑事件、目标设备兼容性、保存重开、实时行为以及客户端逐项兼容验收。源码写入、编译、保存和行为始终分别报告。
