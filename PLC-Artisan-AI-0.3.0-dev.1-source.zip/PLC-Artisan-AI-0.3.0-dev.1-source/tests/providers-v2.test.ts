import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { randomUUID } from "node:crypto";
import {
  complete,
  initialMessages,
  appendToolResults,
  providerRequest,
  sseEvents,
  type ProviderConfig,
  ProviderStore,
} from "../src/providers.js";

test(
  "Windows DPAPI protects credentials at rest and public settings never return the key",
  { skip: process.platform !== "win32" },
  async (t) => {
    const directory = await mkdtemp(join(tmpdir(), "mcp-credentials-"));
    t.after(() => rm(directory, { recursive: true, force: true }));
    const store = new ProviderStore(directory),
      key = randomUUID() + "-test-only";
    const profile = await store.save({ ...cfg("openai-chat"), apiKey: key });
    const saved = await readFile(
      join(directory, "private-providers.json"),
      "utf8",
    );
    assert.ok(!saved.includes(key));
    assert.ok(!JSON.stringify(await store.list()).includes(key));
    assert.equal((await store.get(profile!.id)).key, key);
  },
);
const cfg = (kind: ProviderConfig["kind"]): ProviderConfig => ({
  id: "p",
  name: "test",
  kind,
  baseUrl: "https://example.invalid/v1",
  model: "model",
  supportsTools: true,
});
const stream = (events: any[]) =>
  new Response(
    events.map((e) => "data: " + JSON.stringify(e) + "\n\n").join(""),
    { headers: { "Content-Type": "text/event-stream" } },
  );
test("all native provider interfaces reconstruct streaming tools and usage without parsing prose", async () => {
  const events: Record<string, any[]> = {
    "openai-chat": [
      {
        choices: [
          {
            delta: {
              content: "hello",
              tool_calls: [
                {
                  index: 0,
                  id: "c",
                  function: { name: "codesys_status", arguments: "{" },
                },
              ],
            },
          },
        ],
      },
      {
        choices: [
          {
            delta: { tool_calls: [{ index: 0, function: { arguments: "}" } }] },
          },
        ],
        usage: { total_tokens: 10 },
      },
    ],
    "openai-responses": [
      { type: "response.output_text.delta", delta: "hello" },
      {
        type: "response.output_item.added",
        output_index: 0,
        item: { type: "function_call", call_id: "c", name: "codesys_status" },
      },
      {
        type: "response.function_call_arguments.delta",
        output_index: 0,
        delta: "{}",
      },
      {
        type: "response.completed",
        response: {
          usage: { total_tokens: 10 },
          output: [
            {
              type: "function_call",
              call_id: "c",
              name: "codesys_status",
              arguments: "{}",
            },
          ],
        },
      },
    ],
    anthropic: [
      {
        type: "content_block_delta",
        delta: { type: "text_delta", text: "hello" },
      },
      {
        type: "content_block_start",
        index: 0,
        content_block: { type: "tool_use", id: "c", name: "codesys_status" },
      },
      {
        type: "content_block_delta",
        index: 0,
        delta: { type: "input_json_delta", partial_json: "{}" },
      },
      { type: "message_delta", usage: { output_tokens: 10 } },
    ],
    gemini: [
      {
        candidates: [
          {
            content: {
              parts: [
                { text: "hello" },
                { functionCall: { name: "codesys_status", args: {} } },
              ],
            },
          },
        ],
        usageMetadata: { totalTokenCount: 10 },
      },
    ],
  };
  for (const kind of Object.keys(events) as ProviderConfig["kind"][]) {
    const messages = initialMessages(kind, "test", "source"),
      seen: any[] = [];
    const result = await complete(
      cfg(kind),
      "secret",
      messages,
      [],
      (e) => seen.push(e),
      undefined,
      (async () => stream(events[kind])) as typeof fetch,
    );
    assert.equal(result.text, "hello");
    assert.equal(result.calls[0].name, "codesys_status");
    assert.deepEqual(result.calls[0].arguments, {});
    assert.ok(result.usage);
    appendToolResults(kind, messages, result, [{ ok: true }]);
    assert.ok(messages.length >= 4);
  }
});
test("provider errors, invalid argument JSON and cancellation fail without automatic retries", async () => {
  let calls = 0;
  await assert.rejects(
    complete(
      cfg("openai-chat"),
      "k",
      [],
      [],
      () => {},
      undefined,
      (async () => {
        calls++;
        return new Response("", { status: 429 });
      }) as typeof fetch,
    ),
    { code: "PROVIDER_RATE_LIMIT" },
  );
  assert.equal(calls, 1);
  await assert.rejects(
    complete(cfg("openai-chat"), "k", [], [], () => {}, undefined, (async () =>
      stream([
        {
          choices: [
            {
              delta: {
                tool_calls: [
                  { index: 0, function: { name: "x", arguments: "not-json" } },
                ],
              },
            },
          ],
        },
      ])) as typeof fetch),
    { code: "INVALID_TOOL_ARGUMENTS" },
  );
  const controller = new AbortController();
  controller.abort();
  await assert.rejects(
    complete(cfg("openai-chat"), "k", [], [], () => {}, controller.signal),
  );
});
test("SSE chunk boundaries preserve CRLF and UTF-8; API key is a header, not URL", async () => {
  const encoder = new TextEncoder(),
    bytes = encoder.encode('data: {"text":"中文"}\r\n\r\n');
  const response = new Response(
    new ReadableStream({
      start(c) {
        for (const byte of bytes) c.enqueue(Uint8Array.of(byte));
        c.close();
      },
    }),
  );
  const events = [];
  for await (const e of sseEvents(response)) events.push(e);
  assert.equal(events.length, 1);
  assert.equal(JSON.parse(events[0].data).text, "中文");
  for (const kind of [
    "openai-chat",
    "openai-responses",
    "anthropic",
    "gemini",
  ] as const) {
    const r = providerRequest(
      cfg(kind),
      "SECRET",
      initialMessages(kind, "p", "s"),
      [],
    );
    assert.ok(!r.url.includes("SECRET"));
    assert.ok(!JSON.stringify(r.body).includes("SECRET"));
  }
});
