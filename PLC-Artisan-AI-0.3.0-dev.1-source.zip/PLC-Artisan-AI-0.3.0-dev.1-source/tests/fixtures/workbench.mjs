import { mkdtemp } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createHash, randomUUID } from "node:crypto";
import { EngineeringService } from "../../dist/src/engineering.js";
import { startWorkbench } from "../../dist/src/workbench-server.js";
const app = "/Fixture/Application",
  path = app + "/PRG_Test";
const hash = (d, i) =>
  createHash("sha256")
    .update(d + "\0" + i)
    .digest("hex");
const adapter = {
  session: {
    sessionId: randomUUID(),
    projectIdentity: {
      path: "C:\\fixture\\test-only.project",
      handle: 1,
      instanceId: randomUUID(),
    },
  },
  actions: ["ping", "project_info", "list", "read", "read_many", "compile"],
  guardedWrites: true,
  verifiedCreateKinds: ["PROGRAM"],
  source: {
    path,
    id: "fixture-guid",
    declaration: "PROGRAM PRG_Test\nVAR\n    x : BOOL;\nEND_VAR",
    implementation: "GVL_IO.abDO[11] := FALSE;",
    sourceComplete: true,
    language: "ST",
    sourceKind: "POU",
  },
  async invoke(action, args = {}) {
    this.source.sha256 = hash(
      this.source.declaration,
      this.source.implementation,
    );
    this.source.complete = true;
    if (action === "project_info")
      return {
        ok: true,
        result: {
          projectPath: this.session.projectIdentity.path,
          dirty: false,
        },
      };
    if (action === "ping") return { ok: true, result: { pong: true } };
    if (action === "capabilities")
      return {
        ok: true,
        result: {
          verifiedCreateKinds: ["PROGRAM"],
          implementedUnverifiedKinds: ["FUNCTION", "PROPERTY"],
        },
      };
    if (action === "list")
      return {
        ok: true,
        result: {
          treeComplete: true,
          inventorySha256: "fixture-tree",
          objects: [
            {
              path: app,
              id: "fixture-app",
              isApplication: true,
              childrenSha256: "0".repeat(64),
            },
            {
              path,
              id: this.source.id,
              parentPath: app,
              hasDeclaration: true,
              hasImplementation: true,
              childrenSha256: "0".repeat(64),
            },
          ],
        },
      };
    if (action === "read") return { ok: true, result: { ...this.source } };
    if (action === "read_many")
      return {
        ok: true,
        result: {
          objects: args.paths.map(() => ({
            ok: true,
            source: { ...this.source },
          })),
        },
      };
    if (action === "replace_st") {
      this.source = {
        ...this.source,
        declaration: args.declaration,
        implementation: args.implementation,
      };
      return { ok: true, result: { verified: true, saved: false } };
    }
    if (action === "compile")
      return {
        ok: true,
        result: { success: true, errorCount: 0, warningCount: 0, saved: false },
      };
    throw new Error("Fixture-only unsupported action");
  },
};
const directory = await mkdtemp(join(tmpdir(), "donlinxg-web-e2e-")),
  service = new EngineeringService(directory, adapter);
await service.capture(app);
const server = await startWorkbench({
  directory,
  root: process.cwd(),
  service,
  port: 18765,
});
// Only a test ticket is published here; never an IDE transport key.
process.stdout.write(
  "FIXTURE_WORKBENCH " +
    server.endpoint.url +
    "/#ticket=" +
    server.endpoint.browserTicket +
    "\n",
);
process.on("SIGTERM", () => server.close().then(() => process.exit(0)));
