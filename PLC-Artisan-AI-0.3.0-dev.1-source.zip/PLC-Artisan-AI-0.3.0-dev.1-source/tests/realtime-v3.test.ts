import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, rm, stat } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { pathToFileURL } from "node:url";
import { createServer } from "node:http";
import { ProviderStore } from "../src/providers.js";
import { AIAgent } from "../src/ai-agent.js";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StdioClientTransport } from "@modelcontextprotocol/sdk/client/stdio.js";
import { AnalysisIndex, referencesTo } from "../src/st-analysis.js";
import { AnalysisWorker } from "../src/analysis-worker.js";
import { SourceSearch } from "../src/source-search.js";
import { EngineeringService, type Adapter } from "../src/engineering.js";
import { sourceHash } from "../src/core.js";
import { toolsForProfile } from "../src/toolkit.js";
import {
  OfficialConnection,
  OfficialDiscoveryAdapter,
} from "../src/official-mcp.js";

function object(
  path = "/Application/P",
  implementation = "GVL.Output := TRUE;",
) {
  const declaration = "PROGRAM P\nVAR\n    name : STRING := '中文';\nEND_VAR";
  return {
    path,
    id: path,
    declaration,
    implementation,
    sha256: sourceHash(declaration, implementation),
    complete: true,
    sourceComplete: true,
  };
}
function snapshot(objects = [object()]) {
  return {
    schemaVersion: 2,
    origin: "fixture",
    session: {
      sessionId: "test",
      projectIdentity: { path: "fixture", handle: 1, instanceId: "fixture" },
    },
    objects,
    inventory: [],
    applicationPath: "/Application",
    capturedAt: "2026-01-01T00:00:00Z",
    freshness: "verified-across-passes",
    evidenceIds: [],
    issues: [],
  } as any;
}

test("offline MCP initialization and discovery never opens a service or IDE", async (t) => {
  const data = await mkdtemp(join(tmpdir(), "artisan-discovery-"));
  t.after(() => rm(data, { recursive: true, force: true }));
  const client = new Client({ name: "test", version: "1" });
  const transport = new StdioClientTransport({
    command: process.execPath,
    args: [
      resolve("dist/src/mcp-server.js"),
      "--config",
      join(data, "missing.json"),
      "--data",
      data,
    ],
    stderr: "pipe",
  });
  try {
    await client.connect(transport, { timeout: 10000 });
    const { tools } = await client.listTools();
    assert.ok(tools.some((t) => t.name === "codesys_refresh"));
    assert.ok(tools.some((t) => t.name === "codesys_reconcile_write"));
    assert.ok(!tools.some((t) => t.name === "codesys_replace_st"));
    const denied = await client.callTool({
      name: "codesys_replace_st",
      arguments: {},
    });
    assert.equal(denied.isError, true);
    await assert.rejects(stat(join(data, "service.json")), { code: "ENOENT" });
  } finally {
    await client.close();
  }
});

test("profiles retain compatibility without exposing approval", () => {
  assert.ok(
    toolsForProfile("full").some((t) => t.name === "codesys_replace_st"),
  );
  assert.ok(
    !toolsForProfile("core").some((t) => /telemetry|approve/.test(t.name)),
  );
  assert.throws(() => toolsForProfile("invalid"), { code: "INVALID_PROFILE" });
});

test("core service startup does not resolve optional telemetry, AI or asset modules", async () => {
  const script = `
    import {registerHooks} from 'node:module';
    import {mkdtemp, rm} from 'node:fs/promises';
    import {tmpdir} from 'node:os'; import {join} from 'node:path';
    const loaded=[];
    registerHooks({resolve(s,c,next){if(/node-opcua|modbus-serial|providers\\.js|ai-agent\\.js|regression\\.js|local-assets\\.js/.test(s))loaded.push(s);return next(s,c);}});
    const {startWorkbench}=await import(process.argv[1]);
    const directory=await mkdtemp(join(tmpdir(),'artisan-lazy-'));
    const app=await startWorkbench({directory,root:process.cwd()});
    await app.close();await rm(directory,{recursive:true,force:true});
    console.log(JSON.stringify(loaded));
  `;
  const result = await promisify(execFile)(
    process.execPath,
    [
      "--input-type=module",
      "-e",
      script,
      pathToFileURL(resolve("dist/src/workbench-server.js")).href,
    ],
    { windowsHide: true },
  );
  assert.deepEqual(JSON.parse(result.stdout), []);
});

test("source index handles removal, rename, Chinese literals and bounded hits", () => {
  const index = new SourceSearch();
  index.update([object()]);
  assert.equal(index.search("中文").length, 1);
  index.update([object("/Application/Q", "x := FALSE;\nx := TRUE;")]);
  assert.equal(index.search("GVL.Output").length, 0);
  assert.equal(index.search("x :=", 1).length, 1);
  assert.equal(index.search("x :=")[0].path, "/Application/Q");
  index.update([]);
  assert.deepEqual(index.search("x"), []);
});

test("analysis caches isolate identity, rules, content and mutable findings", () => {
  const index = new AnalysisIndex(),
    a = object(),
    b = object("/Application/Q");
  const first = index.analyze([a, b]);
  assert.ok(first.findings.some((f) => f.rule === "MULTIPLE_WRITERS"));
  first.findings.forEach((f) => (f.message = "corrupted by caller"));
  const second = index.analyze([a]);
  assert.ok(
    !second.findings.some(
      (f) => f.rule === "MULTIPLE_WRITERS" || f.message.includes("corrupted"),
    ),
  );
  // Incorrect caller hash must never produce a hit for previous text.
  a.implementation = "GVL.Other := TRUE;";
  assert.equal(referencesTo(index.referenceIndex([a]), "GVL.Output").length, 0);
});

test("worker analysis matches synchronous results and stays reusable", async (t) => {
  const worker = new AnalysisWorker();
  t.after(() => worker.close());
  const objects = [object(), object("/Application/Q")];
  assert.deepEqual(
    await worker.run(objects),
    new AnalysisIndex().analyze(objects),
  );
  assert.deepEqual(
    await worker.run([object()], "references"),
    new AnalysisIndex().referenceIndex([object()]),
  );
});

test("reference lookup does not run full diagnostic rules; stale worker results are rejected", async (t) => {
  const service = new EngineeringService("unused");
  t.after(() => service.close());
  service.snapshot = snapshot();
  const pending = service.analyze();
  service.snapshot = snapshot([object("/Application/New")]);
  await assert.rejects(pending, { code: "SOURCE_CHANGED" });
  service.analyze = async () => {
    throw new Error("must not run full diagnostics");
  };
  assert.equal(
    (await service.references("GVL.Output"))[0].path,
    "/Application/New",
  );
});

test("selected refresh updates versions only on changes; conflict invalidates captured source", async (t) => {
  const dir = await mkdtemp(join(tmpdir(), "artisan-refresh-"));
  let current = object();
  const initial = snapshot();
  const adapter: Adapter = {
    session: initial.session,
    actions: ["read"],
    guardedWrites: false,
    verifiedCreateKinds: [],
    invoke: async () => ({ ok: true, result: current }),
  };
  const service = new EngineeringService(dir, adapter);
  service.snapshot = initial;
  t.after(async () => {
    await service.close();
    await rm(dir, { recursive: true, force: true });
  });
  assert.equal(
    (await service.refreshSources([current.path])).changedPaths.length,
    0,
  );
  assert.equal(service.snapshot, initial);
  current = object(current.path, "GVL.Output := FALSE;");
  assert.equal(
    (await service.refreshSources([current.path])).changedPaths.length,
    1,
  );
  assert.equal(service.snapshot!.freshness, "changed");
  assert.equal(service.search("FALSE").length, 1);
  current = { ...current, id: "replaced-object" };
  await assert.rejects(service.refreshSources([current.path]), {
    code: "SOURCE_CHANGED",
  });
  assert.equal(service.snapshot, undefined);
});

test("official discovery denies writes and compilation regardless of tool annotations", async () => {
  const connection = new OfficialConnection("unused");
  for (const name of [
    "remove_object",
    "replace_text_in_structured_text",
    "check_for_errors",
    "add_or_remove_library",
    "unknown",
  ])
    await assert.rejects(connection.read(name), {
      code: "OFFICIAL_ACTION_DENIED",
    });
  connection.inventory = { schemaHash: "fixture-only" };
  const adapter = new OfficialDiscoveryAdapter(connection);
  assert.equal(adapter.guardedWrites, false);
  await assert.rejects(adapter.invoke("read"), {
    code: "OFFICIAL_CONTRACT_UNVERIFIED",
  });
  assert.equal(
    (await adapter.invoke("capabilities")).result.status,
    "contract-unverified",
  );
});

test("AI streaming detects changed capture and marks old output stale", async (t) => {
  const dir = await mkdtemp(join(tmpdir(), "artisan-ai-version-"));
  const service = new EngineeringService(dir);
  service.snapshot = snapshot();
  const server = createServer(async (req, res) => {
    for await (const _ of req) {
      /* consume request */
    }
    res.writeHead(200, { "Content-Type": "text/event-stream" });
    const frame = (text: string) =>
      "data: " +
      JSON.stringify({ choices: [{ delta: { content: text } }] }) +
      "\n\n";
    res.end(
      frame("old result") + frame("must be discarded") + "data: [DONE]\n\n",
    );
  });
  await new Promise<void>((r) => server.listen(0, "127.0.0.1", r));
  t.after(async () => {
    server.closeAllConnections();
    await new Promise<void>((r) => server.close(() => r()));
    await service.close();
    await rm(dir, { recursive: true, force: true });
  });
  const address = server.address() as { port: number };
  const providers = new ProviderStore(dir);
  const provider = await providers.save({
    name: "fixture",
    kind: "openai-chat",
    baseUrl: `http://127.0.0.1:${address.port}/v1`,
    model: "fixture",
    supportsTools: false,
  });
  const agent = new AIAgent(
    service,
    { state: () => [], history: () => [] },
    providers,
    dir,
  );
  const request = {
    providerId: provider!.id,
    prompt: "fixture analysis",
    selections: [
      {
        path: object().path,
        part: "implementation" as const,
        startLine: 1,
        endLine: 1,
        sha256: object().sha256,
      },
    ],
  };
  await agent.consent(request);
  const events: any[] = [];
  await assert.rejects(
    agent.run(request, (event) => {
      events.push(event);
      if (event.type === "text")
        service.snapshot = snapshot([object(undefined, "x := FALSE;")]);
    }),
    { code: "SOURCE_CHANGED" },
  );
  assert.ok(events.some((e) => e.type === "stale"));
  assert.ok(!events.some((e) => e.text === "must be discarded"));
});
