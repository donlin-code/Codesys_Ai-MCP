import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, writeFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { decodeLocalText } from "../src/core.js";
import { searchDocuments } from "../src/local-assets.js";

test("local text decoding rejects opaque and malformed content and supports BOM text", () => {
  assert.throws(() => decodeLocalText(Buffer.from("%TSD-Header-###%opaque")), {
    code: "OPAQUE_FILE",
  });
  assert.throws(() => decodeLocalText(Buffer.from([0xc3, 0x28])), {
    code: "TEXT_ENCODING_UNSUPPORTED",
  });
  assert.equal(decodeLocalText(Buffer.from("\ufeff轴回原", "utf8")), "轴回原");
  const le = Buffer.from("\ufeff轴回原", "utf16le");
  assert.equal(decodeLocalText(le), "轴回原");
  assert.equal(decodeLocalText(Buffer.from(le).swap16()), "轴回原");
});

test("document search reports unreadable sources instead of implying a complete negative result", async (t) => {
  const root = await mkdtemp(join(tmpdir(), "mcp-doc-scan-"));
  t.after(() => rm(root, { recursive: true, force: true }));
  await writeFile(
    join(root, "readable.md"),
    Buffer.from("\ufeff轴回原场景", "utf16le"),
  );
  await writeFile(
    join(root, "opaque.md"),
    Buffer.from("%TSD-Header-###%opaque"),
  );
  const report = await searchDocuments([root], "轴回原");
  assert.equal(report.scannedFiles, 2);
  assert.equal(report.results.length, 1);
  assert.equal(report.results[0].text, "轴回原场景");
  assert.equal(report.issues.length, 1);
  assert.match(report.issues[0].reason, /ciphertext/);
});
