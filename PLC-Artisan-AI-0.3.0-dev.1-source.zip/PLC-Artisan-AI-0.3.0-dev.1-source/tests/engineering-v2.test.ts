import test, { type TestContext } from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, rm, readFile, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { randomUUID } from "node:crypto";
import { createServer } from "node:http";
import {
  EngineeringService,
  ScriptAdapter,
  type Adapter,
} from "../src/engineering.js";
import { AppError, sourceHash, sha256, saveJson } from "../src/core.js";
import { startWorkbench } from "../src/workbench-server.js";
import { publicTools } from "../src/toolkit.js";
import {
  AnalysisIndex,
  formatST,
  parseST,
  referencesTo,
  tokenize,
  type SourceObject,
} from "../src/st-analysis.js";
import { standards } from "../src/standards.js";
import {
  defaultScenarios,
  runRegression,
  importManualEvidence,
  ideHarness,
} from "../src/regression.js";
import { AIAgent } from "../src/ai-agent.js";
import { ProviderStore } from "../src/providers.js";
import { TelemetryManager } from "../src/telemetry.js";

const app = "/Device/Application",
  path = app + "/PRG_Test";
export class FakeAdapter implements Adapter {
  session: Adapter["session"] = {
    sessionId: randomUUID(),
    projectIdentity: {
      path: "C:\\test\\isolated.project",
      handle: 7,
      instanceId: randomUUID(),
    },
  };
  actions = [
    "ping",
    "project_info",
    "list",
    "read",
    "read_many",
    "compile",
    "context",
    "capabilities",
  ];
  guardedWrites = true;
  verifiedCreateKinds = [
    "PROGRAM",
    "FUNCTION_BLOCK",
    "GVL",
    "DUT",
    "METHOD",
    "ACTION",
  ];
  sources = new Map<string, SourceObject>();
  writes = 0;
  reads = 0;
  changeOnSecondPass = false;
  fail: string | null = null;
  constructor(count = 1) {
    for (let i = 0; i < count; i++)
      this.sources.set(
        i ? path + i : path,
        this.source(i ? path + i : path, "GVL_IO.abDO[11] := FALSE;"),
      );
  }
  source(path: string, implementation: string): SourceObject {
    const declaration = "PROGRAM PRG_Test\nVAR\n    x : BOOL;\nEND_VAR";
    return {
      path,
      id: path,
      declaration,
      implementation,
      sha256: sourceHash(declaration, implementation),
      sourceComplete: true,
      language: "ST",
      sourceKind: "POU",
    };
  }
  async invoke(action: string, args: any = {}, permit?: any): Promise<any> {
    if (action === "ping") return { ok: true, result: { pong: true } };
    if (action === "project_info")
      return {
        ok: true,
        result: {
          projectPath: this.session.projectIdentity.path,
          dirty: this.writes > 0,
        },
      };
    if (action === "list")
      return {
        ok: true,
        result: {
          objects: [
            { path: app, isApplication: true },
            ...[...this.sources.values()].map((o) => ({
              path: o.path,
              id: o.id,
              parentPath: app,
              hasDeclaration: true,
              hasImplementation: true,
              childrenSha256: sha256("children"),
            })),
          ],
          treeComplete: true,
          inventorySha256: "tree",
        },
      };
    if (action === "read") {
      this.reads++;
      const s = this.sources.get(args.path);
      if (!s)
        return {
          ok: false,
          error: {
            code: "NOT_FOUND",
            message: "Object not found",
            partial: false,
          },
        };
      return { ok: true, result: { ...s, complete: true } };
    }
    if (action === "read_many") {
      if (this.changeOnSecondPass && this.reads >= this.sources.size) {
        const o = this.sources.get(path)!;
        this.sources.set(
          path,
          this.source(path, o.implementation + "\n(* changed *)"),
        );
        this.changeOnSecondPass = false;
      }
      const objects = [];
      for (const path of args.paths) {
        const r = await this.invoke("read", { path });
        objects.push({ ok: r.ok, source: r.result, path });
      }
      return { ok: true, result: { objects } };
    }
    if (action === "replace_st") {
      assert.ok(permit);
      if (this.fail)
        throw new AppError(this.fail, "Injected unknown write", {
          id: "request-unknown",
        });
      const before = this.sources.get(args.path)!;
      if (before.sha256 !== args.expectedSha256)
        return {
          ok: false,
          error: { code: "CONFLICT", message: "changed", partial: false },
        };
      this.writes++;
      this.sources.set(args.path, {
        ...before,
        declaration: args.declaration,
        implementation: args.implementation,
        sha256: sourceHash(args.declaration, args.implementation),
      });
      return {
        ok: true,
        result: {
          verified: true,
          saved: false,
          readback: this.sources.get(args.path),
        },
      };
    }
    if (action === "compile")
      return {
        ok: true,
        result: {
          applicationPath: app,
          success: true,
          errorCount: 0,
          warningCount: 0,
          saved: false,
        },
      };
    throw new Error("Unsupported fake action " + action);
  }
}
async function fixture(t: TestContext, count = 1) {
  const dir = await mkdtemp(join(tmpdir(), "codesys-v2-"));
  t.after(() => rm(dir, { recursive: true, force: true }));
  const adapter = new FakeAdapter(count);
  return { dir, adapter, service: new EngineeringService(dir, adapter) };
}
const changes = (implementation = "GVL_IO.abDO[11] := TRUE;") => [
  {
    action: "replace_st" as const,
    args: {
      path,
      declaration: "PROGRAM PRG_Test\nVAR\n    x : BOOL;\nEND_VAR",
      implementation,
    },
  },
];

test("older loaded bridge code stays read-only until a fresh matching worker is started", async () => {
  const adapter = new FakeAdapter();
  const client = {
    ready: {
      ...adapter.session,
      actions: adapter.actions,
      writeAuthorization: "hmac-sha256-v1",
      bridgeSourceSha256: sha256(
        await readFile("scripts/sp20_bridge.py", "utf8"),
      ),
    },
    config: { authorizationKey: "a".repeat(64) },
  };
  assert.equal(new ScriptAdapter(client as any).guardedWrites, true);
  client.ready.bridgeSourceSha256 = "0".repeat(64);
  assert.equal(new ScriptAdapter(client as any).guardedWrites, false);
});

test("ordered creations derive parent baselines only from validated siblings and bridge rejects late tree changes", async (t) => {
  const { dir, adapter, service } = await fixture(t);
  const original = adapter.invoke.bind(adapter);
  let listCalls = 0,
    inject = false;
  const childHash = () =>
    sha256(
      JSON.stringify(
        [...adapter.sources.values()].map((o) => [o.path, o.id]).sort(),
      ),
    );
  adapter.invoke = async (action, args = {}, permit) => {
    if (action === "list") {
      listCalls++;
      const result = await original(action, args, permit);
      Object.assign(result.result.objects[0], {
        id: "parent-guid",
        childrenSha256: childHash(),
      });
      return result;
    }
    if (action === "create_st") {
      assert.ok(permit);
      if (inject)
        adapter.sources.set(
          app + "/Manual",
          adapter.source(app + "/Manual", ""),
        );
      if (args.expectedChildrenSha256 !== childHash())
        return {
          ok: false,
          error: {
            code: "CONFLICT",
            message: "Native parent changed",
            partial: false,
          },
        };
      const created = {
        ...adapter.source(app + "/" + args.name, args.implementation),
        declaration: args.declaration,
        sha256: sourceHash(args.declaration, args.implementation),
      };
      adapter.sources.set(created.path, created);
      adapter.writes++;
      return { ok: true, result: { verified: true, readback: created } };
    }
    return original(action, args, permit);
  };
  const create = (name: string) => ({
    action: "create_st" as const,
    args: {
      parentPath: app,
      name,
      kind: "GVL",
      declaration: "VAR_GLOBAL\n    x : BOOL;\nEND_VAR",
      implementation: "",
    },
  });
  const batch = await service.prepare(app, [
    create("GVL_One"),
    create("GVL_Two"),
  ]);
  await service.approve(batch.id, batch.planHash);
  listCalls = 0;
  await service.execute(batch.id, batch.operations[0].id);
  assert.equal(listCalls, 1);
  listCalls = 0;
  await service.execute(batch.id, batch.operations[1].id);
  assert.equal(listCalls, 1);
  assert.equal(adapter.writes, 2);
  const next = await service.prepare(app, [create("GVL_Three")]);
  await service.approve(next.id, next.planHash);
  inject = true;
  await assert.rejects(service.execute(next.id, next.operations[0].id), {
    code: "CONFLICT",
  });
  assert.equal(adapter.writes, 2);
  assert.ok(!adapter.sources.has(app + "/GVL_Three"));
});
test("live writes require human approval, exact plan and fresh baseline; no tool approves", async (t) => {
  const { service, adapter } = await fixture(t);
  const b = await service.prepare(app, changes());
  assert.ok(!publicTools.some((t) => /approv/i.test(t.name)));
  await assert.rejects(service.execute(b.id, b.operations[0].id), {
    code: "APPROVAL_REQUIRED",
  });
  await service.approve(b.id, b.planHash);
  await assert.rejects(
    service.execute(b.id, b.operations[0].id, {
      action: "replace_st",
      args: { ...b.operations[0].args, implementation: "x:=9;" },
    }),
    { code: "PLAN_CHANGED" },
  );
  adapter.sources.set(path, adapter.source(path, "(* manual edit *)"));
  await assert.rejects(service.execute(b.id, b.operations[0].id), {
    code: "CONFLICT",
  });
  assert.equal(adapter.writes, 0);
  assert.ok((await service.getBatch(b.id)).halted);
});
test("approved unchanged batch writes once with independent readback and separate build", async (t) => {
  const { service, adapter } = await fixture(t);
  const b = await service.prepare(app, changes());
  await service.approve(b.id, b.planHash);
  const done = await service.execute(b.id, b.operations[0].id);
  assert.equal(done.operations[0].state, "verified");
  assert.equal(adapter.writes, 1);
  assert.equal(done.persistence, "not-verified");
  assert.equal(done.compile, undefined);
  await assert.rejects(service.execute(b.id, b.operations[0].id));
  const compiled = await service.compile(app, b.id);
  assert.equal(compiled.success, true);
});
test("expiry, altered plans and new sessions reject before writes", async (t) => {
  const { service, adapter, dir } = await fixture(t);
  let b = await service.prepare(app, changes());
  await service.approve(b.id, b.planHash);
  b = await service.getBatch(b.id);
  b.approval!.expiresAt = "2000-01-01T00:00:00Z";
  await saveJson(join(dir, "batches", b.id + ".json"), b);
  await assert.rejects(service.execute(b.id, b.operations[0].id), {
    code: "APPROVAL_REQUIRED",
  });
  b = await service.prepare(app, changes());
  await service.approve(b.id, b.planHash);
  adapter.session = { ...adapter.session, sessionId: randomUUID() };
  await assert.rejects(service.execute(b.id, b.operations[0].id), {
    code: "SESSION_CHANGED",
  });
  adapter.session = b.session;
  b.operations[0].args.implementation = "tampered";
  await saveJson(join(dir, "batches", b.id + ".json"), b);
  await assert.rejects(service.execute(b.id, b.operations[0].id), {
    code: "PLAN_CHANGED",
  });
  assert.equal(adapter.writes, 0);
});
test("same-path same-text replacement of an object GUID invalidates approval", async (t) => {
  const { service, adapter } = await fixture(t);
  const b = await service.prepare(app, changes());
  await service.approve(b.id, b.planHash);
  adapter.sources.get(path)!.id = randomUUID();
  await assert.rejects(service.execute(b.id, b.operations[0].id), {
    code: "CONFLICT",
  });
  assert.equal(adapter.writes, 0);
});
test("last-moment manual edit is caught by the immediate target reread", async (t) => {
  const { service, adapter } = await fixture(t);
  const b = await service.prepare(app, changes());
  await service.approve(b.id, b.planHash);
  const original = adapter.invoke.bind(adapter);
  let reads = 0;
  adapter.invoke = async (action, args, permit) => {
    if (action === "read" && ++reads === 2)
      adapter.sources.set(
        path,
        adapter.source(path, "x := FALSE; (* operator *)"),
      );
    return original(action, args, permit);
  };
  await assert.rejects(service.execute(b.id, b.operations[0].id), {
    code: "CONFLICT",
  });
  assert.equal(adapter.writes, 0);
  assert.equal((await service.getBatch(b.id)).operations[0].state, "failed");
});
test("unknown outcome survives restart and blocks other batches", async (t) => {
  const { service, adapter, dir } = await fixture(t);
  const b = await service.prepare(app, changes());
  await service.approve(b.id, b.planHash);
  adapter.fail = "WRITE_OUTCOME_UNKNOWN";
  await assert.rejects(service.execute(b.id, b.operations[0].id));
  assert.equal((await service.getBatch(b.id)).operations[0].state, "unknown");
  const restarted = new EngineeringService(dir, adapter);
  const b2 = await restarted.prepare(app, changes());
  await restarted.approve(b2.id, b2.planHash);
  await assert.rejects(restarted.execute(b2.id, b2.operations[0].id), {
    code: "UNRESOLVED_WRITE",
  });
  assert.equal(adapter.writes, 0);
});
test("multi-entry queue and source freshness prevent stale successful captures", async (t) => {
  const { service, adapter } = await fixture(t, 30);
  const full = await service.capture(app);
  assert.equal(full.objects.length, 30);
  assert.equal(full.freshness, "verified-across-passes");
  assert.equal(full.metrics.requests, 6);
  adapter.reads = 0;
  adapter.changeOnSecondPass = true;
  const changed = await service.capture(app);
  assert.equal(changed.freshness, "changed");
  assert.equal(changed.atomic, false);
  assert.ok(changed.issues.length);
});

test("large Chinese source pages are complete and non-advancing cursors reject immediately", async (t) => {
  const { service, adapter } = await fixture(t);
  const large = adapter.source(path, "(* 中文源码 *)\n".repeat(100000));
  adapter.sources.set(path, large);
  adapter.actions.push("read_page");
  const original = adapter.invoke.bind(adapter);
  let broken = false;
  adapter.invoke = async (action, args = {}, permit) => {
    if (action === "read_many")
      return {
        ok: true,
        result: { objects: [{ ok: true, paged: true, path }] },
      };
    if (action === "read_page") {
      const text = large[args.part as "declaration" | "implementation"],
        end = Math.min(text.length, args.cursor + args.maxChars);
      return {
        ok: true,
        result: {
          path,
          id: large.id,
          part: args.part,
          cursor: args.cursor,
          chunk: text.slice(args.cursor, end),
          nextCursor: broken ? args.cursor : end === text.length ? null : end,
          sha256: large.sha256,
          sourceComplete: true,
          sourceKind: "POU",
          language: "ST",
        },
      };
    }
    return original(action, args, permit);
  };
  const snapshot = await service.capture(app);
  assert.equal(snapshot.objects[0].implementation, large.implementation);
  assert.equal(snapshot.freshness, "verified-across-passes");
  broken = true;
  await assert.rejects(service.capture(app), { code: "PAGINATION_GAP" });
  assert.equal(service.progress, null);
});
test("lexical protection, partial parser and indirect reference evidence", () => {
  const text =
    "(* outer (* nested *) *)\nIF x THEN\n    GVL_IO.abDO[i] := TRUE;\nEND_IF;\ns := 'END_IF; DO[11] := TRUE';\n{attribute 'keep_CASE'}";
  assert.equal(tokenize(text).issues.length, 0);
  assert.equal(parseST(text).complete, true);
  const o = {
    path,
    declaration: "PROGRAM P",
    implementation: text,
    sha256: sourceHash("PROGRAM P", text),
  };
  const idx = new AnalysisIndex().analyze([o]);
  assert.ok(
    referencesTo(idx.references, "GVL_IO.abDO[11]").some(
      (r) => r.expression === "GVL_IO.abDO[i]" && r.access === "possible-write",
    ),
  );
  assert.equal(parseST("IF x THEN x:=1;").complete, false);
  const fmt = formatST("if x then\ns:='if END_IF'; (* if then *)\nend_if;");
  assert.ok(fmt.text.includes("'if END_IF'"));
  assert.ok(fmt.text.includes("(* if then *)"));
  assert.ok(fmt.text.startsWith("IF"));
  assert.equal(formatST("IF x THEN").changed, false);
});
test("unverified 2025 features block code drafts; standard catalogue includes all requested domains", () => {
  const o = {
    path,
    declaration: "PROGRAM P\nVAR s : USTRING; END_VAR",
    implementation: "",
    sha256: "x",
  };
  assert.ok(
    new AnalysisIndex()
      .analyze([o])
      .findings.some(
        (f) => f.rule === "UNVERIFIED_FEATURE" && f.severity === "error",
      ),
  );
  for (const id of [
    "IEC 61158",
    "IEC 61784",
    "IEC 62541",
    "IEC 61784-3",
    "IEC 62264",
    "IEC 61512",
    "IEC 62714",
    "IEC 62443",
  ])
    assert.ok(standards.some((s) => s.id === id && !s.certification));
});
test("models bind source hashes and cannot be relabelled IDE evidence", () => {
  const o = {
    path,
    declaration: "PROGRAM P",
    implementation: "",
    sha256: sourceHash("PROGRAM P", ""),
  };
  for (const model of [
    "cylinder",
    "initialization",
    "axis-handshake",
  ] as const) {
    const spec = defaultScenarios(model, [o]);
    const result = runRegression(spec, [o]);
    assert.equal(result.status, "passed");
    assert.equal(result.evidence, "offline-model");
    assert.equal(result.plcSimulation, false);
    assert.equal(
      runRegression(spec, [{ ...o, sha256: "changed" }]).status,
      "stale",
    );
    assert.throws(() => importManualEvidence(spec, [o], {} as any));
    const harness = ideHarness(spec);
    assert.ok(harness.needsWiring);
    assert.equal(harness.automaticSimulation, false);
    assert.ok(harness.implementation.includes("NOT xWiringVerified"));
    assert.equal(tokenize(harness.implementation).issues.length, 0);
  }
});
test("AI scope preview and consent bind provider, content, ranges and prompt", async (t) => {
  const { service, dir } = await fixture(t);
  await service.capture(app);
  const providers = new ProviderStore(dir);
  const config = {
    name: "test",
    kind: "openai-chat" as const,
    baseUrl: "https://example.invalid/v1",
    model: "test",
    supportsTools: true,
  };
  const first = await providers.save(config),
    second = await providers.save({ ...config, name: "other" });
  const agent = new AIAgent(service, new TelemetryManager(dir), providers, dir),
    o = service.snapshot!.objects[0];
  const request = {
    providerId: first!.id,
    prompt: "review",
    selections: [
      {
        path,
        part: "implementation" as const,
        startLine: 1,
        endLine: 1,
        sha256: o.sha256,
      },
    ],
  };
  const preview = await agent.preview(request);
  assert.ok(preview.text.includes("abDO"));
  await assert.rejects(
    agent.run(request, () => {}),
    { code: "SEND_CONSENT_REQUIRED" },
  );
  await agent.consent(request);
  await assert.rejects(
    agent.run({ ...request, languageEdition: "2025" }, () => {}),
    { code: "SEND_CONSENT_REQUIRED" },
  );
  await assert.rejects(
    agent.run({ ...request, providerId: second!.id }, () => {}),
    { code: "SEND_CONSENT_REQUIRED" },
  );
  await assert.rejects(
    agent.preview({
      ...request,
      selections: [{ ...request.selections[0], endLine: 999 }],
    }),
    { code: "SCOPE_CHANGED" },
  );
  await providers.save({
    ...config,
    id: first!.id,
    baseUrl: "https://changed.invalid/v1",
  });
  await assert.rejects(
    agent.run(request, () => {}),
    { code: "SEND_CONSENT_REQUIRED" },
  );
});
test("AI never sends a newly changed IDE baseline back to a provider under old source consent", async (t) => {
  const { service, adapter, dir } = await fixture(t);
  await service.capture(app);
  const o = service.snapshot!.objects[0],
    operations = changes(),
    requests: string[] = [],
    events: any[] = [];
  const server = createServer(async (req, res) => {
    let body = "";
    for await (const chunk of req) body += chunk;
    requests.push(body);
    res.writeHead(200, { "Content-Type": "text/event-stream" });
    res.end(
      "data: " +
        JSON.stringify({
          choices: [
            {
              delta: {
                tool_calls: [
                  {
                    index: 0,
                    id: "c",
                    function: {
                      name: "codesys_batch_prepare",
                      arguments: JSON.stringify({
                        applicationPath: app,
                        operations,
                      }),
                    },
                  },
                ],
              },
            },
          ],
        }) +
        "\n\ndata: [DONE]\n\n",
    );
  });
  await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
  t.after(() => new Promise<void>((resolve) => server.close(() => resolve())));
  const providers = new ProviderStore(dir),
    provider = await providers.save({
      name: "local-test",
      kind: "openai-chat",
      baseUrl: "http://127.0.0.1:" + (server.address() as any).port,
      model: "fixture",
      supportsTools: true,
    });
  const agent = new AIAgent(service, new TelemetryManager(dir), providers, dir);
  const request = {
    providerId: provider!.id,
    prompt: "prepare",
    selections: (["declaration", "implementation"] as const).map((part) => ({
      path,
      part,
      startLine: 1,
      endLine: o[part].split("\n").length,
      sha256: o.sha256,
    })),
  };
  await agent.consent(request);
  const privateText = "(* MANUAL_CONFIDENTIAL_CONTENT *)";
  adapter.sources.set(path, adapter.source(path, privateText));
  await agent.run(request, (event) => events.push(event));
  assert.ok(
    events.some((e) => e.type === "paused" && e.reason === "EXPANDED_SCOPE"),
  );
  assert.ok(!JSON.stringify(events).includes(privateText));
  assert.ok(!requests.join("").includes(privateText));
  assert.equal(adapter.writes, 0);
});
test("browser approval cannot be reached from machine RPC or foreign origin; secrets stay out of tool output", async (t) => {
  const { service, dir } = await fixture(t);
  const appServer = await startWorkbench({
    directory: dir,
    root: process.cwd(),
    service,
  });
  t.after(() => appServer.close());
  const { url, token, browserTicket } = appServer.endpoint;
  const rpc = await fetch(url + "/rpc", {
    method: "POST",
    headers: {
      Authorization: "Bearer " + token,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      method: "tools/call",
      name: "codesys_batch_approve",
      arguments: {},
    }),
  });
  assert.equal(rpc.status, 400);
  const forbidden = await fetch(url + "/api/batch/approve", {
    method: "POST",
    headers: {
      Authorization: "Bearer " + token,
      "Content-Type": "application/json",
    },
    body: "{}",
  });
  assert.equal(forbidden.status, 403);
  const login = await fetch(url + "/api/session", {
    method: "POST",
    headers: { Origin: url, "Content-Type": "application/json" },
    body: JSON.stringify({ ticket: browserTicket }),
  });
  const cookie = login.headers.get("set-cookie")!.split(";")[0],
    { csrf } = (await login.json()) as any;
  const cross = await fetch(url + "/api/batch/approve", {
    method: "POST",
    headers: {
      Cookie: cookie,
      Origin: "https://example.com",
      "X-CSRF-Token": csrf,
      "Content-Type": "application/json",
    },
    body: "{}",
  });
  assert.equal(cross.status, 403);
  const b = await service.prepare(app, changes());
  const approved = await fetch(url + "/api/batch/approve", {
    method: "POST",
    headers: {
      Cookie: cookie,
      Origin: url,
      "X-CSRF-Token": csrf,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ batchId: b.id, planHash: b.planHash }),
  });
  assert.equal(approved.status, 200);
});
