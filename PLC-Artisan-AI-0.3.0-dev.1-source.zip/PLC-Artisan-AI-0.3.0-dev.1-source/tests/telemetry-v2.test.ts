import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { setTimeout as delay } from "node:timers/promises";
import {
  TelemetryManager,
  decodeRegisters,
  protocolAddress,
  groupPoints,
  validateTelemetry,
  type Point,
} from "../src/telemetry.js";
import { startMocks } from "../src/mock-protocols.js";
const p = (overrides: Partial<Point> = {}): Point => ({
  id: "p",
  fc: 3,
  address: 40001,
  addressBase: "reference",
  dataType: "UINT",
  byteOrder: "BE",
  wordOrder: "high-low",
  ...overrides,
});
test("Modbus reference numbering, signed values, floating-point word order and range checks", () => {
  assert.equal(protocolAddress(p()), 0);
  assert.equal(protocolAddress(p({ fc: 4, address: 30002 })), 1);
  assert.throws(() => protocolAddress(p({ addressBase: undefined })), {
    code: "ADDRESS_BASE_REQUIRED",
  });
  assert.equal(decodeRegisters([65535], p({ dataType: "INT" })), -1);
  assert.equal(decodeRegisters([0x3f80, 0], p({ dataType: "REAL" })), 1);
  assert.equal(
    decodeRegisters(
      [0, 0x3f80],
      p({ dataType: "REAL", wordOrder: "low-high" }),
    ),
    1,
  );
  assert.equal(
    decodeRegisters([0x803f, 0], p({ dataType: "REAL", byteOrder: "LE" })),
    1,
  );
  assert.throws(() => decodeRegisters([0x7f80, 0], p({ dataType: "REAL" })), {
    code: "NON_FINITE",
  });
  assert.equal(groupPoints([p(), p({ id: "p2", address: 40002 })]).length, 1);
  assert.throws(
    () =>
      validateTelemetry({
        id: "x",
        protocol: "modbus-tcp",
        host: "127.0.0.1",
        port: 502,
        unitId: 1,
        intervalMs: 50,
        points: [],
      }),
    { code: "CONFIG_INVALID" },
  );
});
test(
  "real local Modbus TCP and OPC UA read-only clients produce samples and stop cleanly",
  { timeout: 45000 },
  async (t) => {
    const dir = await mkdtemp(join(tmpdir(), "mcp-protocol-")),
      mocks = await startMocks(dir),
      manager = new TelemetryManager(dir);
    t.after(async () => {
      await manager.close();
      await mocks.close();
      await rm(dir, { recursive: true, force: true });
    });
    await manager.start({
      id: "mb",
      protocol: "modbus-tcp",
      host: "127.0.0.1",
      port: mocks.modbusPort,
      unitId: 1,
      intervalMs: 100,
      points: [
        p({ address: 0, addressBase: "zero" }),
        p({ id: "input", fc: 4, address: 0, addressBase: "zero" }),
        p({
          id: "coil",
          fc: 1,
          address: 0,
          addressBase: "zero",
          dataType: "BOOL",
        }),
        p({
          id: "discrete",
          fc: 2,
          address: 1,
          addressBase: "zero",
          dataType: "BOOL",
        }),
      ],
    });
    for (
      let n = 0;
      n < 60 && (manager.state()[0]?.samples.length ?? 0) < 4;
      n++
    )
      await delay(100);
    const mb = manager.state().find((c) => c.id === "mb")!;
    assert.equal(mb.samples.length, 4);
    assert.equal(mb.samples.find((s) => s.point === "coil")?.value, true);
    assert.equal(mb.samples.find((s) => s.point === "input")?.value, 100);
    assert.ok(mb.samples.every((s) => s.quality === "Good"));
    const config = {
      id: "ua",
      protocol: "opcua" as const,
      endpoint: mocks.endpoint,
      securityMode: "None" as const,
      securityPolicy: "None" as const,
      intervalMs: 100,
      points: [
        { id: "counter", nodeId: "ns=1;s=Counter", dataType: "UDINT" as const },
      ],
    };
    const endpoints = await manager.discover(mocks.endpoint);
    assert.ok(endpoints.length);
    const browse = await manager.browse(config, "ObjectsFolder");
    assert.ok(browse.references.some((r) => r.browseName.includes("McpMock")));
    const attributes = await manager.readAttributes(config, [
      { nodeId: "ns=1;s=Ready", attribute: "Value" },
      { nodeId: "ns=1;s=Counter", attribute: "DataType" },
      { nodeId: "ns=1;s=missing", attribute: "Value" },
    ]);
    assert.equal(attributes[0].value, true);
    assert.equal(attributes[0].quality, "Good");
    assert.match(attributes[2].quality, /BadNodeIdUnknown/);
    await assert.rejects(
      manager.readAttributes(config, [
        { nodeId: "ns=1;s=Counter", attribute: "Write" },
      ]),
      { code: "ATTRIBUTE_INVALID" },
    );
    const secure = {
      ...config,
      securityMode: "SignAndEncrypt" as const,
      securityPolicy: "Basic256Sha256" as const,
      trustedFingerprint: "0".repeat(64),
    };
    await assert.rejects(manager.browse(secure), {
      code: "CERTIFICATE_CHANGED",
    });
    await assert.rejects(manager.trust(mocks.endpoint, "0".repeat(64)), {
      code: "CERTIFICATE_CHANGED",
    });
    const fingerprint = endpoints.find(
      (e) => e.securityMode === "SignAndEncrypt",
    )!.fingerprint!;
    // Pinning a certificate is insufficient: it must also have been explicitly trusted.
    await assert.rejects(
      manager.browse({ ...secure, trustedFingerprint: fingerprint }),
    );
    await manager.trust(mocks.endpoint, fingerprint);
    const secureRead = await manager.readAttributes(
      { ...secure, trustedFingerprint: fingerprint },
      [{ nodeId: "ns=1;s=Ready", attribute: "Value" }],
    );
    assert.equal(secureRead[0].value, true);
    await manager.start(config);
    for (
      let n = 0;
      n < 100 && !manager.state().find((c) => c.id === "ua")?.samples.length;
      n++
    )
      await delay(100);
    const ua = manager.state().find((c) => c.id === "ua")!;
    assert.ok(ua.samples.length, ua.error);
    assert.equal(ua.samples[0].quality, "Good");
    assert.ok(ua.revisedInterval);
    assert.ok(manager.csv("mb").includes("sourceTimestamp"));
    await manager.stop("ua");
    await manager.stop("mb");
    assert.ok(manager.state().every((c) => c.state === "stopped"));
  },
);
