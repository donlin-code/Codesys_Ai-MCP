# v0.2 acceptance record / 验收记录

Date: 2026-10-24. Status: **acceptance candidate, not full native acceptance**.

| Capability | Actual evidence | Status |
| --- | --- | --- |
| Backend and web TypeScript | Type checking and builds | Automated |
| Original and v0.2 Node tests | Batch approval, stale baselines/GUIDs, queueing, unknown outcomes, providers, DPAPI, parsing, protocol clients | Automated |
| Python bridge contracts | Identity/authentication, unsigned/tampered/expired/replay rejection, tree traversal, source/readback and compiler diagnostics | Automated; ScriptEngine double |
| React workbench | Headless Edge: edit draft, full diff, required review, approve, execute/readback, build, standards and language switch | Automated; fixture adapter |
| Modbus TCP and OPC UA | Actual local simulated TCP servers, FC1–4, decode/order, UA attributes, subscription, bad quality, certificate rejection/pinning/trust and encrypted read | Local protocol test |
| SP20 real source reads | Isolated GUI test copy: 149 complete ST objects, 212,465 bytes; other objects separately reported | Native read verified |
| SP20 performance | Three trials each; sequential 124088/111115/135430 ms, batch 54061/40315/41833 ms; medians 124088→41833 ms, 66.3% lower; requests307→15 | Native measured |
| Task/device/I/O context | Four tasks, 31 devices and 31 I/O groups read from the test copy | Native read verified |
| Library context | SP20 returned names rather than objects; corrected using references[name]. A fresh generic SP20 test copy read its library manager successfully | Native read verified on generic copy |
| v0.2 signed IDE editing | Exact three-object plan approved in the workbench; DUT, GVL and PROGRAM created through the shared service and matching fresh bridge, each independently read back | Native create/readback passed; replacement/conflict/unknown cases remain contract-tested |
| New build association/diagnostic fields | Generic test copy baseline and approved edited source rebuilt with 0 errors / 0 warnings; matching before/after source scope | Native positive case passed; negative diagnostic case pending |
| Save/reopen | Historical v0.1 tests exist locally, not evidence for new v0.2 edits | Pending for v0.2 |
| Cylinder/init/axis reference models | Deterministic source-bound offline scenarios; staleness checks | Offline only |
| IDE simulation / actual behavior | Harness drafts and manual evidence import delivered | Pending |
| Cloud AI providers | Four native interface formats, stream/tool/cancel/error/scope tests, DPAPI test | Real credential calls pending |
| FUNCTION/INTERFACE/PROPERTY/non-structure DUT | Adapter preparation behind capability gate | Disabled pending native acceptance |
| SP22 / InoProShop / Motion Expert | Capability/status boundary and environment detection | Unverified |
| Real PLC telemetry | Only local mock services used | Pending |
| Node version | Development runtime Node24.22.1; portable Node22.23.4 selected for release checks; engines require22+ | See release VALIDATION.json for the actual passing local runtime; remote CI not yet run |

The performance comparison uses the same v0.2 completeness and freshness checks in sequential/batched transport modes. It is not a benchmark against the previous published binary. Counts cover the selected Application and complete ST sources, not all graphical, protected or vendor objects. Collection is an observation across an interval, not an atomic snapshot.

DO[11] diagnostic case: the captured test copy has one direct read reference in PRG_Main; source alone does not exclude dynamic indexing, aliases, retained/startup configuration or driver behavior. Its provenance is a prior test copy, so this does not establish the startup cause in the latest original project. Correlate current authorized source, I/O defaults and online observations before asserting a cause. Raw business evidence is deliberately excluded from the package.

The release's VALIDATION.json records checks that actually passed for that release; DOWNLOAD-SHA256.json identifies the ZIPs. Fixture/offline results must never be relabelled as IDE or device evidence. No original engineering project was modified during this v0.2 implementation run. Native saves, close/reopen and simulation remain operator steps.

标准目录和生成检查已纳入 IEC 61131-3/-8/-10、61158/61784、62541、61508/62061、ISO13849-1、61784-3、62264、61512、62714、62443 等的适用边界。目录不等于这些协议全部实现；工具不提供安全认证。

Native smoke plan `005a18fe74c23fc3b3435ffc925529a2f18c401306faa202a59cdca6572d1952` was approved by the human in the workbench. Three generic objects (DUT, GVL, PROGRAM) were created and read back; the associated full build passed with 0 errors / 0 warnings. The program is not added to a task, has no physical I/O, and the project was not saved. I/O defaults and structured error positions still require field-level evidence; an empty or unavailable field is not proof that no configuration exists.

Runtime packaging consolidates 43 public dependency `.txt` license/copyright notices into THIRD-PARTY-NOTICES.md with an original-path/byte-count/SHA-256 map. Their text is retained verbatim; other license files remain in place. This avoids this Windows environment's archive handler changing those notice entries after packaging. No system security settings are changed. Only a release that passes a subsequent archive/clean-install check should be distributed.
