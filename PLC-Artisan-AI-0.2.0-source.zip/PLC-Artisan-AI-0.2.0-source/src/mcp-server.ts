#!/usr/bin/env node
import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
} from "@modelcontextprotocol/sdk/types.js";
import { publicTools } from "./toolkit.js";
import { ensureService, rpc } from "./service-client.js";
export const bridgeTools = publicTools;
async function main() {
  const args = process.argv.slice(2),
    option = (key: string) => {
      const i = args.indexOf("--" + key);
      return i >= 0 ? args[i + 1] : undefined;
    };
  const endpoint = await ensureService(option("data"), option("config"));
  const server = new Server(
    { name: "plc-artisan-ai", version: "0.2.0" },
    {
      capabilities: { tools: {} },
      instructions:
        "Experimental SP20 isolated-project adapter. Human approves exact batches in the local workbench; no approval tool exists. Stop on conflicts or unknown writes. Readback, compilation, save/reopen and behavior are distinct. No PLC download/start/force.",
    },
  );
  server.setRequestHandler(ListToolsRequestSchema, async () => ({
    tools: publicTools as any,
  }));
  server.setRequestHandler(CallToolRequestSchema, async (request) => {
    try {
      const value = await rpc(endpoint, {
        method: "tools/call",
        name: request.params.name,
        arguments: request.params.arguments ?? {},
      });
      return {
        content: [{ type: "text" as const, text: JSON.stringify(value) }],
      };
    } catch (e) {
      return {
        isError: true,
        content: [
          {
            type: "text" as const,
            text: JSON.stringify({
              ok: false,
              error: {
                code: (e as any).code ?? "CLIENT_ERROR",
                message: (e as Error).message,
              },
            }),
          },
        ],
      };
    }
  });
  await server.connect(new StdioServerTransport());
}
main().catch((e) => {
  console.error((e as Error).message);
  process.exitCode = 1;
});
