#!/usr/bin/env node
import {
  createServer,
  type IncomingMessage,
  type ServerResponse,
} from "node:http";
import { randomBytes, timingSafeEqual, randomUUID } from "node:crypto";
import { readFile, mkdir, open, unlink } from "node:fs/promises";
import { join, dirname, resolve, extname } from "node:path";
import { fileURLToPath } from "node:url";
import { EngineeringService } from "./engineering.js";
import { TelemetryManager } from "./telemetry.js";
import { ProviderStore } from "./providers.js";
import { AIAgent } from "./ai-agent.js";
import { publicTools, invokeTool } from "./toolkit.js";
import { AppError, loadJson, saveJson, inside } from "./core.js";
import { standards } from "./standards.js";
import {
  defaultScenarios,
  runRegression,
  importManualEvidence,
  ideHarness,
} from "./regression.js";
import { searchDocuments, gitInspect, gitCheckpoint } from "./local-assets.js";
import { workbenchDoctor } from "./environment.js";

export interface ServiceEndpoint {
  url: string;
  token: string;
  browserTicket: string;
  pid: number;
  startedAt: string;
}
function secureEqual(a: string, b: string) {
  const aa = Buffer.from(a),
    bb = Buffer.from(b);
  return aa.length === bb.length && timingSafeEqual(aa, bb);
}
async function body(req: IncomingMessage): Promise<any> {
  const chunks: Buffer[] = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > 8 * 1024 * 1024)
      throw new AppError("BODY_TOO_LARGE", "Request limit is 8 MiB");
    chunks.push(chunk);
  }
  try {
    return JSON.parse(Buffer.concat(chunks).toString("utf8") || "{}");
  } catch {
    throw new AppError("INVALID_JSON", "Invalid JSON body");
  }
}
function json(res: ServerResponse, value: unknown, status = 200) {
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
  });
  res.end(JSON.stringify(value));
}
export async function startWorkbench(options: {
  directory: string;
  root: string;
  service?: EngineeringService;
  port?: number;
  config?: string;
}) {
  const { directory, root } = options;
  await mkdir(directory, { recursive: true });
  const service = options.service ?? new EngineeringService(directory),
    telemetry = new TelemetryManager(directory),
    providers = new ProviderStore(directory),
    ai = new AIAgent(service, telemetry, providers, directory);
  const token = randomBytes(32).toString("hex"),
    browserTicket = randomBytes(32).toString("hex"),
    sessions = new Map<string, string>();
  let origin = "";
  let documentRoots = await loadJson<string[]>(
    join(directory, "document-roots.json"),
    [],
  );
  const server = createServer(async (req, res) => {
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("Referrer-Policy", "no-referrer");
    res.setHeader(
      "Content-Security-Policy",
      "default-src 'none'; script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; font-src 'self' data:; worker-src 'self' blob:; frame-ancestors 'none'; base-uri 'none'; form-action 'self'",
    );
    try {
      if (req.headers.host !== new URL(origin).host)
        throw new AppError("HOST_DENIED", "Invalid local Host header");
      const url = new URL(req.url ?? "/", origin),
        path = url.pathname;
      if (req.method === "POST" && path === "/rpc") {
        if (
          req.headers.origin ||
          !secureEqual(req.headers.authorization ?? "", "Bearer " + token)
        )
          throw new AppError(
            "RPC_DENIED",
            "Machine transport authorization required",
          );
        const input = await body(req);
        if (input.method === "tools/list")
          return json(res, { tools: publicTools });
        if (input.method !== "tools/call")
          throw new AppError(
            "METHOD_DENIED",
            "Only tool discovery/calls are exposed",
          );
        return json(res, {
          ok: true,
          result: await invokeTool(
            service,
            telemetry,
            input.name,
            input.arguments,
          ),
        });
      }
      if (req.method === "POST" && path === "/api/session") {
        if (req.headers.origin !== origin)
          throw new AppError("ORIGIN_DENIED", "Same-origin browser required");
        const input = await body(req);
        if (!secureEqual(input.ticket ?? "", browserTicket))
          throw new AppError("LOGIN_REQUIRED", "Open the local launcher link");
        const sessionId = randomBytes(32).toString("hex"),
          csrf = randomBytes(32).toString("hex");
        sessions.set(sessionId, csrf);
        res.setHeader(
          "Set-Cookie",
          `workbench=${sessionId}; HttpOnly; SameSite=Strict; Path=/`,
        );
        return json(res, { csrf });
      }
      if (path.startsWith("/api/")) {
        const sessionId = /(?:^|;\s*)workbench=([a-f0-9]+)/.exec(
            req.headers.cookie ?? "",
          )?.[1],
          csrf = sessions.get(sessionId ?? "");
        if (!csrf)
          throw new AppError(
            "LOGIN_REQUIRED",
            "Open the launcher link in this browser",
          );
        if (
          req.method !== "GET" &&
          (req.headers.origin !== origin ||
            !secureEqual(String(req.headers["x-csrf-token"] ?? ""), csrf))
        )
          throw new AppError(
            "ORIGIN_DENIED",
            "Same-origin request and CSRF token required",
          );
        if (req.method === "GET") {
          if (path === "/api/session") return json(res, { csrf });
          if (path === "/api/status") return json(res, await service.status());
          if (path === "/api/tools") return json(res, publicTools);
          if (path === "/api/standards") return json(res, standards);
          if (path === "/api/batches")
            return json(res, await service.batches());
          if (path === "/api/snapshot")
            return json(res, service.snapshot ?? null);
          if (path === "/api/providers")
            return json(res, await providers.list());
          if (path === "/api/telemetry")
            return json(res, {
              configs: await telemetry.configs(),
              connections: telemetry.state(),
            });
          if (path === "/api/documents") return json(res, documentRoots);
          if (path === "/api/git") return json(res, await gitInspect(root));
          if (path === "/api/telemetry/csv") {
            res.writeHead(200, {
              "Content-Type": "text/csv; charset=utf-8",
              "Content-Disposition": 'attachment; filename="telemetry.csv"',
            });
            return res.end(
              "\uFEFF" + telemetry.csv(url.searchParams.get("id") ?? ""),
            );
          }
          if (path === "/api/report")
            return json(res, {
              generatedAt: new Date().toISOString(),
              status: await service.status(),
              snapshot: service.snapshot,
              analysis: service.snapshot ? service.analyze() : null,
              batches: await service.batches(),
              telemetry: telemetry.state(),
              liveAcceptance:
                "See versioned acceptance record; compilation is not simulation or persistence.",
            });
        }
        if (req.method === "POST") {
          const input = await body(req);
          if (path === "/api/connect")
            return json(res, await service.connect(String(input.config)));
          if (path === "/api/doctor")
            return json(res, await workbenchDoctor(input));
          if (path === "/api/tool")
            return json(
              res,
              await invokeTool(service, telemetry, input.name, input.arguments),
            );
          if (path === "/api/batch/approve")
            return json(
              res,
              await service.approve(input.batchId, input.planHash),
            );
          if (path === "/api/providers")
            return json(res, await providers.save(input));
          if (path === "/api/ai/preview")
            return json(res, await ai.preview(input));
          if (path === "/api/ai/consent")
            return json(res, await ai.consent(input));
          if (path === "/api/ai/run") {
            const controller = new AbortController();
            res.on("close", () => {
              if (!res.writableEnded) controller.abort();
            });
            res.writeHead(200, {
              "Content-Type": "application/x-ndjson; charset=utf-8",
              "Cache-Control": "no-store",
            });
            const emit = (value: unknown) => {
              if (!res.destroyed) res.write(JSON.stringify(value) + "\n");
            };
            try {
              await ai.run(input, emit, controller.signal);
            } catch (e) {
              emit({
                type: "error",
                code: (e as any).code ?? "AI_FAILED",
                message: (e as Error).message,
              });
            }
            return res.end();
          }
          if (path === "/api/telemetry/config")
            return json(res, await telemetry.save(input));
          if (path === "/api/telemetry/start") {
            const config = (await telemetry.configs()).find(
              (c) => c.id === input.id,
            );
            if (!config)
              throw new AppError(
                "CONFIG_MISSING",
                "Save a connection profile first",
              );
            return json(res, await telemetry.start(config));
          }
          if (path === "/api/telemetry/stop") {
            await telemetry.stop(input.id);
            return json(res, { stopped: true });
          }
          if (path === "/api/telemetry/discover")
            return json(res, await telemetry.discover(input.endpoint));
          if (path === "/api/telemetry/trust")
            return json(
              res,
              await telemetry.trust(input.endpoint, input.fingerprint),
            );
          if (path === "/api/telemetry/browse")
            return json(
              res,
              await telemetry.browse(input.config, input.nodeId),
            );
          if (path === "/api/telemetry/attributes")
            return json(
              res,
              await telemetry.readAttributes(input.config, input.nodes),
            );
          if (path === "/api/telemetry/history")
            return json(res, telemetry.history(input.id));
          if (path.startsWith("/api/regression/")) {
            const objects =
              service.snapshot?.objects.filter(
                (o) => !input.paths?.length || input.paths.includes(o.path),
              ) ?? [];
            if (!objects.length)
              throw new AppError(
                "SNAPSHOT_REQUIRED",
                "Select source objects in a current snapshot",
              );
            if (path === "/api/regression/prepare") {
              const spec = defaultScenarios(input.model, objects);
              return json(res, { spec, harness: ideHarness(spec) });
            }
            const result =
              path === "/api/regression/manual"
                ? importManualEvidence(input.spec, objects, input.record)
                : runRegression(input.spec, objects);
            await saveJson(
              join(directory, "regressions", randomUUID() + ".json"),
              result,
            );
            return json(res, result);
          }
          if (path === "/api/documents/roots") {
            if (!Array.isArray(input.roots) || input.roots.length > 20)
              throw new AppError(
                "ROOTS_INVALID",
                "Select at most 20 document directories",
              );
            const checked = [];
            for (const r of input.roots)
              checked.push(await inside(String(r), "."));
            documentRoots = checked;
            await saveJson(join(directory, "document-roots.json"), checked);
            return json(res, checked);
          }
          if (path === "/api/documents/search")
            return json(res, await searchDocuments(documentRoots, input.query));
          if (path === "/api/git/checkpoint")
            return json(
              res,
              await gitCheckpoint(root, input.files, input.message),
            );
        }
        throw new AppError("NOT_FOUND", "Unknown human-control API");
      }
      if (req.method !== "GET")
        throw new AppError("METHOD_DENIED", "Static content uses GET");
      const file = await inside(
          join(root, "web-dist"),
          path === "/"
            ? "index.html"
            : decodeURIComponent(path).replace(/^\//, ""),
        ),
        data = await readFile(file);
      const mime: Record<string, string> = {
        ".html": "text/html; charset=utf-8",
        ".js": "text/javascript; charset=utf-8",
        ".css": "text/css; charset=utf-8",
        ".svg": "image/svg+xml",
        ".ttf": "font/ttf",
        ".woff2": "font/woff2",
      };
      res.writeHead(200, {
        "Content-Type": mime[extname(file)] ?? "application/octet-stream",
      });
      return res.end(data);
    } catch (e) {
      if (!res.headersSent) {
        const code = (e as any).code ?? "REQUEST_FAILED";
        json(
          res,
          { ok: false, error: { code, message: (e as Error).message } },
          [
            "LOGIN_REQUIRED",
            "RPC_DENIED",
            "ORIGIN_DENIED",
            "HOST_DENIED",
          ].includes(code)
            ? 403
            : code === "NOT_FOUND"
              ? 404
              : 400,
        );
      } else res.end();
    }
  });
  server.requestTimeout = 180000;
  await new Promise<void>((resolve, reject) => {
    server.once("error", reject);
    server.listen(options.port ?? 0, "127.0.0.1", () => resolve());
  });
  const address = server.address();
  if (!address || typeof address === "string")
    throw new Error("No loopback address");
  origin = `http://127.0.0.1:${address.port}`;
  const endpoint: ServiceEndpoint = {
    url: origin,
    token,
    browserTicket,
    pid: process.pid,
    startedAt: new Date().toISOString(),
  };
  await saveJson(join(directory, "service.json"), endpoint);
  if (options.config)
    try {
      await service.connect(options.config);
    } catch (e) {
      service.lastError = {
        code: (e as any).code ?? "OFFLINE",
        message: (e as Error).message,
      };
    }
  return {
    server,
    service,
    telemetry,
    endpoint,
    close: async () => {
      await telemetry.close();
      server.closeAllConnections();
      await new Promise<void>((r) => server.close(() => r()));
    },
  };
}
async function main() {
  const args = process.argv.slice(2),
    option = (name: string) => {
      const i = args.indexOf("--" + name);
      return i < 0 ? undefined : args[i + 1];
    };
  const root = resolve(dirname(fileURLToPath(import.meta.url)), "../.."),
    directory = resolve(option("data") ?? join(root, "artifacts", "workbench"));
  await mkdir(directory, { recursive: true });
  let lock;
  try {
    lock = await open(join(directory, "service.lock"), "wx");
  } catch {
    throw new AppError(
      "SERVICE_BUSY",
      "Service lock exists. Inspect its PID before recovery.",
    );
  }
  await lock.writeFile(
    JSON.stringify({ pid: process.pid, startedAt: new Date().toISOString() }),
  );
  try {
    const app = await startWorkbench({
      directory,
      root,
      port: option("port") ? Number(option("port")) : undefined,
      config: option("config"),
    });
    process.stdout.write(
      `PLC Artisan AI v0.2: ${app.endpoint.url}/#ticket=${app.endpoint.browserTicket}\n`,
    );
    const close = async () => {
      await app.close();
      await lock.close();
      await unlink(join(directory, "service.lock"));
      process.exit(0);
    };
    process.once("SIGINT", close);
    process.once("SIGTERM", close);
  } catch (e) {
    await lock.close();
    await unlink(join(directory, "service.lock"));
    throw e;
  }
}
if (
  process.argv[1] &&
  resolve(process.argv[1]) === fileURLToPath(import.meta.url)
)
  main().catch((e) => {
    console.error((e as Error).message);
    process.exitCode = 1;
  });
