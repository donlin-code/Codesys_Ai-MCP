import { defaultProfile, type TargetProfile } from "./standards.js";
import { sha256 } from "./core.js";

export interface Token {
  kind: "id" | "number" | "string" | "symbol" | "comment" | "pragma";
  text: string;
  start: number;
  end: number;
  line: number;
  column: number;
}
export interface ParseIssue {
  line: number;
  message: string;
}
export interface Statement {
  kind: "assign" | "call" | "control" | "other";
  line: number;
  target?: string;
  value?: string;
  conditional: boolean;
  tokens: Token[];
}
export type Expression =
  | { kind: "literal" | "name"; value: string }
  | { kind: "unary"; operator: string; operand: Expression }
  | { kind: "binary"; operator: string; left: Expression; right: Expression }
  | { kind: "member"; object: Expression; member: string }
  | { kind: "index"; object: Expression; indices: Expression[] }
  | {
      kind: "call";
      callee: Expression;
      arguments: { name?: string; output?: boolean; value: Expression }[];
    };
export interface SourceObject {
  path: string;
  id?: string;
  declaration: string;
  implementation: string;
  sha256: string;
  sourceComplete?: boolean;
  language?: string;
  sourceKind?: string;
}
export interface Finding {
  rule: string;
  path: string;
  part: "declaration" | "implementation";
  line: number;
  column: number;
  snippet: string;
  severity: "error" | "warning" | "info";
  confidence: "confirmed-static" | "possible";
  evidence: "static";
  message: string;
  verification: string;
  standard: string;
}
const keywords = new Set(
  "PROGRAM END_PROGRAM FUNCTION_BLOCK END_FUNCTION_BLOCK FUNCTION END_FUNCTION METHOD END_METHOD INTERFACE END_INTERFACE PROPERTY END_PROPERTY VAR VAR_INPUT VAR_OUTPUT VAR_IN_OUT VAR_TEMP VAR_GLOBAL VAR_STAT END_VAR RETAIN PERSISTENT CONSTANT AT TYPE END_TYPE STRUCT END_STRUCT UNION END_UNION ARRAY OF EXTENDS IMPLEMENTS PUBLIC PRIVATE PROTECTED INTERNAL ABSTRACT FINAL OVERRIDE IF THEN ELSIF ELSE END_IF CASE END_CASE FOR TO BY DO END_FOR WHILE END_WHILE REPEAT UNTIL END_REPEAT EXIT CONTINUE RETURN TRUE FALSE AND OR XOR NOT MOD BOOL BYTE WORD DWORD LWORD SINT USINT INT UINT DINT UDINT LINT ULINT REAL LREAL TIME LTIME STRING WSTRING DATE DT TOD POINTER REFERENCE REF_TO THIS SUPER".split(
    " ",
  ),
);

export function tokenize(text: string): {
  tokens: Token[];
  issues: ParseIssue[];
} {
  const tokens: Token[] = [],
    issues: ParseIssue[] = [];
  let i = 0,
    line = 1,
    column = 1;
  function emit(kind: Token["kind"], end: number) {
    const value = text.slice(i, end);
    tokens.push({ kind, text: value, start: i, end, line, column });
    const lines = value.split("\n");
    line += lines.length - 1;
    column =
      lines.length > 1 ? lines.at(-1)!.length + 1 : column + value.length;
    i = end;
  }
  while (i < text.length) {
    const c = text[i];
    if (/\s/.test(c)) {
      if (c === "\n") {
        line++;
        column = 1;
      } else column++;
      i++;
      continue;
    }
    if (text.startsWith("//", i)) {
      const end = text.indexOf("\n", i);
      emit("comment", end < 0 ? text.length : end);
      continue;
    }
    if (text.startsWith("(*", i)) {
      let end = i + 2,
        depth = 1;
      while (end < text.length && depth) {
        if (text.startsWith("(*", end)) {
          depth++;
          end += 2;
        } else if (text.startsWith("*)", end)) {
          depth--;
          end += 2;
        } else end++;
      }
      if (depth) issues.push({ line, message: "Unclosed nested comment" });
      emit("comment", end);
      continue;
    }
    if (c === "'" || c === '"') {
      let end = i + 1,
        closed = false;
      while (end < text.length) {
        if (text[end] === "$") {
          end += 2;
          continue;
        }
        if (text[end] === c) {
          if (text[end + 1] === c) {
            end += 2;
            continue;
          }
          end++;
          closed = true;
          break;
        }
        end++;
      }
      if (!closed) issues.push({ line, message: "Unclosed string literal" });
      emit("string", Math.min(end, text.length));
      continue;
    }
    if (c === "{") {
      let end = i + 1,
        quote = "";
      while (end < text.length) {
        const ch = text[end++];
        if (quote) {
          if (ch === "$") end++;
          else if (ch === quote) quote = "";
        } else if (ch === "'" || ch === '"') quote = ch;
        else if (ch === "}") break;
      }
      if (text[end - 1] !== "}")
        issues.push({ line, message: "Unclosed pragma" });
      emit("pragma", end);
      continue;
    }
    const rest = text.slice(i),
      id = /^[A-Za-z_][A-Za-z0-9_]*/.exec(rest),
      number =
        /^(?:\d+#[0-9A-Fa-f_]+|\d[\d_]*(?:\.(?!\.)\d[\d_]*)?(?:[Ee][+-]?\d+)?)/.exec(
          rest,
        );
    if (id) {
      emit("id", i + id[0].length);
      continue;
    }
    if (number) {
      emit("number", i + number[0].length);
      continue;
    }
    const op = /^(?::=|=>|<>|<=|>=|\.\.|\*\*|[;:,().\[\]+\-*/=<>#^&])/u.exec(
      rest,
    );
    if (op) {
      emit("symbol", i + op[0].length);
      continue;
    }
    issues.push({ line, message: `Unsupported token ${c}` });
    emit("symbol", i + 1);
  }
  return { tokens, issues };
}
const significant = (tokens: Token[]) =>
  tokens.filter((t) => t.kind !== "comment" && t.kind !== "pragma");
const join = (tokens: Token[]) => tokens.map((t) => t.text).join("");

/** Expression grammar used for analysis only; compiler remains the type authority. */
export function parseExpression(tokens: Token[]): Expression {
  let index = 0;
  const precedence: Record<string, number> = {
    OR: 1,
    XOR: 2,
    AND: 3,
    "&": 3,
    "=": 4,
    "<>": 4,
    "<": 5,
    ">": 5,
    "<=": 5,
    ">=": 5,
    "+": 6,
    "-": 6,
    "*": 7,
    "/": 7,
    MOD: 7,
    "**": 8,
  };
  function take(text: string) {
    if (tokens[index]?.text.toUpperCase() !== text)
      throw new Error("Expected " + text);
    return tokens[index++];
  }
  function expression(min = 0): Expression {
    const first = tokens[index++];
    if (!first) throw new Error("Missing expression");
    let left: Expression;
    if (["NOT", "-", "+"].includes(first.text.toUpperCase()))
      left = {
        kind: "unary",
        operator: first.text.toUpperCase(),
        operand: expression(9),
      };
    else if (first.text === "(") {
      left = expression();
      take(")");
    } else if (
      first.kind === "id" ||
      first.kind === "number" ||
      first.kind === "string"
    ) {
      let value = first.text;
      if (tokens[index]?.text === "#") {
        index++;
        const next = tokens[index++];
        if (!next) throw new Error("Incomplete typed literal");
        value += "#" + next.text;
        while (tokens[index]?.kind === "id" || tokens[index]?.kind === "number")
          value += tokens[index++].text;
      }
      left = {
        kind:
          first.kind === "id" &&
          !/^(TRUE|FALSE)$/i.test(first.text) &&
          !value.includes("#")
            ? "name"
            : "literal",
        value,
      };
    } else throw new Error("Unsupported expression token " + first.text);
    while (index < tokens.length) {
      const word = tokens[index].text.toUpperCase();
      if (word === ".") {
        index++;
        const name = tokens[index++];
        if (name?.kind !== "id") throw new Error("Missing member");
        left = { kind: "member", object: left, member: name.text };
        continue;
      }
      if (word === "[") {
        index++;
        const indices = [expression()];
        while (tokens[index]?.text === ",") {
          index++;
          indices.push(expression());
        }
        take("]");
        left = { kind: "index", object: left, indices };
        continue;
      }
      if (word === "(") {
        index++;
        const args: { name?: string; output?: boolean; value: Expression }[] =
          [];
        while (tokens[index]?.text !== ")") {
          let name: string | undefined, output: boolean | undefined;
          if (
            tokens[index]?.kind === "id" &&
            [":=", "=>"].includes(tokens[index + 1]?.text)
          ) {
            name = tokens[index++].text;
            output = tokens[index++].text === "=>";
          }
          args.push({ name, output, value: expression() });
          if (tokens[index]?.text !== ",") break;
          index++;
        }
        take(")");
        left = { kind: "call", callee: left, arguments: args };
        continue;
      }
      const p = precedence[word];
      if (p === undefined || p < min) break;
      index++;
      left = {
        kind: "binary",
        operator: word,
        left,
        right: expression(word === "**" ? p : p + 1),
      };
    }
    return left;
  }
  const result = expression();
  if (index !== tokens.length) throw new Error("Unsupported expression suffix");
  return result;
}
export function parseDeclarations(text: string) {
  const lexical = tokenize(text),
    tokens = significant(lexical.tokens),
    declarations: {
      names: string[];
      type: string;
      initializer?: string;
      address?: string;
      retain: boolean;
      persistent: boolean;
      line: number;
    }[] = [];
  let inBlock = false,
    retain = false,
    persistent = false,
    buffer: Token[] = [];
  const flush = () => {
    const colon = buffer.findIndex((t) => t.text === ":");
    if (colon < 1) {
      buffer = [];
      return;
    }
    const init = buffer.findIndex((t) => t.text === ":="),
      at = buffer.findIndex((t) => t.text.toUpperCase() === "AT");
    declarations.push({
      names: buffer
        .slice(0, at < 0 ? colon : at)
        .filter((t) => t.kind === "id")
        .map((t) => t.text),
      type: join(buffer.slice(colon + 1, init < 0 ? undefined : init)),
      initializer: init < 0 ? undefined : join(buffer.slice(init + 1)),
      address: at < 0 ? undefined : join(buffer.slice(at + 1, colon)),
      retain,
      persistent,
      line: buffer[0].line,
    });
    buffer = [];
  };
  for (const t of tokens) {
    const word = t.text.toUpperCase();
    if (/^VAR(?:_(?:INPUT|OUTPUT|IN_OUT|TEMP|GLOBAL|STAT))?$/.test(word)) {
      inBlock = true;
      retain = persistent = false;
      buffer = [];
      continue;
    }
    if (word === "END_VAR") {
      flush();
      inBlock = false;
      continue;
    }
    if (!inBlock) continue;
    if (!buffer.length && ["RETAIN", "PERSISTENT", "CONSTANT"].includes(word)) {
      retain ||= word === "RETAIN";
      persistent ||= word === "PERSISTENT";
      continue;
    }
    if (t.text === ";") flush();
    else buffer.push(t);
  }
  return {
    declarations,
    issues: [
      ...lexical.issues,
      ...(inBlock
        ? [
            {
              line: tokens.at(-1)?.line ?? 1,
              message: "Unclosed variable block",
            },
          ]
        : []),
    ],
  };
}

/** Conservative statement structure, not a complete IEC type checker or executor. */
export function parseST(text: string) {
  const lexical = tokenize(text),
    tokens = significant(lexical.tokens),
    issues = [...lexical.issues],
    statements: Statement[] = [],
    expressions: { line: number; expression: Expression }[] = [];
  const stack: string[] = [];
  let buffer: Token[] = [],
    parens = 0,
    brackets = 0;
  const open: Record<string, string> = {
    IF: "END_IF",
    CASE: "END_CASE",
    FOR: "END_FOR",
    WHILE: "END_WHILE",
    REPEAT: "END_REPEAT",
  };
  function flush() {
    if (!buffer.length) return;
    const assign = buffer.findIndex((t) => t.text === ":="),
      conditional = stack.length > 0;
    const topAssign =
      assign >= 0 && !buffer.slice(0, assign).some((t) => t.text === "(");
    if (topAssign) {
      try {
        expressions.push({
          line: buffer[assign].line,
          expression: parseExpression(buffer.slice(assign + 1)),
        });
      } catch (e) {
        issues.push({
          line: buffer[assign].line,
          message: (e as Error).message,
        });
      }
    } else if (
      buffer[0].kind === "id" &&
      !keywords.has(buffer[0].text.toUpperCase()) &&
      buffer.some((t) => t.text === "(")
    ) {
      try {
        expressions.push({
          line: buffer[0].line,
          expression: parseExpression(buffer),
        });
      } catch (e) {
        issues.push({ line: buffer[0].line, message: (e as Error).message });
      }
    }
    statements.push({
      kind: topAssign
        ? "assign"
        : buffer.some((t) => t.text === "(")
          ? "call"
          : "other",
      line: buffer[0].line,
      target: topAssign ? join(buffer.slice(0, assign)) : undefined,
      value: topAssign ? join(buffer.slice(assign + 1)) : undefined,
      conditional,
      tokens: buffer,
    });
    buffer = [];
  }
  for (const t of tokens) {
    const word = t.text.toUpperCase();
    if (word in open) {
      flush();
      stack.push(open[word]);
      statements.push({
        kind: "control",
        line: t.line,
        tokens: [t],
        conditional: stack.length > 1,
      });
    }
    if (
      word.startsWith("END_") &&
      ["END_IF", "END_CASE", "END_FOR", "END_WHILE", "END_REPEAT"].includes(
        word,
      )
    ) {
      flush();
      if (stack.pop() !== word)
        issues.push({
          line: t.line,
          message: "Unbalanced control block " + word,
        });
      continue;
    }
    if (["THEN", "DO", "OF", "ELSE", "ELSIF"].includes(word)) {
      flush();
      continue;
    }
    if (t.text === "(") parens++;
    if (t.text === ")") parens--;
    if (t.text === "[") brackets++;
    if (t.text === "]") brackets--;
    if (parens < 0 || brackets < 0)
      issues.push({ line: t.line, message: "Unbalanced expression delimiter" });
    if (t.text === ";" && parens === 0 && brackets === 0) flush();
    else buffer.push(t);
  }
  flush();
  if (stack.length || parens || brackets)
    issues.push({
      line: tokens.at(-1)?.line ?? 1,
      message: "Incomplete control flow or expression",
    });
  if (
    tokens.some((t) =>
      ["POINTER", "ADR", "__NEW", "__DELETE", "__QUERYINTERFACE"].includes(
        t.text.toUpperCase(),
      ),
    )
  )
    issues.push({
      line: tokens.find((t) =>
        ["POINTER", "ADR", "__NEW", "__DELETE", "__QUERYINTERFACE"].includes(
          t.text.toUpperCase(),
        ),
      )!.line,
      message:
        "Pointer/dynamic behavior cannot be resolved by this static index",
    });
  return {
    tokens: lexical.tokens,
    statements,
    expressions,
    issues,
    complete: issues.length === 0,
  };
}

export interface Reference {
  path: string;
  part: "declaration" | "implementation";
  line: number;
  expression: string;
  access: "read" | "write" | "possible-write" | "call";
  conditional: boolean;
}
export function indexObject(source: SourceObject) {
  const parsed = parseST(source.implementation),
    refs: Reference[] = [];
  for (const part of ["declaration", "implementation"] as const) {
    const tokens = significant(tokenize(source[part]).tokens);
    for (let i = 0; i < tokens.length; i++) {
      const first = tokens[i];
      if (
        first.kind !== "id" ||
        keywords.has(first.text.toUpperCase()) ||
        tokens[i - 1]?.text === "."
      )
        continue;
      let end = i + 1;
      while (end < tokens.length) {
        if (tokens[end].text === "." && tokens[end + 1]?.kind === "id") {
          end += 2;
          continue;
        }
        if (tokens[end].text === "[") {
          let depth = 1;
          end++;
          while (end < tokens.length && depth) {
            if (tokens[end].text === "[") depth++;
            if (tokens[end].text === "]") depth--;
            end++;
          }
          continue;
        }
        break;
      }
      const expression = join(tokens.slice(i, end));
      const stmt = parsed.statements.find(
        (s) =>
          s.tokens.includes(first) ||
          (s.line <= first.line && s.tokens.at(-1)!.line >= first.line),
      );
      let access: Reference["access"] =
        tokens[end]?.text === ":="
          ? "write"
          : tokens[end]?.text === "("
            ? "call"
            : "read";
      if (access === "write" && /\[[^\]]*[A-Za-z_][^\]]*\]/.test(expression))
        access = "possible-write";
      refs.push({
        path: source.path,
        part,
        line: first.line,
        expression,
        access,
        conditional: part === "implementation" && (stmt?.conditional ?? false),
      });
      i = end - 1;
    }
  }
  return {
    sourceHash: source.sha256,
    parsed,
    declarations: parseDeclarations(source.declaration),
    refs,
  };
}

export class AnalysisIndex {
  private cache = new Map<string, ReturnType<typeof indexObject>>();
  analyze(objects: SourceObject[], profile: TargetProfile = defaultProfile) {
    const findings: Finding[] = [],
      refs: Reference[] = [],
      gaps: { path: string; line: number; message: string }[] = [];
    function add(
      o: SourceObject,
      part: Finding["part"],
      line: number,
      rule: string,
      message: string,
      severity: Finding["severity"] = "warning",
      confidence: Finding["confidence"] = "possible",
      standard = "IEC 61131-3",
    ) {
      findings.push({
        rule,
        path: o.path,
        part,
        line,
        column: 1,
        snippet: o[part].split("\n")[line - 1] ?? "",
        severity,
        confidence,
        evidence: "static",
        message,
        standard,
        verification:
          "Review task/call order and initial conditions; compile and run the stated scenario in an isolated IDE simulation.",
      });
    }
    for (const o of objects) {
      const key = (o.id ?? o.path) + ":" + o.sha256;
      let idx = this.cache.get(key);
      if (!idx) {
        idx = indexObject(o);
        this.cache.set(key, idx);
      }
      refs.push(...idx.refs);
      gaps.push(
        ...idx.parsed.issues.map((i) => ({ path: o.path, ...i })),
        ...idx.declarations.issues.map((i) => ({ path: o.path, ...i })),
      );
      for (const d of idx.declarations.declarations) {
        if (
          d.initializer &&
          d.names.some((n) => /(?:DO|output|pump|trigger)/i.test(n))
        )
          add(
            o,
            "declaration",
            d.line,
            "OUTPUT_INITIAL_VALUE",
            "Output-related variable has an explicit initial value; inspect cold/warm start and retention",
          );
      }
      for (const part of ["declaration", "implementation"] as const) {
        const tokens = tokenize(o[part]);
        gaps.push(...tokens.issues.map((i) => ({ path: o.path, ...i })));
        for (const t of tokens.tokens.filter((t) => t.kind === "id")) {
          if (
            ["UCHAR", "USTRING"].includes(t.text.toUpperCase()) &&
            !profile.verifiedFeatures.includes(t.text.toUpperCase())
          )
            add(
              o,
              part,
              t.line,
              "UNVERIFIED_FEATURE",
              "Feature not verified for the selected compiler: " + t.text,
              "error",
              "confirmed-static",
            );
          if (["RETAIN", "PERSISTENT", "AT"].includes(t.text.toUpperCase()))
            add(
              o,
              part,
              t.line,
              "STARTUP_CONTEXT",
              "Check retained initial state or direct address before drawing startup conclusions",
              "info",
            );
        }
      }
      const assignments = idx.parsed.statements.filter(
        (s) => s.kind === "assign",
      );
      for (const s of assignments) {
        if (/DO\[/i.test(s.target ?? "") && /TRUE|1/i.test(s.value ?? ""))
          add(
            o,
            "implementation",
            s.line,
            "OUTPUT_ENABLE",
            "Output can be enabled here; correlate with startup reachability and I/O mapping",
          );
        if (
          /entered|entry/i.test(s.target ?? "") &&
          /^FALSE$/i.test(s.value ?? "") &&
          assignments.some(
            (a) =>
              a.target?.toLowerCase() === s.target?.toLowerCase() &&
              /^TRUE$/i.test(a.value ?? "") &&
              a.line < s.line,
          )
        )
          add(
            o,
            "implementation",
            s.line,
            "ENTRY_CLEARED",
            "Entry flag may be cleared in the same scan before the next state consumes it",
          );
      }
      for (const r of idx.refs.filter(
        (r) =>
          r.part === "implementation" &&
          r.access === "call" &&
          /^(?:.*\.)?(?:fb.*(?:Timer|Trig)|TON|TOF|TP|R_TRIG|F_TRIG|MC_\w+)$/i.test(
            r.expression,
          ),
      )) {
        if (r.conditional)
          add(
            o,
            "implementation",
            r.line,
            "CONDITIONAL_FB",
            "Stateful function block may not be called every scan; inspect instance type and invocation contract",
          );
      }
      const instanceTypes = new Map(
        idx.declarations.declarations.flatMap((d) =>
          d.names.map(
            (name) =>
              [
                name.toLowerCase(),
                d.type.split(".").at(-1)!.toUpperCase(),
              ] as const,
          ),
        ),
      );
      const motionCalls: { line: number; type: string; execute?: string }[] =
        [];
      for (const item of idx.parsed.expressions) {
        if (
          item.expression.kind !== "call" ||
          item.expression.callee.kind !== "name"
        )
          continue;
        const type =
          instanceTypes.get(item.expression.callee.value.toLowerCase()) ??
          item.expression.callee.value.toUpperCase();
        if (!/^(?:MC_|TON$|TOF$|TP$|R_TRIG$|F_TRIG$)/.test(type)) continue;
        const statement = idx.parsed.statements.find(
          (s) => s.line === item.line,
        );
        if (statement?.conditional)
          add(
            o,
            "implementation",
            item.line,
            "STATEFUL_CALL_SCHEDULE",
            `${type} is conditionally called; verify scan invocation and state retention`,
          );
        if (type.startsWith("MC_")) {
          const execute = item.expression.arguments.find(
            (a) => a.name?.toUpperCase() === "EXECUTE",
          );
          motionCalls.push({
            line: item.line,
            type,
            execute: execute ? JSON.stringify(execute.value) : undefined,
          });
          add(
            o,
            "implementation",
            item.line,
            "MOTION_HANDSHAKE_REVIEW",
            `${type}: verify Execute edge/reset, Busy/Done/Error, axis identity and fault/stop priority`,
            "info",
            "possible",
            "PLCopen Motion Control",
          );
        }
      }
      if (
        motionCalls.filter((c) => /MC_(?:HOME|MOVE|STOP|HALT)/.test(c.type))
          .length > 1
      )
        add(
          o,
          "implementation",
          motionCalls[0].line,
          "MOTION_COMMAND_OWNERSHIP",
          "Several motion commands exist in this object; verify mutual exclusion and stop/fault precedence",
          "warning",
          "possible",
          "PLCopen Motion Control",
        );
      const grouped = new Map<string, Statement[]>();
      for (const statement of assignments.filter((s) =>
        s.target?.includes("."),
      )) {
        const key = statement.target!.toLowerCase();
        grouped.set(key, [...(grouped.get(key) ?? []), statement]);
      }
      for (const [target, list] of grouped)
        if (
          list.length > 1 &&
          list.some((s) => !s.conditional) &&
          new Set(list.map((s) => s.value)).size > 1
        )
          add(
            o,
            "implementation",
            list.at(-1)!.line,
            "SCAN_WRITE_ORDER",
            `${target} has different assignments and an unconditional write; check which value survives the scan`,
          );
      if (
        idx.parsed.statements.some(
          (s) =>
            s.kind === "control" && s.tokens[0].text.toUpperCase() === "CASE",
        ) &&
        !idx.parsed.tokens.some(
          (t) => t.kind === "id" && t.text.toUpperCase() === "ELSE",
        )
      )
        add(
          o,
          "implementation",
          1,
          "CASE_FALLBACK",
          "Review behavior for an unexpected state value",
        );
    }
    const writes = refs.filter(
      (r) => r.access === "write" || r.access === "possible-write",
    );
    const globalWrites = new Map<string, Reference[]>();
    for (const r of writes.filter((r) => r.expression.includes("."))) {
      const key = r.expression.toLowerCase();
      globalWrites.set(key, [...(globalWrites.get(key) ?? []), r]);
    }
    for (const list of globalWrites.values())
      if (new Set(list.map((r) => r.path)).size > 1)
        for (const r of list) {
          const o = objects.find((o) => o.path === r.path)!;
          add(
            o,
            r.part,
            r.line,
            "MULTIPLE_WRITERS",
            "Multiple objects assign this expression; inspect task ownership and order",
          );
        }
    if (this.cache.size > 20000) this.cache.clear();
    return {
      findings,
      references: refs,
      gaps,
      complete: gaps.length === 0,
      profile,
      certification: false,
      evidence: "static",
    };
  }
}

export function referencesTo(refs: Reference[], query: string) {
  const target = query.replace(/\s/g, "").toLowerCase(),
    base = target.split("[")[0];
  return refs.filter((r) => {
    const expr = r.expression.toLowerCase();
    return (
      expr === target ||
      expr === base ||
      (expr.startsWith(base + "[") && /\[[^\]]*[A-Za-z_]/.test(expr))
    );
  });
}
export function formatST(text: string): {
  text: string;
  changed: boolean;
  issues: ParseIssue[];
} {
  const parsed = parseST(text);
  if (!parsed.complete) return { text, changed: false, issues: parsed.issues };
  // Token replacements preserve every literal, pragma, comment and newline byte.
  let result = text;
  for (const t of [...parsed.tokens].reverse())
    if (t.kind === "id" && keywords.has(t.text.toUpperCase()))
      result =
        result.slice(0, t.start) + t.text.toUpperCase() + result.slice(t.end);
  const lexical = tokenize(result).tokens,
    lines = result.split("\n");
  let depth = 0;
  const opens =
    /^(?:IF|CASE|FOR|WHILE|REPEAT|VAR(?:_INPUT|_OUTPUT|_IN_OUT|_TEMP|_GLOBAL|_STAT)?|STRUCT|UNION)$/;
  const closes =
    /^(?:END_IF|END_CASE|END_FOR|END_WHILE|END_REPEAT|END_VAR|END_STRUCT|END_UNION)$/;
  result = lines
    .map((line, i) => {
      const lineNo = i + 1,
        here = lexical.filter((t) => t.line === lineNo),
        active = here.filter(
          (t) =>
            t.kind !== "comment" && t.kind !== "string" && t.kind !== "pragma",
        );
      // Never rewrite a line inside a multiline literal, pragma or comment.
      const protectedLine = lexical.some(
        (t) =>
          ["string", "comment", "pragma"].includes(t.kind) &&
          t.line < lineNo &&
          t.line + t.text.split("\n").length - 1 >= lineNo,
      );
      const first = active[0]?.text.toUpperCase(),
        middle = first === "ELSE" || first === "ELSIF";
      const indentation = Math.max(
        0,
        depth - (closes.test(first ?? "") || middle ? 1 : 0),
      );
      const formatted =
        protectedLine || !line.trim()
          ? line
          : " ".repeat(indentation * 4) + line.trimStart();
      for (const t of active)
        if (t.kind === "id") {
          const word = t.text.toUpperCase();
          if (opens.test(word)) depth++;
          if (closes.test(word)) depth = Math.max(0, depth - 1);
        }
      return formatted;
    })
    .join("\n");
  return { text: result, changed: result !== text, issues: [] };
}
export const analysisFingerprint = (objects: SourceObject[]) =>
  sha256(JSON.stringify(objects.map((o) => [o.path, o.sha256])));
