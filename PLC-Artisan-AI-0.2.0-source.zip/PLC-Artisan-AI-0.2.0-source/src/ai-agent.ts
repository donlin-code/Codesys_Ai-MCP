import { randomUUID } from "node:crypto";
import { join } from "node:path";
import type { EngineeringService } from "./engineering.js";
import type { TelemetryManager } from "./telemetry.js";
import { AppError, saveJson, sha256 } from "./core.js";
import {
  ProviderStore,
  complete,
  initialMessages,
  appendToolResults,
  consentHash,
} from "./providers.js";
import { publicTools, invokeTool } from "./toolkit.js";
import { targetProfile } from "./standards.js";

export interface Selection {
  path: string;
  part: "declaration" | "implementation";
  startLine: number;
  endLine: number;
  sha256: string;
}
export interface AIRequest {
  providerId: string;
  prompt: string;
  selections: Selection[];
  languageEdition?: "2013" | "2025";
}
export class AIAgent {
  private consents = new Set<string>();
  constructor(
    private service: EngineeringService,
    private telemetry: TelemetryManager,
    private providers: ProviderStore,
    private directory: string,
  ) {}
  async preview(request: AIRequest) {
    if (
      !request.providerId ||
      !request.prompt ||
      request.prompt.length > 32000 ||
      !Array.isArray(request.selections) ||
      request.selections.length > 100 ||
      (request.languageEdition !== undefined &&
        !["2013", "2025"].includes(request.languageEdition))
    )
      throw new AppError(
        "AI_REQUEST_INVALID",
        "Select provider, prompt and bounded excerpts",
      );
    const configured = (await this.providers.list()).find(
      (p) => p.id === request.providerId,
    );
    if (!configured)
      throw new AppError(
        "PROVIDER_MISSING",
        "Configure and select the provider before previewing source",
      );
    const provider = {
      id: configured.id,
      name: configured.name,
      kind: configured.kind,
      baseUrl: configured.baseUrl,
      model: configured.model,
      supportsTools: configured.supportsTools,
    };
    const profile = targetProfile(request.languageEdition);
    const pieces = request.selections.map((s) => {
      const o = this.service.snapshot?.objects.find((o) => o.path === s.path),
        lines = o?.[s.part]?.split("\n");
      if (
        !o ||
        o.sha256 !== s.sha256 ||
        !lines ||
        !Number.isInteger(s.startLine) ||
        !Number.isInteger(s.endLine) ||
        s.startLine < 1 ||
        s.endLine < s.startLine ||
        s.endLine > lines.length
      )
        throw new AppError(
          "SCOPE_CHANGED",
          "Source selection changed or has invalid line bounds",
        );
      return { ...s, text: lines.slice(s.startLine - 1, s.endLine).join("\n") };
    });
    const text = pieces
      .map(
        (s) =>
          `${s.path} [${s.part}:${s.startLine}-${s.endLine}] (${s.sha256})\n${s.text}`,
      )
      .join("\n\n");
    if (Buffer.byteLength(text) > 1024 * 1024)
      throw new AppError(
        "AI_SCOPE_LIMIT",
        "Choose at most 1 MiB of source per request",
      );
    return {
      provider,
      profile,
      pieces,
      bytes: Buffer.byteLength(text),
      text,
      consent: consentHash(
        JSON.stringify({ provider, profile }),
        request.prompt,
        request.selections,
      ),
    };
  }
  async consent(request: AIRequest) {
    const preview = await this.preview(request);
    this.consents.add(preview.consent);
    return { consentHash: preview.consent, bytes: preview.bytes };
  }
  async run(
    request: AIRequest,
    emit: (value: any) => void,
    signal?: AbortSignal,
  ) {
    const preview = await this.preview(request);
    if (!this.consents.has(preview.consent))
      throw new AppError(
        "SEND_CONSENT_REQUIRED",
        "Confirm provider and exact source sending scope first",
      );
    // Consent is one request only; provider/scope/prompt changes always need a new review.
    this.consents.delete(preview.consent);
    const { config, key } = await this.providers.get(request.providerId),
      messages = initialMessages(
        config.kind,
        request.prompt,
        preview.text,
        preview.profile,
      ),
      transcript: any[] = [];
    if (
      JSON.stringify(preview.provider) !==
      JSON.stringify({
        id: config.id,
        name: config.name,
        kind: config.kind,
        baseUrl: config.baseUrl,
        model: config.model,
        supportsTools: config.supportsTools,
      })
    )
      throw new AppError(
        "SEND_CONSENT_REQUIRED",
        "Provider configuration changed; preview and confirm again",
      );
    const allowed = new Set([
      "codesys_status",
      "codesys_generation_rules",
      "codesys_check_st",
      "codesys_batch_prepare",
      "codesys_batch_status",
      "codesys_batch_execute",
      "codesys_read_object",
      "codesys_search",
      "codesys_references",
      "codesys_analyze",
      "codesys_compile",
    ]);
    const tools = publicTools
      .filter((t) => allowed.has(t.name))
      .map((t) => ({
        name: t.name,
        description: t.description,
        parameters: t.inputSchema,
      }));
    const paths = new Set(request.selections.map((s) => s.path));
    // Keep the consent baseline for this run even when a verified write
    // invalidates the service's shared collection cache.
    const consentObjects = this.service.snapshot?.objects ?? [];
    const fullObject = (path: string) => {
      const object = consentObjects.find((o) => o.path === path);
      return (
        object &&
        (["declaration", "implementation"] as const).every(
          (part) =>
            !object[part] ||
            request.selections.some(
              (s) =>
                s.path === path &&
                s.part === part &&
                s.startLine === 1 &&
                s.endLine === object[part].split("\n").length,
            ),
        )
      );
    };
    const checkBatchScope = (batch: any) => {
      if (
        batch.operations.some((o: any) => {
          const source = consentObjects.find((s) => s.path === o.path);
          return (
            !fullObject(o.path) ||
            !source ||
            (o.before?.sha256 !== source.sha256 &&
              !(o.state === "verified" && o.afterHash === source.sha256))
          );
        })
      )
        throw new AppError(
          "EXPANDED_SCOPE",
          "Batch baseline differs from the confirmed source; recollect and confirm the new scope",
        );
    };
    const batchSummary = (batch: any) => ({
      id: batch.id,
      planHash: batch.planHash,
      applicationPath: batch.applicationPath,
      approved: !!batch.approval,
      halted: !!batch.halted,
      operations: batch.operations.map((o: any) => ({
        id: o.id,
        path: o.path,
        action: o.action,
        state: o.state,
        beforeSha256: o.before?.sha256,
        afterSha256: o.afterHash,
        errorCode: o.result?.error?.code,
      })),
      details:
        "Complete diffs and raw execution evidence are retained in the local workbench.",
    });
    const scopeTool = async (name: string, args: any) => {
      if (!allowed.has(name))
        throw new AppError("AI_TOOL_DENIED", "Tool not available to the model");
      if (name === "codesys_read_object") {
        if (!paths.has(args.path))
          throw new AppError(
            "EXPANDED_SCOPE",
            "Select and confirm this additional object before sending it",
          );
        return {
          path: args.path,
          excerpts: preview.pieces.filter((p) => p.path === args.path),
          completeObject: fullObject(args.path),
        };
      }
      if (name === "codesys_batch_prepare") {
        if (
          !Array.isArray(args.operations) ||
          args.operations.some(
            (o: any) => o.action !== "replace_st" || !fullObject(o.args?.path),
          )
        )
          throw new AppError(
            "EXPANDED_SCOPE",
            "AI editing requires full approved excerpts for every existing target; create new objects from the human draft interface",
          );
        const batch = await invokeTool(
          this.service,
          this.telemetry,
          name,
          args,
        );
        checkBatchScope(batch);
        return batchSummary(batch);
      }
      if (["codesys_batch_execute", "codesys_batch_status"].includes(name)) {
        const batch = await this.service.getBatch(args.batchId);
        checkBatchScope(batch);
        return batchSummary(
          await invokeTool(this.service, this.telemetry, name, args),
        );
      }
      if (name === "codesys_compile") {
        if (!args.batchId)
          throw new AppError(
            "AI_TOOL_DENIED",
            "AI compilation requires a reviewed batch",
          );
        const batch = await this.service.getBatch(args.batchId);
        checkBatchScope(batch);
        const result = await invokeTool(
          this.service,
          this.telemetry,
          name,
          args,
        );
        return {
          success: result.success,
          errorCount: result.errorCount,
          warningCount: result.warningCount,
          details:
            "Full diagnostics retained locally; review in workbench to avoid sending unrelated source diagnostics.",
        };
      }
      const result = await invokeTool(this.service, this.telemetry, name, args);
      const allowedLine = (r: any) =>
        request.selections.some(
          (s) =>
            s.path === r.path &&
            (!r.part || s.part === r.part) &&
            r.line >= s.startLine &&
            r.line <= s.endLine,
        );
      if (name === "codesys_search" || name === "codesys_references")
        return result.filter(allowedLine);
      if (name === "codesys_analyze")
        return {
          findings: result.findings.filter(allowedLine),
          gaps: result.gaps.filter(allowedLine),
          complete: false,
          scope: "Selected excerpts only",
        };
      return result;
    };
    const runId = randomUUID();
    try {
      for (let round = 0; round < 12; round++) {
        signal?.throwIfAborted();
        const reply = await complete(
          config,
          key,
          messages,
          tools,
          emit,
          signal,
        );
        transcript.push({ role: "assistant", ...reply });
        if (!config.supportsTools && reply.calls.length)
          throw new AppError(
            "TOOLS_UNSUPPORTED",
            "Provider profile is analysis-only; tool calls were not executed",
          );
        if (!reply.calls.length) {
          emit({ type: "done", runId });
          return;
        }
        const results = [];
        for (const call of reply.calls) {
          signal?.throwIfAborted();
          let result;
          try {
            result = await scopeTool(call.name, call.arguments);
          } catch (e) {
            const code = (e as any).code ?? "TOOL_ERROR";
            result = { error: { code, message: (e as Error).message } };
            if (
              call.name === "codesys_batch_execute" ||
              [
                "APPROVAL_REQUIRED",
                "EXPANDED_SCOPE",
                "SCOPE_CHANGED",
                "BATCH_HALTED",
                "UNRESOLVED_WRITE",
                "CONFLICT",
                "WRITE_OUTCOME_UNKNOWN",
              ].includes(code)
            ) {
              emit({ type: "paused", reason: code, call, result, runId });
              return;
            }
          }
          results.push(result);
          transcript.push({
            tool: call.name,
            arguments: call.arguments,
            result,
          });
          emit({ type: "tool", name: call.name, result });
          if (call.name === "codesys_batch_prepare") {
            emit({
              type: "paused",
              reason: "APPROVAL_REQUIRED",
              batchId: result.id,
              runId,
            });
            return;
          }
          if (call.name === "codesys_compile" && result.success === false) {
            emit({
              type: "paused",
              reason: "COMPILE_FAILED_NEW_BATCH_REQUIRED",
              runId,
            });
            return;
          }
        }
        appendToolResults(config.kind, messages, reply, results);
      }
      emit({ type: "paused", reason: "TOOL_ROUND_LIMIT", runId });
    } finally {
      await saveJson(join(this.directory, "ai-runs", runId + ".json"), {
        runId,
        providerId: config.id,
        model: config.model,
        scope: request.selections,
        promptHash: sha256(request.prompt),
        transcript,
      });
    }
  }
}
