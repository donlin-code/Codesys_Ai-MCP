import { spawn } from "node:child_process";
import { join, dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { unlink } from "node:fs/promises";
import { setTimeout as delay } from "node:timers/promises";
import { loadJson, AppError } from "./core.js";
import type { ServiceEndpoint } from "./workbench-server.js";

export async function rpc(endpoint: ServiceEndpoint, input: unknown) {
  const response = await fetch(endpoint.url + "/rpc", {
    method: "POST",
    headers: {
      Authorization: "Bearer " + endpoint.token,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(input),
    signal: AbortSignal.timeout(180000),
    redirect: "error",
  });
  const value: any = await response.json();
  if (!response.ok || value.ok === false)
    throw new AppError(
      value.error?.code ?? "SERVICE_ERROR",
      value.error?.message ?? `HTTP ${response.status}`,
    );
  return value;
}
export async function ensureService(
  directory?: string,
  config?: string,
): Promise<ServiceEndpoint> {
  const root = resolve(dirname(fileURLToPath(import.meta.url)), "../.."),
    data = resolve(directory ?? join(root, "artifacts", "workbench")),
    endpointPath = join(data, "service.json");
  config = config ? resolve(config) : undefined;
  const prior = await loadJson<ServiceEndpoint | null>(endpointPath, null);
  if (prior) {
    try {
      await rpc(prior, { method: "tools/list" });
      if (config) {
        const desired = await loadJson<{ sessionId: string }>(config);
        const current = await rpc(prior, {
          method: "tools/call",
          name: "codesys_status",
          arguments: {},
        });
        if (current.result.session?.sessionId !== desired.sessionId)
          throw new AppError(
            "SESSION_SELECTION_REQUIRED",
            "Shared service is bound to another session; select the new bridge explicitly in the workbench",
          );
      }
      return prior;
    } catch (e) {
      if (e instanceof AppError && e.code === "SESSION_SELECTION_REQUIRED")
        throw e;
      try {
        process.kill(prior.pid, 0);
        throw new AppError(
          "SERVICE_UNRESPONSIVE",
          "Existing service PID is alive; inspect it instead of starting another",
        );
      } catch (e) {
        if ((e as NodeJS.ErrnoException).code !== "ESRCH") throw e;
      }
      const lock = await loadJson<{ pid: number } | null>(
        join(data, "service.lock"),
        null,
      );
      if (lock?.pid === prior.pid)
        await unlink(join(data, "service.lock")).catch(() => {});
    }
  }
  const child = spawn(
    process.execPath,
    [
      fileURLToPath(new URL("./workbench-server.js", import.meta.url)),
      "--data",
      data,
      ...(config ? ["--config", config] : []),
    ],
    { cwd: root, detached: true, windowsHide: true, stdio: "ignore" },
  );
  child.unref();
  for (let n = 0; n < 100; n++) {
    await delay(100);
    const endpoint = await loadJson<ServiceEndpoint | null>(endpointPath, null);
    if (endpoint && endpoint.pid !== prior?.pid) {
      try {
        await rpc(endpoint, { method: "tools/list" });
        return endpoint;
      } catch {}
    }
  }
  throw new AppError(
    "SERVICE_START_FAILED",
    "Local service did not start; use Start-Workbench.ps1 to inspect startup",
  );
}
